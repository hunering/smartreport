drop table SMP_INCOME_CHANNEL cascade constraints;

/*==============================================================*/
/* Table: SMP_INCOME_CHANNEL                                    */
/*==============================================================*/
create table SMP_INCOME_CHANNEL  (
   pk_incomechannel     VARCHAR2(50)                    not null,
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   pk_clsexe            VARCHAR2(50),
   studentnum           NUMBER(18),
   total_money          NUMBER(18,6),
   pk_branch            VARCHAR2(50),
   pk_agent             VARCHAR2(50)
)
tablespace NNC_DATA01
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256
    next 256
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
  
  -- Create/Recreate primary, unique and foreign key constraints 
alter table SMP_INCOME_CHANNEL
  add constraint PK_SMP_INCOME_CHANNEL primary key (pk_incomechannel)
  using index 
  tablespace NNC_DATA01
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    next 256K
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
