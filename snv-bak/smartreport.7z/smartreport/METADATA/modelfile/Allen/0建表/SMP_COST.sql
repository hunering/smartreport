drop table SMP_COST cascade constraints;

/*==============================================================*/
/* Table: SMP_COST                                      */
/*==============================================================*/
create table SMP_COST  (
   pk_cost              VARCHAR2(50)                    not null,
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   pk_clsexe            VARCHAR2(50),
   meeting_cost         NUMBER(18,6),
   teacher_cost         NUMBER(18,6),
   project_cost         NUMBER(18,6)
)
tablespace NNC_DATA01
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256
    next 256
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
  
  -- Create/Recreate primary, unique and foreign key constraints 
alter table SMP_COST
  add constraint PK_SMP_COST primary key (pk_cost)
  using index 
  tablespace NNC_DATA01
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    next 256K
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
