drop table SMP_BRANCH cascade constraints;

/*==============================================================*/
/* Table: SMP_BRANCH                                            */
/*==============================================================*/
create table SMP_BRANCH  (
   pk_branch            VARCHAR2(50)                    not null,
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   pk_area              VARCHAR2(50),
   name                 VARCHAR2(50)
)
tablespace NNC_DATA01
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256
    next 256
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
  
  -- Create/Recreate primary, unique and foreign key constraints 
alter table SMP_BRANCH
  add constraint PK_SMP_BRANCH primary key (pk_branch)
  using index 
  tablespace NNC_DATA01
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    next 256K
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
