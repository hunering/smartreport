prompt Importing table PUB_REPORT_TEMPLET...
set feedback off
set define off
insert into PUB_REPORT_TEMPLET (DESCRIBE, DR, NODE_CODE, NODE_NAME, PARENT_CODE, PK_CORP, PK_TEMPLET, PRINTINFO, RESID, SUBHEAD, TS)
values (null, 0, '98H26000', '������ϸ', '98H260', '@@@@', '0001ZZ100000000007Q3', null, null, null, '2013-09-17 22:22:21');

insert into PUB_REPORT_TEMPLET (DESCRIBE, DR, NODE_CODE, NODE_NAME, PARENT_CODE, PK_CORP, PK_TEMPLET, PRINTINFO, RESID, SUBHEAD, TS)
values (null, 0, '98H26200', '����ɱ���ϸ��', '98H262', '@@@@', '0001ZZ10000000000PHJ', null, null, null, '2013-09-25 01:31:23');

insert into PUB_REPORT_TEMPLET (DESCRIBE, DR, NODE_CODE, NODE_NAME, PARENT_CODE, PK_CORP, PK_TEMPLET, PRINTINFO, RESID, SUBHEAD, TS)
values (null, 0, '98H26100', '���������뱨��', '98H261', '@@@@', '0001ZZ10000000000HR0', null, null, null, '2013-09-23 22:12:59');

prompt Done.
