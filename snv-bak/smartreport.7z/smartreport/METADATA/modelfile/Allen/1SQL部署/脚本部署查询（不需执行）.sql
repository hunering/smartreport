select * from sm_funcregister where CLASS_NAME like '%smp%';

select * from bd_billtype  where pk_billtypecode like '%SP%';

select * from pub_billcode_rule where pk_billtypecode like '%SP%';

select * from pub_billaction where pk_billtype like '%SP%';

select * from pub_busiclass where pk_billtype like '%SP%';
select * from pub_votable where pk_billtype like '%SP%';
select * from pub_billtobillrefer where billtype like '%SP%';

select * from pub_billtemplet where pk_billtypecode like '%SP%';
select * from pub_billtemplet_b where pk_billtemplet in(select pk_billtemplet from pub_billtemplet where pk_billtypecode like '%SP%');
select * from pub_billtemplet_t where pk_billtemplet in(select pk_billtemplet from pub_billtemplet where pk_billtypecode like '%SP%');

select * from pub_query_templet where node_code like '%98%';
select * from pub_query_condition where pk_templet in(select id from pub_query_templet where node_code like '%98%');
select * from pub_systemplate where funnode like '%98%';
select * from dap_defitem where pk_billtype like '%SP%';
select * from pub_function where pk_billtype='21' and functionnote like '%SP%';
