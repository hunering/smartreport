select * from dap_dapsystem ;

insert into dap_dapsystem (DEF1, DEF2, DEF3, DR, FUNCODE, ISACCOUNT, ISITEM, MODULE, RESOURCEID, SYSTYPECODE, SYSTYPENAME, TS, USEBUSITYPE)
values (null, null, null, 0, '98', 'N', 'N', 'smp', null, 'SMP', '�ж��ɹ�', '2013-09-08 13:25:03', 0);

select * from sm_codetocode;

insert into sm_codetocode (DISPCODE, DR, FUNCCODE, ISLEAF, MODULETYPE, PK_CODETOCODE, SUBFUNCCODE, TS)
values (null, 0, '98', 'Y', 1, '98', null, '2013-09-08 13:25:04');

select * from smp_income;
alter table smp_income add vbilltype VARCHAR2(50)
