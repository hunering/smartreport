prompt Importing table pub_systemplate...
set feedback off
set define off
insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H101', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000001', null, 'Y', '0001ZZ1000000000033S', 0, '2013-09-16 14:39:10');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H102', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000002', null, 'Y', '0001ZZ10000000000348', 0, '2013-09-16 14:51:59');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H103', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000003', null, 'Y', '0001ZZ1000000000034T', 0, '2013-09-16 15:03:32');

prompt Done.
