prompt Importing table pub_systemplate...
set feedback off
set define off
insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H260', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000000RT', null, 'Y', '0001ZZ100000000007Q3', 2, '2013-09-17 22:24:22');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H261', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000001JL', null, 'Y', '0001ZZ10000000000HR0', 2, '2013-09-23 22:15:54');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H262', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000335', null, 'Y', '0001ZZ10000000000PHJ', 2, '2013-09-25 01:41:35');

prompt Done.
