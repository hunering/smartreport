prompt Importing table pub_billtemplet...
set feedback off
set define off
insert into pub_billtemplet (BILL_TEMPLETCAPTION, BILL_TEMPLETNAME, DR, METADATACLASS, MODEL_TYPE, NODECODE, OPTIONS, PK_BILLTEMPLET, PK_BILLTYPECODE, PK_CORP, RESID, SHAREFLAG, TS, VALIDATEFORMULA)
values ('�������', 'SYSTEM', 0, null, null, null, null, '0001ZZ1000000000033S', 'SP10', '@@@@', null, 'N', '2013-09-16 14:34:29', null);

insert into pub_billtemplet (BILL_TEMPLETCAPTION, BILL_TEMPLETNAME, DR, METADATACLASS, MODEL_TYPE, NODECODE, OPTIONS, PK_BILLTEMPLET, PK_BILLTYPECODE, PK_CORP, RESID, SHAREFLAG, TS, VALIDATEFORMULA)
values ('�����̹���', 'SYSTEM', 0, null, null, null, null, '0001ZZ10000000000348', 'SP11', '@@@@', null, 'N', '2013-09-16 14:57:42', null);

insert into pub_billtemplet (BILL_TEMPLETCAPTION, BILL_TEMPLETNAME, DR, METADATACLASS, MODEL_TYPE, NODECODE, OPTIONS, PK_BILLTEMPLET, PK_BILLTYPECODE, PK_CORP, RESID, SHAREFLAG, TS, VALIDATEFORMULA)
values ('������ϸ', 'SYSTEM', 0, null, null, null, null, '0001ZZ1000000000034T', 'SP12', '@@@@', null, 'N', '2013-09-16 15:20:02', null);

prompt Done.
