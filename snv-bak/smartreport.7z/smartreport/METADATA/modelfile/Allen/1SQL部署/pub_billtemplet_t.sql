prompt Importing table pub_billtemplet_t...
set feedback off
set define off
insert into pub_billtemplet_t (BASETAB, DR, METADATACLASS, METADATAPATH, MIXINDEX, PK_BILLTEMPLET, PK_BILLTEMPLET_T, POS, POSITION, RESID, TABCODE, TABINDEX, TABNAME, TS, VDEF1, VDEF2, VDEF3)
values (null, 0, null, null, null, '0001ZZ1000000000033S', '0001ZZ1000000000033U', 0, null, null, 'smp_area', 0, '�������', '2013-09-16 14:34:29', null, null, null);

insert into pub_billtemplet_t (BASETAB, DR, METADATACLASS, METADATAPATH, MIXINDEX, PK_BILLTEMPLET, PK_BILLTEMPLET_T, POS, POSITION, RESID, TABCODE, TABINDEX, TABNAME, TS, VDEF1, VDEF2, VDEF3)
values (null, 0, null, null, null, '0001ZZ10000000000348', '0001ZZ1000000000034L', 0, null, null, 'smp_agent', 0, '�����̹���', '2013-09-16 14:57:42', null, null, null);

insert into pub_billtemplet_t (BASETAB, DR, METADATACLASS, METADATAPATH, MIXINDEX, PK_BILLTEMPLET, PK_BILLTEMPLET_T, POS, POSITION, RESID, TABCODE, TABINDEX, TABNAME, TS, VDEF1, VDEF2, VDEF3)
values (null, 0, null, null, null, '0001ZZ1000000000034T', '0001ZZ100000000003V0', 0, null, null, 'smp_clsexe', 0, '������ϸ', '2013-09-16 15:20:02', null, null, null);

prompt Done.
