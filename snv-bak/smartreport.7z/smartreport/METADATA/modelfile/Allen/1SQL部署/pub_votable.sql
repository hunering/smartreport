prompt Importing table pub_votable...
set feedback off
set define off
insert into pub_votable (APPROVEID, BILLID, BILLNO, BILLVO, BUSITYPE, DEF1, DEF2, DEF3, DR, HEADBODYFLAG, HEADITEMVO, ITEMCODE, OPERATOR, PK_BILLTYPE, PK_CORP, PK_VOTABLE, PKFIELD, TS, VOTABLE)
values ('vapproveid', 'pk_clsexe', 'vbillno', 'nc.vo.trade.pub.HYBillVO', null, 'pk_billtype', null, null, null, 'Y', 'nc.vo.smp.clsexe.ClsexeVO', null, 'voperatorid', 'SP03', null, '0001ZZ1000000000066O', 'pk_clsexe', '2013-09-09 15:29:04', 'smp_clsexe');

prompt Done.
