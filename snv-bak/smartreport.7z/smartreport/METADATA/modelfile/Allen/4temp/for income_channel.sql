select a.name as agentname, b.pk_clsexe as clsexe, sum(b.studentnum)as studentnum,sum(b.total_money)as totalmoney,
c.pk_corp as branchcode, c.unitname as branchname
from smp_agent a left join smp_income_channel b on (a.pk_agent=b.pk_agent)
left join smp_clsexe d on (b.pk_clsexe=d.pk_clsexe and d.class_start_date >=  '2013-09-01' and d.class_start_date <=  '2013-09-30')
left join bd_corp c on (a.pk_branch=c.pk_corp)
where a.dr=0 group by a.pk_agent, a.name, b.pk_clsexe, c.pk_corp, c.unitname

select * from smp_income_channel

alter table smp_income_channel add income_time char(19);
update smp_income_channel set income_time='2013-09-01';


select a.name as agentname, b.pk_clsexe as clsexe, sum(b.studentnum)as studentnum,sum(b.total_money)as totalmoney,
c.pk_corp as branchcode, c.unitname as branchname
from smp_agent a left join smp_income_channel b on (a.pk_agent=b.pk_agent and b.income_time >=  '2013-09-01' and b.income_time <=  '2013-09-30')
left join smp_clsexe d on (b.pk_clsexe=d.pk_clsexe)
left join bd_corp c on (a.pk_branch=c.pk_corp)
where a.dr=0 group by a.pk_agent, a.name, b.pk_clsexe, c.pk_corp, c.unitname

