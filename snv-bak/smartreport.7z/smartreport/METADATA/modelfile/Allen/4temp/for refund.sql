select * from smp_income_agent
select * from smp_refund
alter table smp_refund  rename column refunddate to refund_date;
alter table smp_refund add vbilltype VARCHAR2(50);
update smp_refund set refundamount=1234;
alter table smp_refund modify   refundamount         NUMBER(20,8);
select * from SMP_INCOMEINPUT;
delete from SMP_INCOMEINPUT;

select * from smp_performance;

select * from SMP_INCOME_CHANNEL;
drop table SMP_INCOMEINPUT cascade constraints;

/*==============================================================*/
/* Table: SMP_INCOMEINPUT                                       */
/*==============================================================*/
create table SMP_INCOMEINPUT  (
   pk_smp_incomeinput   VARCHAR2(50)                    not null,
   pk_branch            VARCHAR2(50),
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   vbilltype            VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   agent_income         NUMBER(10),
   self_income          NUMBER(10),
   agent_income_qj      NUMBER(10),
   zyywsjjfj            NUMBER(10),
   zyywcb               NUMBER(10),
   fytc                 NUMBER(10),
   agentfd              NUMBER(10),
   qtywsr               NUMBER(10),
   qtywcb               NUMBER(10),
   yywsz                NUMBER(10),
   ftzbfy               NUMBER(10),
   sdsfy                NUMBER(10),
   fydate               CHAR(10),
   ysxsyj               NUMBER(10),
   xyysxsyj             NUMBER(10),
   yscwsr               NUMBER(10),
   xyyscwsr             NUMBER(10),
   constraint PK_SMP_INCOMEINPUT primary key (pk_smp_incomeinput)
);
