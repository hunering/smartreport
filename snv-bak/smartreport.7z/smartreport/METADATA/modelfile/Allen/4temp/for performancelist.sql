select * from smp_performance;

select * from bd_corp;

select * from smp_team;
select * from smp_course;
delete smp_performance; 
select * from smp_performance;

alter table smp_performance add student_name         VARCHAR2(50);
alter table smp_performance add    account_name         VARCHAR2(50);
alter table smp_performance add    account_number       VARCHAR2(100);

select   to_char(sysdate,'W')   from   dual;   
select to_char('2013/10/11 22:17:04','W') from dual;

select c.unitname as branchname, a.achievetype, to_char(to_date(a.performance_date,'YYYY-MM-DD'),'W') as week, a.performance_date, a.remit_company, a.remit_amount,
 b.course_name, a.pk_partner, d.team_name, a.director_id, a.student_name, a.remit_name, a.account_name, a.account_number
 from smp_performance a left join smp_course b on (a.pk_course=b.pk_course) 
 left join bd_corp c on (a.pk_corp=c.pk_corp) left join smp_team d on (a.pk_team=d.pk_team) 
 where a.performance_date >= '2013-08-01' and a.performance_date <= '2013-08-91';

select * from smp_refund;

select c.unitname as branchname, a.achievetype, to_char(to_date(a.performance_date,'YYYY-MM-DD'),'W') as week, a.performance_date, a.remit_company,
  e.refundamount, b.course_name, a.pk_partner, d.team_name, a.director_id, a.student_name, a.remit_name, a.account_name, a.account_number
 from smp_refund e left join smp_performance a on (e.pk_performance=a.pk_performance) left join smp_course b on (a.pk_course=b.pk_course) 
 left join bd_corp c on (a.pk_corp=c.pk_corp) left join smp_team d on (a.pk_team=d.pk_team) 
 where e.refunddate >= '2013-08-01' and e.refunddate <= '2013-08-91'  and e.vbillstatus=1;
 
insert into smp_refund (refundid, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, dr, pk_corp, ts, pk_performance, refundamount, refunddate)
values ('000EHEA3DH0000000001', '', '', '', 1, '', '', '', '', 0, '', '2013-09-10 00:58:45', '0003AA13DH0000000002', 800, '2013-08-01');



drop table SMP_REFUND cascade constraints;

/*==============================================================*/
/* Table: SMP_REFUND                                            */
/*==============================================================*/
create table SMP_REFUND  (
   refundid             VARCHAR2(20)                    not null,
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   pk_performance       VARCHAR2(50),
   refundamount         VARCHAR2(50),
   refundreason         VARCHAR2(50),
   refunddate           CHAR(19),
   constraint PK_SMP_REFUND primary key (refundid)
);

