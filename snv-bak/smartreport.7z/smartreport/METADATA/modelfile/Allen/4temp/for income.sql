select * from bd_corp;

select * from bd_areacl;

insert into SMP_INCOME (pk_income, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, pk_corp, pk_clsexe, studentnum, total_money, group_money, branch_money, jx_money, sd_money, pk_area, pk_branch, ts, dr)
values ('000235EWRDH00EF00001', null, null, null, null, null, null, null, null, null, '0001ZZ100000000004MR', 10, 10000.01, 3000.12, 7000, 0, 0, '0001ZZ10000000000670', '0003', '2013-09-10 00:44:36', 0);


select * from smp_clsexe where class_start_date >='2013-09-01' and class_start_date<='2013-09-30';
select * from smp_clsexe_type;
select * from smp_income;


select b.def1, b.unitname, a.total_money from bd_corp b left join smp_income a on (a.pk_branch=b.unitcode) ;

select sum(a.total_money)as income, a.pk_clsexe, sum(a.studentnum) as studen_number, b.unitcode, b.unitname 
from bd_corp b left join smp_income a on (a.pk_branch=b.unitcode) 
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe) where c.class_start_date >='2013-09-01' and c.class_start_date<='2013-09-30' group by b.unitcode, b.unitname, a.pk_clsexe ;



select  b.pk_corp as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber, sum(a.total_money)as totalmoney, sum(a.group_money)as groupmoney, sum(a.branch_money)as branchmoney, 
sum(a.jx_money)as jxmoney, sum(a.sd_money)as sdmoney from bd_corp b left join smp_income a on (a.pk_branch=b.pk_corp) 
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >='2013-09-01' and c.class_start_date<='2013-09-30') 
group by b.pk_corp, b.unitname, a.pk_clsexe order by b.pk_corp;

       
select b.pk_corp as branchcode, b.unitname as branchname, a.pk_clsexe as clsexe
from bd_corp b left join smp_income a on (a.pk_branch=b.pk_corp)
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe
and c.class_start_date >= '2013-09-01' 
and c.class_start_date <= '2013-09-30')

       


select * from smp_clsexe;
select * from smp_income;
update smp_income 
select * from bd_corp;

select a.pk_clsexe, sum(b.studentnum)as studennumber,sum(b.total_money)as totalmoney,sum(b.group_money)as groupmoney, sum(b.branch_money)as branchmoney,
sum(b.jx_money)as jxmoney, sum(b.sd_money)as sdmoney from smp_clsexe a left join  smp_income b 
on (a.pk_clsexe=b.pk_clsexe and a.class_start_date >= '2013-09-01' and a.class_start_date <= '2013-09-30') group by a.pk_clsexe


select c.title, a.total_money from smp_income a join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >='2013-09-01' and c.class_start_date<='2013-09-30')
 join 

select b.def1, b.unitname, a.total_money,a.pk_branch from bd_corp b, smp_income a where (a.pk_branch=b.unitcode);

select * from smp_income where pk_branch='0003'

update smp_income set pk_branch='1002';
commit;
select * from smp_clsexe

select * from smp_course;



SELECT a.course_code,a.course_name,a.pk_course, a.headerquarter_percentage, a.branch_percentage, a.jixiao_percentage,
a.shidao_percentage, a.wuxiang_percentage, b.coursetype_name AS pk_coursetype FROM smp_course a 
					 LEFT JOIN smp_coursetype b ON a.pk_coursetype=b.pk_coursetype
					 WHERE nvl(a.dr,0)=0 AND nvl(b.dr,0)=0 
           

alter table smp_income add income_time char(19);
update smp_income set income_time='2013-09-01';


select b.pk_corp as branchcode, b.unitname as branchname, a.pk_clsexe as clsexe, sum(a.studentnum)as studentnum,
sum(a.total_money)as totalmoney, sum(a.total_money*d.headerquarter_percentage)as groupmoney,
sum(a.total_money*d.branch_percentage)as branchmoney, sum(a.total_money*d.jixiao_percentage)as jxmoney,
sum(a.total_money*d.shidao_percentage)as sdmoney, sum(a.total_money*d.wuxiang_percentage)as wxmoney 
from bd_corp b left join smp_income a on (a.pk_branch=b.pk_corp) 
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe 
and c.class_start_date >= '2013-09-01' 
and c.class_start_date <= '2013-09-31') 
left join smp_course d on (c.pk_course=d.pk_course)
group by b.pk_corp, b.unitname, a.pk_clsexe order by b.pk_corp


select b.pk_corp as branchcode, b.unitname as branchname, a.pk_clsexe as clsexe, sum(a.studentnum)as studentnum,
sum(a.total_money)as totalmoney, sum(a.total_money*d.headerquarter_percentage)as groupmoney,
sum(a.total_money*d.branch_percentage)as branchmoney, sum(a.total_money*d.jixiao_percentage)as jxmoney,
sum(a.total_money*d.shidao_percentage)as sdmoney, sum(a.total_money*d.wuxiang_percentage)as wxmoney 
from bd_corp b left join smp_income a on (a.pk_branch=b.pk_corp and a.income_time >= '2013-09-01' 
and a.income_time <= '2013-09-31') 
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe ) 
left join smp_course d on (c.pk_course=d.pk_course)
group by b.pk_corp, b.unitname, a.pk_clsexe order by b.pk_corp


		select a.pk_clsexe as clsexe, sum(b.studentnum)as studentnum,sum(b.total_money)as totalmoney,
			sum(b.total_money*d.headerquarter_percentage)as groupmoney, 
			sum(b.total_money*d.branch_percentage)as branchmoney, sum(b.total_money*d.jixiao_percentage)as jxmoney,
			sum(b.total_money*d.shidao_percentage)as sdmoney, sum(b.total_money*d.wuxiang_percentage)as wxmoney 
			from smp_income b left join smp_clsexe a on (a.pk_clsexe=b.pk_clsexe)
			left join smp_course d on (a.pk_course=d.pk_course) 
			where b.income_time >= '2013-09-01' and b.income_time <= '2013-09-31' group by a.pk_clsexe
    
       
