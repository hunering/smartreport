select * from bd_corp;

select * from bd_areacl;

insert into SMP_INCOME (pk_income, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, pk_corp, pk_clsexe, studentnum, total_money, group_money, branch_money, jx_money, sd_money, pk_area, pk_branch, ts, dr)
values ('000235EWRDH00EF00001', null, null, null, null, null, null, null, null, null, '0001ZZ100000000004MR', 10, 10000.01, 3000.12, 7000, 0, 0, '0001ZZ10000000000670', '0003', '2013-09-10 00:44:36', 0);


select * from smp_clsexe where class_start_date >='2013-09-01' and class_start_date<='2013-09-30';
select * from smp_clsexe_type;
select * from smp_income;


select b.def1, b.unitname, a.total_money from bd_corp b left join smp_income a on (a.pk_branch=b.unitcode) ;

select sum(a.total_money)as income, a.pk_clsexe, sum(a.studentnum) as studen_number, b.unitcode, b.unitname 
from bd_corp b left join smp_income a on (a.pk_branch=b.unitcode) 
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe) where c.class_start_date >='2013-09-01' and c.class_start_date<='2013-09-30' group by b.unitcode, b.unitname, a.pk_clsexe ;



select b.pk_corp as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber, sum(a.total_money)as totalmoney, sum(a.group_money)as groupmoney, sum(a.branch_money)as branchmoney, 
sum(a.jx_money)as jxmoney, sum(a.sd_money)as sdmoney from bd_corp b left join smp_income a on (a.pk_branch=b.pk_corp) 
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >='2013-09-01' and c.class_start_date<='2013-09-30') group by b.pk_corp, b.unitname, a.pk_clsexe order by b.pk_corp;


select c.title, a.total_money from smp_income a join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >='2013-09-01' and c.class_start_date<='2013-09-30')
 join 

select b.def1, b.unitname, a.total_money,a.pk_branch from bd_corp b, smp_income a where (a.pk_branch=b.unitcode);

select * from smp_income where pk_branch='0003'

update smp_income set pk_branch='1002';
commit;
select * from smp_clsexe
