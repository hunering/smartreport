select * from bd_billtype  where pk_billtypecode like 'SP%';

select * from dap_dapsystem ;

update bd_billtype set systemcode='SMP' where pk_billtypecode like 'SP%';

select * from smp_income;
delete from smp_income;
