select a.pk_agent as agentname, b.unitcode as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber,
sum(a.total_money)as totalmoney from smp_agent left join bd_corp b left join smp_income_agent a on (a.pk_branch=b.unitcode)
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >= '2013-09-01')
and c.class_start_date <= '2013-09-30'
group by b.unitcode, b.unitname, a.pk_clsexe, a.pk_agent order by b.unitcode, a.pk_agent


select a.pk_agent as agentname, b.pk_corp as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber,
sum(a.total_money)as totalmoney from smp_agent d left join smp_income_agent a on (a.pk_agent=d.pk_agent) left join bd_corp b on (a.pk_branch=b.pk_corp)
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >= '2013-09-01')
and c.class_start_date <= '2013-09-30'
group by b.pk_corp, b.unitname, a.pk_clsexe, a.pk_agent;

       
select a.pk_agent as agentname, a.name, b.pk_clsexe as clsexe, sum(b.studentnum)as studennumber,sum(b.total_money)as totalmoney,
c.pk_corp as branchcode, c.unitname as branchname
from smp_agent a left join smp_income_agent b on (a.pk_agent=b.pk_agent) 
left join smp_clsexe d on (b.pk_clsexe=d.pk_clsexe and d.class_start_date >= '2013-09-01' and d.class_start_date <= '2013-09-30')
left join bd_corp c on (a.pk_branch=c.pk_corp)
where a.dr=0 group by a.pk_agent, a.name, b.pk_clsexe, c.pk_corp, c.unitname;

select a.pk_clsexe, sum(b.studentnum)as studennumber,sum(b.total_money)as totalmoney from smp_clsexe a left join  smp_income_agent b 
on (a.pk_clsexe=b.pk_clsexe and a.class_start_date >= '2013-09-01' and a.class_start_date <= '2013-09-30') group by a.pk_clsexe


select a.pk_agent as agentname, a.name, b.pk_clsexe as clsexe, sum(b.studentnum)as studennumber,sum(b.total_money)as totalmoney, 
c.pk_corp as branchcode, c.unitname as branchname 
from smp_agent a left join smp_income_agent b on (a.pk_agent=b.pk_agent)left join smp_clsexe d on (b.pk_clsexe=d.pk_clsexe and d.class_start_date >= ? and d.class_start_date <= ?)left join bd_corp c on (a.pk_branch=c.pk_corp)where a.dr=0 group by a.pk_agent, a.name, b.pk_clsexe, c.pk_corp, c.unitname

select * from smp_agent where dr=0;

delete from smp_agent where dr<>0;

select *from smp_agent;
update smp_agent

select * from smp_clsexe;
select * from bd_corp;

update smp_income_agent set pk_branch='1004';
commit;

update smp_agent set pk_branch='1004';
commit;

update smp_income_agent set pk_agent='0001ZZ10000000000N5G';
commit;


select * from smp_income_agent;
delete  from smp_income_agent;

insert into SMP_INCOME_AGENT (pk_incomeagent, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, pk_corp, pk_clsexe, studentnum, total_money, pk_branch, pk_agent, ts, dr)
values ('000235SWJKE00EF00001', null, null, null, null, null, null, null, null, null,'0001ZZ100000000004MR', 5, 1257.67, '0003', '0001ZZ10000000000JAL', '2013-09-10 00:44:36', 0);
insert into SMP_INCOME_AGENT (pk_incomeagent, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, pk_corp, pk_clsexe, studentnum, total_money, pk_branch, pk_agent, ts, dr)
values ('000235SWJKE00EF00002', null, null, null, null, null, null, null, null, null,'0001ZZ100000000004MR', 6, 3000.67, '0003', '0001ZZ10000000000JAL', '2013-09-10 00:44:36', 0);
commit;

alter table smp_income_agent add income_time char(19);
update smp_income_agent set income_time='2013-09-01';

select a.pk_clsexe as clsexe, sum(b.studentnum)as studentnum,sum(b.total_money)as totalmoney,
sum(b.total_money*d.headerquarter_percentage)as groupmoney, 
sum(b.total_money*d.branch_percentage)as branchmoney, sum(b.total_money*d.jixiao_percentage)as jxmoney,
sum(b.total_money*d.shidao_percentage)as sdmoney, sum(b.total_money*d.wuxiang_percentage)as wxmoney 
from smp_clsexe a left join smp_income b on (a.pk_clsexe=b.pk_clsexe )
left join smp_course d on (a.pk_course=d.pk_course) 
where a.class_start_date >= '2013-09-01' and a.class_start_date <=  '2013-09-31' group by a.pk_clsexe
      

select a.pk_clsexe as clsexe, sum(b.studentnum)as studentnum,sum(b.total_money)as totalmoney,
sum(b.total_money*d.headerquarter_percentage)as groupmoney, 
sum(b.total_money*d.branch_percentage)as branchmoney, sum(b.total_money*d.jixiao_percentage)as jxmoney,
sum(b.total_money*d.shidao_percentage)as sdmoney, sum(b.total_money*d.wuxiang_percentage)as wxmoney 
from smp_clsexe a left join smp_income b on (a.pk_clsexe=b.pk_clsexe and b.income_time >= '2013-09-01' and b.income_time <= '2013-09-31')
left join smp_course d on (a.pk_course=d.pk_course) 
group by a.pk_clsexe
      
select a.pk_clsexe as clsexe, sum(b.studentnum)as studentnum,sum(b.total_money)as totalmoney,
sum(b.total_money*d.headerquarter_percentage)as groupmoney, 
sum(b.total_money*d.branch_percentage)as branchmoney, sum(b.total_money*d.jixiao_percentage)as jxmoney,
sum(b.total_money*d.shidao_percentage)as sdmoney, sum(b.total_money*d.wuxiang_percentage)as wxmoney 
from smp_income b left join  smp_clsexe a on (a.pk_clsexe=b.pk_clsexe)
left join smp_course d on (a.pk_course=d.pk_course) where b.income_time >= '2013-09-01' and b.income_time <= '2013-09-31'
group by a.pk_clsexe

select b.pk_clsexe as clsexe, sum(b.studentnum)as studentnum, sum(b.total_money)as totalmoney from smp_income_agent b
where b.income_time >= '2013-09-01' 
and b.income_time <= '2013-09-31' group by b.pk_clsexe
