select a.pk_agent as agentname, b.unitcode as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber,
sum(a.total_money)as totalmoney from smp_agent left join bd_corp b left join smp_income_agent a on (a.pk_branch=b.unitcode)
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >= '2013-09-01')
and c.class_start_date <= '2013-09-30'
group by b.unitcode, b.unitname, a.pk_clsexe, a.pk_agent order by b.unitcode, a.pk_agent


select a.pk_agent as agentname, b.unitcode as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber,
sum(a.total_money)as totalmoney from smp_agent d left join smp_income_agent a on (a.pk_agent=d.pk_agent) left join bd_corp b on (a.pk_branch=b.unitcode)
left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >= '2013-09-01')
and c.class_start_date <= '2013-09-30'
group by b.unitcode, b.unitname, a.pk_clsexe, a.pk_agent;

select a.pk_agent as agentname, a.name, b.pk_clsexe, sum(b.studentnum)as studennumber,sum(b.total_money)as totalmoney,
c.pk_corp as branchcode, c.unitname as branchname
from smp_agent a left join smp_income_agent b on (a.pk_agent=b.pk_agent) left join bd_corp c on (a.pk_branch=c.pk_corp)
where a.dr=0 group by a.pk_agent, a.name, b.pk_clsexe, c.pk_corp, c.unitname;

select * from smp_agent where dr=0;

select * from bd_corp;

update smp_income_agent set pk_branch='1005';
commit;

select * from smp_income_agent;
delete  from smp_income_agent;

insert into SMP_INCOME_AGENT (pk_incomeagent, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, pk_corp, pk_clsexe, studentnum, total_money, pk_branch, pk_agent, ts, dr)
values ('000235SWJKE00EF00001', null, null, null, null, null, null, null, null, null,'0001ZZ100000000004MR', 5, 1257.67, '0003', '0001ZZ10000000000JAL', '2013-09-10 00:44:36', 0);
insert into SMP_INCOME_AGENT (pk_incomeagent, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, pk_corp, pk_clsexe, studentnum, total_money, pk_branch, pk_agent, ts, dr)
values ('000235SWJKE00EF00002', null, null, null, null, null, null, null, null, null,'0001ZZ100000000004MR', 6, 3000.67, '0003', '0001ZZ10000000000JAL', '2013-09-10 00:44:36', 0);
commit;
