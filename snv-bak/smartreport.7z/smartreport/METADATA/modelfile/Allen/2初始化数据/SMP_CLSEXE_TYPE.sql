insert into smp_clsexe_type (PK_CLSEXE_TYPE, DAPPROVEDATE, VAPPROVENOTE, VAPPROVEID, VBILLSTATUS, VOPERATORID, VBILLNO, PK_BUSITYPE, VBUSICODE, PK_CORP, CODE, NAME, TS, DR)
values ('0002AA13DH00EF000001', null, null, null, null, null, null, null, null, null, 1, '��������', '2013-09-10 00:44:36', 0);

insert into smp_clsexe_type (PK_CLSEXE_TYPE, DAPPROVEDATE, VAPPROVENOTE, VAPPROVEID, VBILLSTATUS, VOPERATORID, VBILLNO, PK_BUSITYPE, VBUSICODE, PK_CORP, CODE, NAME, TS, DR)
values ('0002AA13DH00EF000002', null, null, null, null, null, null, null, null, null, 2, '��ѵ', '2013-09-10 00:44:36', 0);