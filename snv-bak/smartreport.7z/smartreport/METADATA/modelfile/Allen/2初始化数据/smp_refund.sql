insert into smp_refund (refundid, dapprovedate, vapprovenote, vapproveid, vbillstatus, voperatorid, vbillno, pk_busitype, vbusicode, dr, pk_corp, ts, pk_performance, refundamount, refunddate)
values ('000EHEA3DH0000000001', '', '', '', 1, '', '', '', '', 0, '', '2013-09-10 00:58:45', '0003AA13DH0000000002', 800, '2013-08-01');

