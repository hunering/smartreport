prompt Importing table sm_funcregister...
set feedback off
set define off
insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000000TP', null, '98H1', null, null, 0, '98H1', null, 2, '��������', 1, 0, null, 'N', 'N', 'N', null, 'N', null, '0001ZZ100000000000TO', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-20 22:00:38');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ10000000000NX7', 'nc.ui.smp.report.expensedetail.ClientUI', '98H101', null, null, 0, '98H101', null, 3, '������ñ���', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000000TP', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-14 18:51:52');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000015O3', 'nc.ui.smp.report.wperformance.ClientUI', '98H102', null, null, 0, '98H102', null, 3, '�ܼ�Ч����', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000000TP', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-20 22:00:38');

prompt Done.
prompt Importing table sm_funcregister...
set feedback off
set define off
insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000006Y3', null, '98H3', null, null, 0, '98H3', null, 2, '��������ά��', 1, 0, null, 'N', 'N', 'N', null, 'N', null, '0001ZZ100000000000TO', null, null, null, '0001ZZ100000000000TO', 1, '2013-10-07 11:11:35');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000006Y4', 'nc.ui.smp.coursetype.ClientUI', '98H301', null, null, 0, '98H301', null, 3, '�γ����ά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-09 21:38:50');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000006Y5', 'nc.ui.smp.course.ClientUI', '98H302', null, null, 0, '98H302', null, 3, '�γ�ά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-09 21:39:14');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000006Y6', 'nc.ui.smp.partner.ClientUI', '98H303', null, null, 0, '98H303', null, 3, '������ά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-09 21:39:40');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000006Y7', 'nc.ui.smp.team.ClientUI', '98H304', null, null, 0, '98H304', null, 3, '�Ŷ�ά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-09 21:41:36');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ10000000000CCN', 'nc.ui.smp.performance.ClientUI', '98H305', null, null, 0, '98H305', null, 3, 'ҵ������', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-10 21:27:13');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ10000000000G7G', 'nc.ui.smp.performance.ReportClientUI', '98H306', null, null, 0, '98H306', null, 3, 'ҵ����ϸ', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-12 20:45:47');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ10000000000GZ9', 'nc.ui.smp.expensetype.ClientUI', '98H307', null, null, 0, '98H307', null, 3, '�����������ά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-14 15:09:03');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ10000000000GZA', 'nc.ui.smp.expensedetail.ClientUI', '98H308', null, null, 0, '98H308', null, 3, '���������ϸά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-14 15:10:04');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ10000000001BUE', 'nc.ui.smp.incomeinput.ClientUI', '98H309', null, null, 0, '98H309', null, 3, '�ܼ�Ч����¼��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000006Y3', null, null, null, '0001ZZ100000000000TO', 1, '2013-10-07 11:11:35');

prompt Done.
prompt Importing table pub_query_templet...
set feedback off
set define off
insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ100000000006YH', null, '98H301', '�γ����Ͳ�ѯ', '98H301', '@@@@', null, '2013-09-09 21:45:21');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ100000000006Z1', null, '98H302', '�γ̲�ѯĩ��', '98H302', '@@@@', null, '2013-09-09 21:52:32');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ10000000000EO1', null, '98H303', '�������ѯ', '98H303', '@@@@', null, '2013-09-10 22:10:38');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ100000000006ZN', null, '98H304', '�ŶӲ�ѯģ��', '98H304', '@@@@', null, '2013-09-09 21:56:58');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ10000000000CD4', null, '98H305', 'ҵ����ѯģ��', '98H305', '@@@@', null, '2013-09-10 21:35:17');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ10000000000GZH', null, '98H307', '����������Ͳ�ѯ', '98H307', '@@@@', null, '2013-09-14 15:17:15');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ10000000000N5I', null, '98H308', '������ϸ��ѯ', '98H308', '@@@@', null, '2013-09-14 16:42:54');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ10000000001I0Q', null, '98H309', '�ܼ�Ч��ѯ', '98H309', '@@@@', null, '2013-10-07 15:14:21');

prompt Done.
prompt Importing table pub_query_condition...
set feedback off
set define off
insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_expensetype.expensecode', '���ñ��', null, '0001ZZ10000000000GZI', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000GZH', null, null, 0, null, null, '2013-09-14 15:17:15', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_expensetype.expensename', '��������', null, '0001ZZ10000000000GZJ', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000GZH', null, null, 0, null, null, '2013-09-14 15:17:15', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('SX,���۷���=XSFY,��������=GLFY,�������=CWFY', 6, 100, 0, null, 0, 'smp_expensetype.expensetype', '��������', null, '0001ZZ10000000000GZK', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000GZH', null, null, 0, null, null, '2013-09-14 15:17:15', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.agent_income', '����������', null, '0001ZZ10000000001I0R', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.agent_income_qj', '����������(ȫ��)', null, '0001ZZ10000000001I0S', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.agentfd', '�����̷���', null, '0001ZZ10000000001I0T', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.ftzbfy', '��̯�ܲ�����', null, '0001ZZ10000000001I0U', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.fytc', '����(���)', null, '0001ZZ10000000001I0V', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.qtywcb', '����ҵ��ɱ�', null, '0001ZZ10000000001I0W', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.qtywsr', '����ҵ������', null, '0001ZZ10000000001I0X', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.sdsfy', '����˰����', null, '0001ZZ10000000001I0Y', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.self_income', '��������', null, '0001ZZ10000000001I0Z', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.yywsz', 'Ӫҵ����֧', null, '0001ZZ10000000001I10', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.zyywcb', '��Ӫҵ��ɱ�', null, '0001ZZ10000000001I11', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.zyywsjjfj', '��Ӫҵ��˰�𼰸���', null, '0001ZZ10000000001I12', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 3, 100, 0, null, 0, 'smp_incomeinput.fydate', '��������', null, '0001ZZ10000000001I13', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('��˾Ŀ¼', 5, 100, 0, null, 0, 'smp_incomeinput.pk_corp', '��˾', null, '0001ZZ10000000001I14', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.xyysxsyj', '����Ԥ������ҵ��', null, '0001ZZ10000000001I15', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.xyyscwsr', '����Ԥ���������', null, '0001ZZ10000000001I16', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.ysxsyj', 'Ԥ������ҵ��', null, '0001ZZ10000000001I17', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_incomeinput.yscwsr', 'Ԥ���������', null, '0001ZZ10000000001I18', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000001I0Q', null, null, 0, null, null, '2013-10-07 15:14:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 3, 100, 0, null, 0, 'smp_expensedetail.t_year', '�������·�', null, '0001ZZ10000000000N5J', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000N5I', null, null, 0, null, null, '2013-09-14 16:42:54', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_expensedetail.amount', '���ý��', null, '0001ZZ10000000000N5K', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000N5I', null, null, 0, null, null, '2013-09-14 16:42:54', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('<nc.ui.smp.expensetype.ExpenseTypeModel>', 5, 100, 0, null, 0, 'smp_expensedetail.pk_expensetype', '��������', null, '0001ZZ10000000000N5L', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000N5I', null, null, 0, null, null, '2013-09-14 16:42:54', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_coursetype.coursetypename', '�γ���������', null, '0001ZZ100000000006YI', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006YH', null, null, 0, null, null, '2013-09-09 21:45:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_coursetype.pk_corp', '��˾����', null, '0001ZZ100000000006YJ', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006YH', null, null, 0, null, null, '2013-09-09 21:45:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_coursetype.voperatorid', '������', null, '0001ZZ100000000006YK', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006YH', null, null, 0, null, null, '2013-09-09 21:45:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_coursetype.ts', 'ʱ���', null, '0001ZZ100000000006YL', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006YH', null, null, 0, null, null, '2013-09-09 21:45:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_coursetype.dr', 'ɾ����ʶ', null, '0001ZZ100000000006YM', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006YH', null, null, 0, null, null, '2013-09-09 21:45:21', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_course.course_code', '�γ̱���', null, '0001ZZ100000000006Z2', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('<nc.ui.smp.coursetype.CourseTypeModel>', 5, 100, 0, null, 0, 'smp_course.pk_coursetype', '�γ���������', null, '0001ZZ100000000006Z3', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_course.course_name', '�γ�����', null, '0001ZZ100000000006Z4', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_course.headerquarter_percentage', '�ܲ���ֱ���', null, '0001ZZ100000000006Z5', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_course.jixiao_percentage', '��Ч��ֱ���', null, '0001ZZ100000000006Z6', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_course.shidao_percentage', 'ʦ����ҵ����ֱ���', null, '0001ZZ100000000006Z7', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_course.branch_percentage', '�ֹ�˾��ֱ���', null, '0001ZZ100000000006Z8', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_course.agency_percentage', '�����̲�ֱ���', null, '0001ZZ100000000006Z9', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 9, 100, 0, null, 0, 'smp_course.remark', '��ע', null, '0001ZZ100000000006ZA', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006Z1', null, null, 0, null, null, '2013-09-09 21:52:32', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_team.team_name', '�Ŷ�����', null, '0001ZZ100000000006ZO', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006ZN', null, null, 0, null, null, '2013-09-09 21:56:58', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('��Ա��������', 5, 100, 0, null, 0, 'smp_team.pk_director', '�Ŷ��ܼ�', null, '0001ZZ100000000006ZP', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006ZN', null, null, 0, null, null, '2013-09-09 21:56:58', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_team.team_director_name', '�Ŷ��ܼ�����', null, '0001ZZ100000000006ZQ', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ100000000006ZN', null, null, 0, null, null, '2013-09-09 21:56:58', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 6, 100, 0, null, 0, 'smp_performance.achievetype', 'ҵ������', null, '0001ZZ10000000000CD5', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_performance.crm_remit_number', 'CRM����', null, '0001ZZ10000000000CD6', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('<nc.ui.smp.team.TeamModel>', 5, 100, 0, null, 0, 'smp_performance.director_id', '�Ŷ��ܼ�', null, '0001ZZ10000000000CD7', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 3, 100, 0, null, 0, 'smp_performance.performance_date', 'ҵ������', null, '0001ZZ10000000000CD8', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_performance.pk_course', '�γ�����', null, '0001ZZ10000000000CD9', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('<nc.ui.smp.partner.PartnerModel>', 5, 100, 0, null, 0, 'smp_performance.pk_partner', '�������', null, '0001ZZ10000000000CDA', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('<nc.ui.smp.team.TeamModel>', 5, 100, 0, null, 0, 'smp_performance.pk_team', '�Ŷ�����', null, '0001ZZ10000000000CDB', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 'smp_performance.remit_amount', '�����', null, '0001ZZ10000000000CDC', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_performance.remit_company', '��˾', null, '0001ZZ10000000000CDD', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_performance.remit_name', '�����', null, '0001ZZ10000000000CDE', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000CD4', null, null, 0, null, null, '2013-09-10 21:35:17', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 'smp_partner.partner_name', '�����������', null, '0001ZZ10000000000EO2', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000EO1', null, null, 0, null, null, '2013-09-10 22:10:38', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('<nc.ui.smp.team.TeamModel>', 5, 100, 0, null, 0, 'smp_partner.pk_team', '�Ŷ�����', null, '0001ZZ10000000000EO3', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ10000000000EO1', null, null, 0, null, null, '2013-09-10 22:10:38', null, null);

prompt Done.
prompt Importing table pub_systemplate...
set feedback off
set define off
insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H301', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033I', null, 'Y', '0001ZZ100000000006YA', 0, '2013-09-10 21:49:15');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H301', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033J', null, 'Y', '0001ZZ100000000006YH', 1, '2013-09-10 21:49:15');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H302', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033F', null, 'Y', '0001ZZ100000000006ZD', 0, '2013-09-10 21:48:26');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H302', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033G', null, 'Y', '0001ZZ100000000006Z1', 1, '2013-09-10 21:48:26');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H303', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033D', null, 'Y', '0001ZZ100000000006ZD', 0, '2013-09-10 21:48:13');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H303', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033E', null, 'Y', '0001ZZ100000000006ZG', 1, '2013-09-10 21:48:13');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H304', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033B', null, 'Y', '0001ZZ100000000006ZD', 0, '2013-09-10 21:47:59');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H304', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033C', null, 'Y', '0001ZZ100000000006ZN', 1, '2013-09-10 21:47:59');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H305', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000339', null, 'Y', '0001ZZ10000000000CCS', 0, '2013-09-10 21:47:45');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H305', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000033A', null, 'Y', '0001ZZ10000000000CD4', 1, '2013-09-10 21:47:45');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H306', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000003UX', null, 'Y', '0001ZZ10000000000G7I', 2, '2013-09-12 21:02:13');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H307', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000004MP', null, 'Y', '0001ZZ10000000000GZC', 0, '2013-09-14 15:22:27');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H307', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000004MQ', null, 'Y', '0001ZZ10000000000GZH', 1, '2013-09-14 15:22:27');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H308', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000669', null, 'Y', '0001ZZ10000000000GZL', 0, '2013-09-14 16:43:18');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H308', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ1000000000066A', null, 'Y', '0001ZZ10000000000N5I', 1, '2013-09-14 16:43:18');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H309', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ10000000000A15', null, 'Y', '0001ZZ10000000001I0Q', 1, '2013-10-07 15:33:45');

prompt Done.
prompt Importing table pub_systemplate...
set feedback off
set define off
insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H101', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000006Y1', null, 'Y', '0001ZZ10000000000U3I', 2, '2013-09-20 10:21:28');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H102', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000008HL', null, 'Y', '0001ZZ100000000015O6', 2, '2013-09-21 10:59:05');

prompt Done.
prompt Importing table PUB_REPORT_MODEL...
set feedback off
set define off
insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'SNO', '���', 0, '���', 80, 1, 0, null, null, 'Y', 'N', 'N', null, 'N', 1, '98H306', null, null, '@@@@', '0001ZZ10000000000G7J', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'MONTH', '��', 0, '��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 2, '98H306', null, null, '@@@@', '0001ZZ10000000000G7K', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'WEEK', '��', 0, '��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 3, '98H306', null, null, '@@@@', '0001ZZ10000000000G7L', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'STUDENT', 'ѧԱ��', 0, 'ѧԱ��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 4, '98H306', null, null, '@@@@', '0001ZZ10000000000G7M', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'COMPANY', '��˾�������', 0, '��˾�������', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 5, '98H306', null, null, '@@@@', '0001ZZ10000000000G7N', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'COMPANY_FULLNAME', '��˾ȫ��', 0, '��˾ȫ��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 6, '98H306', null, null, '@@@@', '0001ZZ10000000000G7O', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'CARDNO', 'ˢ������', 0, 'ˢ������', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 7, '98H306', null, null, '@@@@', '0001ZZ10000000000G7P', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'DATE', '������ڣ������գ�', 0, '������ڣ������գ�', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 8, '98H306', null, null, '@@@@', '0001ZZ10000000000G7Q', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'ACCOUNT', '����˻�', 0, '����˻�', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 9, '98H306', null, null, '@@@@', '0001ZZ10000000000G7R', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'XDCGMC', '�ж��ɹ���˾����', 0, '�ж��ɹ���˾����', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 10, '98H306', null, null, '@@@@', '0001ZZ10000000000G7S', '0001ZZ10000000000G7I', 1, null, null, 1, '2013-09-12 20:57:17', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'expenseCode', '���', 0, '���', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 2, '98H101', null, null, '@@@@', '0001ZZ10000000000U3K', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'expenseName', '��Ŀ', 0, '��Ŀ', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 3, '98H101', null, null, '@@@@', '0001ZZ10000000000U3L', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'yearSum', '�����ۼ�', 0, '�����ۼ�', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 4, '98H101', null, null, '@@@@', '0001ZZ10000000000U3M', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'janSum', '1��', 0, '1��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 5, '98H101', null, null, '@@@@', '0001ZZ10000000000U3N', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'febSum', '2��', 0, '2��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 6, '98H101', null, null, '@@@@', '0001ZZ10000000000U3O', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'matSum', '3��', 0, '3��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 7, '98H101', null, null, '@@@@', '0001ZZ10000000000U3P', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'aprSum', '4��', 0, '4��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 8, '98H101', null, null, '@@@@', '0001ZZ10000000000U3Q', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'maySum', '5��', 0, '5��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 9, '98H101', null, null, '@@@@', '0001ZZ10000000000U3R', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'junSum', '6��', 0, '6��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 10, '98H101', null, null, '@@@@', '0001ZZ10000000000U3S', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'julSum', '7��', 0, '7��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 11, '98H101', null, null, '@@@@', '0001ZZ10000000000U3T', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'augSum', '8��', 0, '8��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 12, '98H101', null, null, '@@@@', '0001ZZ10000000000U3U', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'sepSum', '9��', 0, '9��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 13, '98H101', null, null, '@@@@', '0001ZZ10000000000U3V', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'octSum', '10��', 0, '10��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 14, '98H101', null, null, '@@@@', '0001ZZ10000000000U3W', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'novSum', '11��', 0, '11��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 15, '98H101', null, null, '@@@@', '0001ZZ10000000000U3X', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'decSum', '12��', 0, '12��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 16, '98H101', null, null, '@@@@', '0001ZZ10000000000U3Y', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'expenseType', '��������', 0, '��������', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 1, '98H101', null, null, '@@@@', '0001ZZ100000000011T9', '0001ZZ10000000000U3I', 1, null, null, 1, '2013-09-20 16:49:33', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'itemcode', '��Ŀ', 0, '��Ŀ', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 1, '98H102', null, null, '@@@@', '0001ZZ100000000015O7', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'wamount', '�����ۼ�', 0, '�����ۼ�', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 2, '98H102', null, null, '@@@@', '0001ZZ100000000015O8', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'fweek', '��һ��', 0, '��һ��', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 3, '98H102', null, null, '@@@@', '0001ZZ100000000015O9', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'sweek', '�ڶ���', 0, '�ڶ���', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 4, '98H102', null, null, '@@@@', '0001ZZ100000000015OA', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'tweek', '������', 0, '������', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 5, '98H102', null, null, '@@@@', '0001ZZ100000000015OB', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'ftweek', '������', 0, '������', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 6, '98H102', null, null, '@@@@', '0001ZZ100000000015OC', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

insert into PUB_REPORT_MODEL (COL_EXPRESSIONS, COLUMN_CODE, COLUMN_SYSTEM, COLUMN_TYPE, COLUMN_USER, COLUMN_WIDTH, DATA_TYPE, DR, GROUP_ORDER, IDCOLNAME, IF_DEFAULT, IF_MUST, IF_NO, IF_SUM, IS_THMARK, ITEM_ORDER, NODE_CODE, ORDER_ORDER, ORDER_TYPE, PK_CORP, PK_MODEL, PK_TEMPLET, REPORT_POS, RESID_SYSTEM, RESID_USER, SELECT_TYPE, TS, USERDEFFLAG)
values (null, 'fiweek', '������', 0, '������', 80, 0, 0, null, null, 'Y', 'N', 'N', null, 'N', 7, '98H102', null, null, '@@@@', '0001ZZ100000000015OD', '0001ZZ100000000015O6', 1, null, null, 1, '2013-10-07 14:22:10', null);

prompt Done.
prompt Importing table PUB_REPORT_TEMPLET...
set feedback off
set define off
insert into PUB_REPORT_TEMPLET (DESCRIBE, DR, NODE_CODE, NODE_NAME, PARENT_CODE, PK_CORP, PK_TEMPLET, PRINTINFO, RESID, SUBHEAD, TS)
values (null, 0, '98H30600', 'ҵ����ϸ', '98H306', '@@@@', '0001ZZ10000000000G7I', null, null, null, '2013-09-12 20:57:17');

insert into PUB_REPORT_TEMPLET (DESCRIBE, DR, NODE_CODE, NODE_NAME, PARENT_CODE, PK_CORP, PK_TEMPLET, PRINTINFO, RESID, SUBHEAD, TS)
values (null, 0, '98H10100', '������ñ���', '98H101', '@@@@', '0001ZZ10000000000U3I', null, null, null, '2013-09-20 10:15:17');

insert into PUB_REPORT_TEMPLET (DESCRIBE, DR, NODE_CODE, NODE_NAME, PARENT_CODE, PK_CORP, PK_TEMPLET, PRINTINFO, RESID, SUBHEAD, TS)
values (null, 0, '98H10200', '�ܼ�Ч����', '98H102', '@@@@', '0001ZZ100000000015O6', null, null, null, '2013-09-20 21:59:43');

prompt Done.
