/*==============================================================*/
/* DBMS name:      ORACLE Version 10g                           */
/* Created on:     2013/9/25 14:08:52                           */
/*==============================================================*/


drop table SMP_BILLTEST cascade constraints;

drop table SMP_COURSE cascade constraints;

drop table SMP_COURSETYPE cascade constraints;

drop table SMP_EXPENSEDETAIL cascade constraints;

drop table SMP_EXPENSETYPE cascade constraints;

drop table SMP_PARTNER cascade constraints;

drop table SMP_PERFORMANCE cascade constraints;

drop table SMP_REFUND cascade constraints;

drop table smp_team cascade constraints;

/*==============================================================*/
/* Table: SMP_BILLTEST                                          */
/*==============================================================*/
create table SMP_BILLTEST  (
   pk_billtest          VARCHAR2(50)                    not null,
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   constraint PK_SMP_BILLTEST primary key (pk_billtest)
);

/*==============================================================*/
/* Table: SMP_COURSE                                            */
/*==============================================================*/
create table SMP_COURSE  (
   pk_course            VARCHAR2(50)                    not null,
   course_name          VARCHAR2(50)                    not null,
   voperatorid          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   pk_coursetype        VARCHAR2(50),
   reserved2            VARCHAR2(100),
   reserved1            VARCHAR2(100),
   reserved3            VARCHAR2(100),
   reserved4            VARCHAR2(100),
   reserverd5           VARCHAR2(100),
   remark               VARCHAR2(200),
   agency_percentage    NUMBER(10),
   shidao_percentage    NUMBER(10),
   jixiao_percentage    NUMBER(10),
   branch_percentage    NUMBER(10),
   headerquarter_percentage NUMBER(10),
   course_code          CHAR(20)                        not null,
   constraint PK_SMP_COURSE primary key (pk_course)
);

/*==============================================================*/
/* Table: SMP_COURSETYPE                                        */
/*==============================================================*/
create table SMP_COURSETYPE  (
   pk_coursetype        VARCHAR2(50)                    not null,
   coursetypename       VARCHAR2(50)                    not null,
   voperatorid          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   constraint PK_SMP_COURSETYPE primary key (pk_coursetype)
);

/*==============================================================*/
/* Table: SMP_EXPENSEDETAIL                                     */
/*==============================================================*/
create table SMP_EXPENSEDETAIL  (
   pk_expensedetail     VARCHAR2(20)                    not null,
   expensecode          VARCHAR2(50),
   expensename          VARCHAR2(50),
   expensetype          VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   t_year               CHAR(19),
   amount               NUMBER(20,8),
   pk_expensetype       VARCHAR2(50),
   constraint PK_SMP_EXPENSEDETAIL primary key (pk_expensedetail)
);

/*==============================================================*/
/* Table: SMP_EXPENSETYPE                                       */
/*==============================================================*/
create table SMP_EXPENSETYPE  (
   pk_expensetype       VARCHAR2(20)                    not null,
   expensecode          VARCHAR2(50)                    not null,
   expensename          VARCHAR2(50),
   expensetype          VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   constraint PK_SMP_EXPENSETYPE primary key (pk_expensetype)
);

/*==============================================================*/
/* Table: SMP_PARTNER                                           */
/*==============================================================*/
create table SMP_PARTNER  (
   pk_partner           CHAR(20)                        not null,
   partner_name         VARCHAR2(100),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   voperatorid          VARCHAR2(50),
   pk_team              VARCHAR2(50),
   constraint PK_SMP_PARTNER primary key (pk_partner)
);

/*==============================================================*/
/* Table: SMP_PERFORMANCE                                       */
/*==============================================================*/
create table SMP_PERFORMANCE  (
   pk_performance       CHAR(20)                        not null,
   performance_date     VARCHAR2(100),
   pk_course            VARCHAR2(50),
   remit_name           VARCHAR2(100),
   remit_company        VARCHAR2(100),
   remit_amount         NUMBER(20,8),
   pk_team              VARCHAR2(50),
   director_id          VARCHAR2(100),
   crm_remit_number     VARCHAR2(100),
   pk_partner           VARCHAR2(100),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   voperatorid          VARCHAR2(50),
   achievetype          NUMBER(10),
   constraint PK_SMP_PERFORMANCE primary key (pk_performance)
);

/*==============================================================*/
/* Table: SMP_REFUND                                            */
/*==============================================================*/
create table SMP_REFUND  (
   refundid             VARCHAR2(20)                    not null,
   dapprovedate         CHAR(10),
   vapprovenote         VARCHAR2(50),
   vapproveid           VARCHAR2(50),
   vbillstatus          NUMBER(38),
   voperatorid          VARCHAR2(50),
   vbillno              VARCHAR2(50),
   pk_busitype          VARCHAR2(50),
   vbusicode            VARCHAR2(50),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   pk_performance       VARCHAR2(50),
   refundamount         VARCHAR2(50),
   refundreason         VARCHAR2(50),
   constraint PK_SMP_REFUND primary key (refundid)
);

/*==============================================================*/
/* Table: smp_team                                              */
/*==============================================================*/
create table smp_team  (
   pk_team              CHAR(20)                        not null,
   team_name            VARCHAR2(100),
   pk_director          CHAR(20),
   team_director_name   VARCHAR2(100),
   ts                   CHAR(19)                       default to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'),
   dr                   NUMBER(10)                     default 0,
   pk_corp              VARCHAR2(50),
   voperatorid          VARCHAR2(50),
   constraint PK_SMP_TEAM primary key (pk_team)
);

