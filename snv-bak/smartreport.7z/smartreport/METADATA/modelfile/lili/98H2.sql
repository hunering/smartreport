prompt Importing table sm_funcregister...
set feedback off
set define off
insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000000TQ', null, '98H2', null, null, 0, '98H2', null, 2, '���ݹ���', 1, 0, null, 'N', 'N', 'N', null, 'N', null, '0001ZZ100000000000TO', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-08 17:58:11');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000000TR', 'nc.ui.smp.refund.ClientUI', '98H201', null, null, 0, '98H201', null, 3, '�˿����', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000000TQ', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-08 16:47:19');

insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000001SL', 'nc.ui.smp.coursetype.ClientUI', '98H202', null, null, 0, '98H202', null, 3, '�γ�����ά��', 0, 0, null, 'N', 'N', 'N', null, 'N', '1', '0001ZZ100000000000TQ', null, null, null, '0001ZZ100000000000TO', 1, '2013-09-08 17:58:11');

prompt Done.

prompt Importing table pub_query_templet...
set feedback off
set define off
insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '1001ZZ100000000001KS', null, '98H201', '�˿������ѯ', '98H201', '@@@@', null, '2013-09-08 20:23:00');

insert into pub_query_templet (DESCRIBE, DR, FIXCONDITION, ID, METACLASS, MODEL_CODE, MODEL_NAME, NODE_CODE, PK_CORP, RESID, TS)
values (null, 0, null, '0001ZZ1000000000033B', null, '98H202', '�γ����Ͳ�ѯ', '98H202', '@@@@', null, '2013-09-08 18:24:30');

prompt Done.
prompt Importing table pub_systemplate...
set feedback off
set define off
insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H201', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000001JL', null, 'Y', '0001ZZ100000000000V1', 0, '2013-09-08 20:24:30');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H201', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000001JM', null, 'Y', '1001ZZ100000000001KS', 1, '2013-09-08 20:24:30');

insert into pub_systemplate (DR, FUNNODE, ISCOMM, NODEKEY, OPERATOR, OPERATOR_TYPE, ORGTYPECODE, PK_BUSITYPE, PK_CORP, PK_ORG, PK_SYSTEMPLATE, SYSFLAG, TEMPLATEFLAG, TEMPLATEID, TEMPSTYLE, TS)
values (0, '98H202', null, null, null, null, null, null, '@@@@', null, '@@@@ZZ100000000000RT', null, 'Y', '0001ZZ100000000001SN', 0, '2013-09-08 18:00:38');

prompt Done.
prompt Importing table pub_query_condition...
set feedback off
set define off
insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 3, 100, 0, null, 0, 't_refund.dapprovedate', '��������', null, '1001ZZ100000000001KT', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 2, 100, 0, null, 0, 't_refund.dr', 'ɾ����ʶ', null, '1001ZZ100000000001KU', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.pk_busitype', 'ҵ����������', null, '1001ZZ100000000001KV', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('��˾Ŀ¼', 5, 100, 0, null, 0, 't_refund.pk_corp', '��˾����', null, '1001ZZ100000000001KW', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.pk_performance', 'ҵ������', null, '1001ZZ100000000001KX', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.refundamount', '�˿���', null, '1001ZZ100000000001KY', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.refundid', '����', null, '1001ZZ100000000001KZ', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.refundreason', '�˿�ԭ��', null, '1001ZZ100000000001L0', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.ts', 'ʱ���', null, '1001ZZ100000000001L1', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('����Ա', 5, 100, 0, null, 0, 't_refund.vapproveid', '������', null, '1001ZZ100000000001L2', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.vbillno', '���ݱ��', null, '1001ZZ100000000001L3', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 6, 100, 0, null, 0, 't_refund.vbillstatus', '����״̬', null, '1001ZZ100000000001L4', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_refund.vbusicode', 'ҵ��', null, '1001ZZ100000000001L5', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('����Ա', 5, 100, 0, null, 0, 't_refund.voperatorid', '������', null, '1001ZZ100000000001L6', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 9, 100, 0, null, 0, 't_refund.vapprovenote', '��������', null, '1001ZZ100000000001L7', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '1001ZZ100000000001KS', null, null, 0, null, null, '2013-09-08 20:23:00', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_coursetype.coursetypename', '�γ���������', null, '0001ZZ1000000000033C', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ1000000000033B', null, null, 0, null, null, '2013-09-08 18:24:30', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_coursetype.pk_coursetype', '����', null, '0001ZZ1000000000033D', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ1000000000033B', null, null, 0, null, null, '2013-09-08 18:24:30', null, null);

insert into pub_query_condition (CONSULT_CODE, DATA_TYPE, DISP_SEQUENCE, DISP_TYPE, DISP_VALUE, DR, FIELD_CODE, FIELD_NAME, GUIDELINE, ID, IF_AUTOCHECK, IF_DATAPOWER, IF_DEFAULT, IF_DESC, IF_GROUP, IF_IMMOBILITY, IF_MUST, IF_ORDER, IF_SUM, IF_USED, INSTRUMENTSQL, ISCONDITION, MAX_LENGTH, OPERA_CODE, OPERA_NAME, ORDER_SEQUENCE, PK_CORP, PK_TEMPLET, PRERESTRICT, RESID, RETURN_TYPE, TABLE_CODE, TABLE_NAME, TS, USERDEFFLAG, VALUE)
values ('-99', 0, 100, 0, null, 0, 't_coursetype.ts', 'ʱ���', null, '0001ZZ1000000000033E', 'N', 'N', 'Y', null, 'N', 'N', 'N', 'N', 'N', 'Y', null, 'Y', null, '=@>@>=@<@<=@like@', '����@����@���ڵ���@С��@С�ڵ���@����@', 0, '@@@@', '0001ZZ1000000000033B', null, null, 0, null, null, '2013-09-08 18:24:30', null, null);

prompt Done.
