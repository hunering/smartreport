prompt Importing table sm_funcregister...
set feedback off
set define off
insert into sm_funcregister (CFUNID, CLASS_NAME, DISP_CODE, DR, DS_NAME, FORBID_FLAG, FUN_CODE, FUN_DESC, FUN_LEVEL, FUN_NAME, FUN_PROPERTY, GROUP_FLAG, HELP_NAME, ISBUTTONPOWER, ISHASPARA, ISNEEDBUTTONLOG, KEYFUNC, MODULETYPE, ORGTYPECODE, PARENT_ID, PK_CORP, RESID, SHORTCUTCODE, SUBSYSTEM_ID, SYSTEM_FLAG, TS)
values ('0001ZZ100000000000TO', null, '98', null, null, 0, '98', null, 1, '�ж��ɹ�', 1, 0, null, 'N', 'N', 'N', null, 'N', null, null, null, null, null, '0001ZZ100000000000TO', 1, '2013-09-20 22:00:38');

prompt Done.
