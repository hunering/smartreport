select * from smp_cost;

select * from smp_income;

select a.pk_clsexe, sum(b.studentnum)as studennumber,sum(b.total_money)as totalmoney from smp_clsexe a left join  smp_income b 
on (a.pk_clsexe=b.pk_clsexe and a.class_start_date >= '2013-09-01' and a.class_start_date <= '2013-09-30') group by a.pk_clsexe

select a.pk_clsexe, a.title as clsexe, sum(b.studentnum)as studentum,sum(b.total_money)as totalmoney, sum(c.meeting_cost) as meetingcost,
sum(c.teacher_cost)as teachercost, sum(c.project_cost) as projectcost from smp_clsexe a left join  smp_income b
on (a.pk_clsexe=b.pk_clsexe and a.class_start_date >= '2013-09-01' and a.class_start_date <= '2013-09-30') 
left join smp_cost c on (a.pk_clsexe=c.pk_clsexe) group by a.pk_clsexe, a.title

select * from smp_clsexe_type;
