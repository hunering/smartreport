
select * from sm_funcregister  where fun_code like '98H2%';
select * from bd_billtype  where pk_billtypecode like 'SP%';
select * from pub_billcode_rule where pk_billtypecode like 'SP%';

select * from pub_billaction where pk_billtype like 'SP%';
select * from pub_busiclass where pk_billtype like 'SP%';
select * from pub_votable where pk_billtype like 'SP%';
select * from pub_billtobillrefer where billtype like 'SP%';

select * from pub_billtemplet where pk_billtypecode like 'SP%';
select * from pub_billtemplet_b where pk_billtemplet in(select pk_billtemplet from pub_billtemplet where pk_billtypecode like 'SP%');
select * from pub_billtemplet_t where pk_billtemplet in(select pk_billtemplet from pub_billtemplet where pk_billtypecode like 'SP%');


select * from pub_query_condition where pk_templet in(select id from pub_query_templet where node_code like '98H2%');

select * from pub_systemplate where funnode like '98H2%';
select * from dap_defitem where pk_billtype like 'SP%';
select * from pub_function where pk_billtype LIKE 'SP%' and functionnote like '98H2%';

SELECT * FROM PUB_REPORT_GROUP
SELECT * FROM PUB_REPORT_MODEL WHERE NODE_CODE LIKE '98H2%' 
SELECT * FROM PUB_REPORT_TEMPLET WHERE NODE_CODE LIKE '98H2%'
select * from tabs where table_name like '%REPORT%'