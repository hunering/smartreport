package nc.itf.smp;
import nc.vo.pub.BusinessException;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.detail.DetailQueryVO;
import nc.vo.smp.report.detail.DetailReportVO;


/**
 * �����ӿ�
 * @author LINQI
 *
 */
public interface ISMPReport {

	public DetailReportVO[] getDetailData(DetailQueryVO queryVO) throws BusinessException;
	
	public CourseVO[] getCourseVO(String str) throws BusinessException;
	
	
}
