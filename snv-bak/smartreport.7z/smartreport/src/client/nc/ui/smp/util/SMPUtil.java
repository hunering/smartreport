package nc.ui.smp.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class SMPUtil {
	public static Date getFirstDayOfCurrentMonth(Date theDate) {
		// FirstDayOfCurrentMonth();
		// nc.lfw.querytemplate.sysfunc.SysFunctionUtil.
		Calendar cal = new GregorianCalendar();
		cal.setTime(theDate);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);		
		return cal.getTime();
	}
	
	static public Date getLastDayOfCurrentMonth(Date theDate) {
		Calendar cal = new GregorianCalendar();
		cal.setTime(theDate);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		cal.set(Calendar.HOUR, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);		
		return cal.getTime();
	}
}
