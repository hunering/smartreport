package nc.ui.smp.report.income;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReport;
import nc.ui.pub.ButtonObject;
import nc.ui.pub.beans.UIDialog;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.report.ReportBaseClass;
import nc.ui.pub.report.ReportItem;
import nc.ui.report.base.ReportUIBase;
import nc.vo.logging.Debug;
import nc.vo.pub.BusinessException;
import nc.vo.pub.lang.UFDouble;
import nc.vo.smp.clsexe.ClsexeVO;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.income.AgentIncomeReportVO;
import nc.vo.smp.report.income.ClsexeIncomePerBranch;
import nc.vo.smp.report.income.IncomeQueryVO;
import nc.vo.smp.report.income.IncomeReportVO;

/**
 * ͳ����ϸ��
 * @author LINQI
 *
 */
public class AgentIncomeReportUI extends ReportUIBase{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private IncomeQueryVO qryVo;		//��ѯ����
	private IncomeReportQueryDlg qryDlg;//��ѯ�Ի���
	private ReportItem[] dynamicItems;	//��̬��
	private Map<String, CourseVO> courseMap = new HashMap<String, CourseVO>();
	ReportItem[] fixedItems; // ����ģ��Ĭ�Ϻ��е���
	
	public AgentIncomeReportUI(){
		super();
		init();
	}
	
	public void init(){
		
		reBuildButtons();
		getConditionPanel().setVisible(false);	//ȥ����ͷ��ѯ����
		this.getReportBase().showZeroLikeNull(false);
		this.getReportBase().setTatolRowShow(false);
		buildCourseVO();	
		fixedItems = this.getReportBase().getBody_Items();
	}
	
	protected void buildCourseVO() {
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		CourseVO[] vos;
		try {
			vos = sv.getCourseVO(null);
			for(int i=0;i<vos.length;i++){
				courseMap.put(vos[i].getPk_course(), vos[i]);
			}
		} catch (BusinessException e) {
				e.printStackTrace();
				Debug.error("��ȡCourseVO�����쳣��");
			}
	}
	
	/**
	 * ȥ������Ҫ�İ�ť
	 */
	protected void reBuildButtons(){
		ButtonObject[] btns = this.getButtons();
		for(ButtonObject btn : btns){
			if(!btn.getName().equals("��ѯ") && !btn.getName().equals("��ӡ"))
				this.unRegisterButton(btn);
		}
		this.updateAllButtons();
	}
	
	/**
	 * ��ȡ��̬��
	 * @return
	 */
	protected ReportItem[] getDynamicColumns(){
		
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		try {
			ClsexeVO[] vos = sv.getClsexeVO(qryVo);
			if(vos!=null && vos.length>0){
				dynamicItems = new ReportItem[vos.length];
				for(int i=0;i<vos.length;i++){
					dynamicItems[i] = new ReportItem();
					dynamicItems[i].setKey(vos[i].getPk_clsexe());
					dynamicItems[i].setName(vos[i].getTitle());
					dynamicItems[i].setDataType(BillItem.STRING);
					dynamicItems[i].setWidth(80);
					dynamicItems[i].setShowOrder(20+i);	//��20��ʼ����
				}
			}
		}catch (BusinessException e) {
				e.printStackTrace();
				Debug.error("��ȡ��̬�з����쳣��");
			}
		
		
		return dynamicItems;
	}
	
	@Override
	protected void initColumnGroups() {
		// TODO Auto-generated method stub
		super.initColumnGroups();
	}

	@Override
	public void onButtonClicked(ButtonObject arg0) {
		// TODO Auto-generated method stub
		super.onButtonClicked(arg0);
	}
	
	@Override
	public void onQuery() throws BusinessException {
		
		int act = this.getQueryDlg().showModal();
		if (act == UIDialog.ID_CANCEL) {
			return;
		}
		qryVo = getQueryDlg().getQryVo();
		ReportItem[] items = getDynamicColumns();		//��̬��
		if(items!=null && items.length>0){
			//ReportItem[] currtItems = this.getReportBase().getBody_Items();		//��ǰ��
			ReportItem[] newItems = new ReportItem[items.length+fixedItems.length];		//ƴװ���µ���			
			System.arraycopy(fixedItems, 0, newItems, 0, 2);
			System.arraycopy(items, 0, newItems, 2, items.length);
			System.arraycopy(fixedItems, 2, newItems, items.length+2, fixedItems.length-2);

			this.getReportBase().setBody_Items(newItems);	//���ñ�����
		}

		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		
		AgentIncomeReportVO[] agentIncomeReportVOs = sv.getAgentIncomeData(qryVo);
		setBodyData(agentIncomeReportVOs);
	}
	
	/**
	 * ���ñ�������
	 * @param vos
	 */
	public void setBodyData(AgentIncomeReportVO[] agentIncomeReportVOs){
		ReportBaseClass reportBase = this.getReportBase();
		reportBase.getBillModel().clearBodyData();
		for(int i=0;i<agentIncomeReportVOs.length;i++) {
			String fields[] = agentIncomeReportVOs[i].getAttributeNames();
			for(String field:fields){
				if(field.equals("branchname")) {
					reportBase.getBillData().addLine();
					this.getReportBase().setBodyValueAt(agentIncomeReportVOs[i].getAttributeValue(field), i, field);				
				} else if (field.equals("agentname")) {
					this.getReportBase().setBodyValueAt(agentIncomeReportVOs[i].getAttributeValue(field), i, field);
				} else if(field.equals("summationperagent")) {
					ClsexeIncomePerBranch summationPerBranch = (ClsexeIncomePerBranch)agentIncomeReportVOs[i].getAttributeValue(field);
					this.getReportBase().setBodyValueAt(summationPerBranch.getTotalMoney(), i, "total_income_perclsexe");;
				} else {
					ClsexeIncomePerBranch clsexePerBranch = (ClsexeIncomePerBranch)agentIncomeReportVOs[i].getAttributeValue(field);
					StringBuilder sb = new StringBuilder();
					sb.append("������");
					sb.append(clsexePerBranch.getStudentNum());
					sb.append("; ��");
					sb.append(clsexePerBranch.getTotalMoney());
					this.getReportBase().setBodyValueAt(sb.toString(), i, clsexePerBranch.getPk_clsexe());
				}
			}
		

			//reportBase.setBodyValueAt(incomeVOs[i], i, strKey);			
		}
	}
	
	private void applyIncomeReportVO(IncomeReportVO incomeVO) {
		ReportItem[] currtItems = this.getReportBase().getBody_Items();
	}
	
	public IncomeReportQueryDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new IncomeReportQueryDlg(this);
		}
		return qryDlg;
	}

	public String getModuleCode() {
		return "98H261";
	}
}
