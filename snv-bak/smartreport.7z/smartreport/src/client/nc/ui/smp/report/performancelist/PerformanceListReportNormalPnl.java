/**
 * 
 */
package nc.ui.smp.report.performancelist;

import java.awt.Dimension;
import java.awt.LayoutManager;
import javax.swing.SpinnerModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;

import nc.ui.pub.ClientEnvironment;
import nc.ui.pub.beans.UILabel;
import nc.ui.pub.beans.UIPanel;
import nc.ui.pub.beans.UIRefPane;
import nc.ui.pub.beans.UISpinner;
import nc.ui.smp.pub.UIComponentFactory;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDateTime;

/**
 * 
 * @author Allen
 *
 */
public class PerformanceListReportNormalPnl extends UIPanel {

	private static final long serialVersionUID = -3129827417647467318L;
	
	private UILabel lblStartDate;		//��ʼ����
	private UIRefPane refStartDate;
	private UISpinner  startHourSpin;
	private UISpinner  startMinuteSpin;
	private UISpinner  startSecondSpin;	
	
	private UILabel lblEndDate;		//��������
	private UIRefPane refEndDate;
	private UISpinner  endHourSpin;
	private UISpinner  endMinuteSpin;
	private UISpinner  endSecondSpin;
	
	private UILabel lblUnit;		//��ѯ��λ
	private UIRefPane refUnit;
	
	public UFDateTime getStartDate() {
		StringBuilder sb = new StringBuilder();
		sb.append(getRefStartDate(0,0,0,0).getText());
		sb.append(" ");
		sb.append(getSpinStartHour(0,0,0,0).getValue());
		sb.append(":");
		sb.append(getSpinStartMinute(0,0,0,0).getValue());
		sb.append(":");
		sb.append(getSpinStartSecond(0,0,0,0).getValue());
		
		return new UFDateTime(sb.toString());
	}
	public UFDateTime getEndDate() {
		StringBuilder sb = new StringBuilder();
		sb.append(getRefEndDate(0,0,0,0).getText());
		sb.append(" ");
		sb.append(getSpinEndHour(0,0,0,0).getValue());
		sb.append(":");
		sb.append(getSpinEndMinute(0,0,0,0).getValue());
		sb.append(":");
		sb.append(getSpinEndSecond(0,0,0,0).getValue());
		return new UFDateTime(sb.toString());
	}
	
	public UILabel getLbStartDate(int x, int y, int w, int h) {
		if (lblStartDate == null) {
			lblStartDate = UIComponentFactory.createUILabel("lblStartMonth", "��ʼ����");
			lblStartDate.setBounds(x, y, w, h);
		}
		return lblStartDate;
	}
	public UIRefPane getRefStartDate(int x, int y, int w, int h) {
		if (refStartDate == null) {
			refStartDate = UIComponentFactory.createUIRefPane("refMonth", "����", null);
			refStartDate.setBounds(x, y, w, h);
		}
		return refStartDate;

	}
	public UISpinner getSpinStartHour(int x, int y, int w, int h) {
		if (startHourSpin == null) {
			startHourSpin = UIComponentFactory.createUISpinner("spinerStarthour", new SpinnerNumberModel(17, 0, 23,1));
			startHourSpin.setBounds(x, y, w, h);
		}
		return startHourSpin;
	}
	
	public UISpinner getSpinStartMinute(int x, int y, int w, int h) {
		if (startMinuteSpin == null) {
			startMinuteSpin = UIComponentFactory.createUISpinner("spinerStartMinute", new SpinnerNumberModel(0, 0, 59,1));
			startMinuteSpin.setBounds(x, y, w, h);
		}
		return startMinuteSpin;
	}	
	public UISpinner getSpinStartSecond(int x, int y, int w, int h) {
		if (startSecondSpin == null) {
			startSecondSpin = UIComponentFactory.createUISpinner("spinerStartSecond", new SpinnerNumberModel(0, 0, 59,1));
			startSecondSpin.setBounds(x, y, w, h);
		}
		return startSecondSpin;
	}
	
	public UILabel getLbEndDate(int x, int y, int w, int h) {
		if (lblEndDate == null) {
			lblEndDate = UIComponentFactory.createUILabel("lblEndMonth", "��������");
			lblEndDate.setBounds(x, y, w, h);
		}
		return lblEndDate;
	}	
	public UIRefPane getRefEndDate(int x, int y, int w, int h) {
		if (refEndDate == null) {
			refEndDate = UIComponentFactory.createUIRefPane("refMonth", "����", null);
			refEndDate.setBounds(x, y, w, h);
		}
		return refEndDate;

	}
	public UISpinner getSpinEndHour(int x, int y, int w, int h) {
		if (endHourSpin == null) {
			endHourSpin = UIComponentFactory.createUISpinner("spinerEndhour", new SpinnerNumberModel(17, 0, 23,1));
			endHourSpin.setBounds(x, y, w, h);
		}
		return endHourSpin;
	}
	
	public UISpinner getSpinEndMinute(int x, int y, int w, int h) {
		if (endMinuteSpin == null) {
			endMinuteSpin = UIComponentFactory.createUISpinner("spinerEndMinute", new SpinnerNumberModel(0, 0, 59,1));
			endMinuteSpin.setBounds(x, y, w, h);
		}
		return endMinuteSpin;
	}	
	public UISpinner getSpinEndSecond(int x, int y, int w, int h) {
		if (endSecondSpin == null) {
			endSecondSpin = UIComponentFactory.createUISpinner("spinerEndSecond", new SpinnerNumberModel(0, 0, 59,1));
			endSecondSpin.setBounds(x, y, w, h);
		}
		return endSecondSpin;
	}
	
	public UILabel getLbUnit(int x, int y, int w, int h) {
		if (lblUnit == null) {
			lblUnit = UIComponentFactory.createUILabel("lblUnit", "��ǰ��˾");
			lblUnit.setBounds(x, y, w, h);
		}
		return lblUnit;
	}
	public UIRefPane getRefUnit(int x, int y, int w, int h) {
		if (refUnit == null) {
			refUnit = UIComponentFactory.createUIRefPane("refUnit", "��˾Ŀ¼", null);
			refUnit.setMultiSelectedEnabled(false);
			String pk_corp = this.getDefaultValue();
			if(pk_corp.equals("0001")){
				refUnit.setEnabled(true);
			}else{
				refUnit.setEnabled(false);
			}
			refUnit.setPK(pk_corp);
			refUnit.setBounds(x, y, w, h);
		}
		return refUnit;
	}
	
	private void initialize() {
		
		this.setLayout(null);
		this.setSize(520, 380);
		
		add(this.getLbStartDate(20, 20, 80, 20));		//��ѯ�·�
		add(this.getRefStartDate(110, 20, 120, 20));
		add(this.getSpinStartHour(240, 20, 50, 20));		
		add(this.getSpinStartMinute(300, 20, 50, 20));
		add(this.getSpinStartSecond(360, 20, 50, 20));
		
		add(this.getLbEndDate(20, 50, 80, 20));		//��ѯ�·�
		add(this.getRefEndDate(110, 50, 120, 20));
		add(this.getSpinEndHour(240, 50, 50, 20));		
		add(this.getSpinEndMinute(300, 50, 50, 20));
		add(this.getSpinEndSecond(360, 50, 50, 20));
	}

	protected String getDefaultValue(){
		return ClientEnvironment.getInstance().getCorporation().getPk_corp();
	}
	
	private String getDefaultStartDate() {
		UFDate logondate = ClientEnvironment.getInstance().getDate();
		String rt = logondate.getYear() + "-";
		int mon = logondate.getMonth();
		String smon = mon + "";
		while(smon.length() < 2) {
			smon = "0" + smon;
		}
		rt += smon + "-01";
		return rt;
	}
	
	private String getDefaultEndDate() {
		UFDate logondate = ClientEnvironment.getInstance().getDate();
		return logondate.toString();
	}
	
	public PerformanceListReportNormalPnl() {
		initialize();
	}

	/**
	 * @param layout
	 */
	public PerformanceListReportNormalPnl(LayoutManager layout) {
		super(layout);
		initialize();
	}

	
}
