package nc.ui.smp.report.wperformance;

import java.util.List;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReport;
import nc.ui.pub.beans.UIDialog;
import nc.ui.report.base.ReportUIBase;
import nc.ui.smp.report.wperformance.DateSelectDlg;
import nc.vo.smp.report.expensedetail.QueryDateVO;
import nc.vo.smp.report.wperformance.WPerformanceReportVO;

public class ClientUI  extends ReportUIBase{
	private QueryDateVO qryVo;		//��ѯ����
	private DateSelectDlg qryDlg;//��ѯ�Ի���
  
	public DateSelectDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new DateSelectDlg(this);
		}
		return qryDlg;
	}
	public String getModuleCode() {
		return "98H102";
	}
	@Override
	protected void onQuery() throws Exception {
		
		int act = this.getQueryDlg().showModal();
		if (act == UIDialog.ID_CANCEL) {
			return;
		}
		qryVo = getQueryDlg().getQueryDateVO();
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		List<WPerformanceReportVO> vos = sv.getWPerformance(qryVo);
		if(vos!=null){
		int size=vos.size();
		WPerformanceReportVO[] arrVos=vos.toArray(new WPerformanceReportVO[size]);
		//�ȵ���ϵͳ�ķ������ɱ�����Ȼ��Ե�Ԫ���������ֵ
		this.setBodyDataVO(arrVos, false);	
		}
		 
	}
	
}