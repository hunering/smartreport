package nc.ui.smp.report.innermang;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReportNew;
import nc.ui.pub.ButtonObject;
import nc.ui.pub.beans.UIDialog;
import nc.ui.pub.report.ReportItem;
import nc.ui.report.base.ReportUIBase;
import nc.vo.pub.BusinessException;
import nc.vo.smp.report.detail.DetailQueryVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.innermang.InnerMangReportVO;

/**
 * �����ڲ���������
 * @author LINQI
 *
 */
public class InnerMangReportUI extends ReportUIBase{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private DetailQueryVO qryVo;		//��ѯ����
	private InnerMangReportQueryDlg qryDlg;//��ѯ�Ի���
	private ReportItem[] dynamicItems;	//��̬��
	
	public InnerMangReportUI(){
		super();
		init();
	}
	
	public void init(){
		
//		reBuildButtons();
		getConditionPanel().setVisible(false);	//ȥ����ͷ��ѯ����
		this.getReportBase().showZeroLikeNull(false);
		this.getReportBase().setTatolRowShow(false);
		
	}
	
	
	/**
	 * ȥ������Ҫ�İ�ť
	 */
	protected void reBuildButtons(){
		ButtonObject[] btns = this.getButtons();
		for(ButtonObject btn : btns){
			if(!btn.getName().equals("��ѯ") && !btn.getName().equals("��ӡ"))
				this.unRegisterButton(btn);
		}
		this.updateAllButtons();
	}

	@Override
	public void onButtonClicked(ButtonObject arg0) {
		// TODO Auto-generated method stub
		super.onButtonClicked(arg0);
	}
	
	@Override
	public void onQuery() throws BusinessException {
		
//		int act = this.getQueryDlg().showModal();
//		if (act == UIDialog.ID_CANCEL) {
//			return;
//		}
//		qryVo = getQueryDlg().getQryVo();
		ISMPReportNew sv = (ISMPReportNew) NCLocator.getInstance().lookup(ISMPReportNew.class.getName());
		InnerMangReportVO[] vos = sv.getInnerMangData(null);
		this.setBodyDataVO(vos, true);	
	}
	
	
	public InnerMangReportQueryDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new InnerMangReportQueryDlg(this);
		}
		return qryDlg;
	}

	public String getModuleCode() {
		return "102204";
	}
	
	
	
}
