package nc.ui.smp.expensedetail;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import nc.bs.framework.common.NCLocator;
import nc.itf.uap.IUAPQueryBS;
import nc.ui.pub.bill.BillEditEvent;
import nc.ui.trade.bocommand.IUserDefButtonCommand;
import nc.ui.trade.manage.ManageEventHandler;
import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.smp.expensedetail.ExpenseDetailVO;
import nc.vo.smp.expensetype.ExpenseTypeVO;
import nc.vo.smp.team.TeamVO;
import nc.ui.pub.beans.UIRefPane;

/**
 * <b> �ڴ˴���Ҫ��������Ĺ��� </b>
 *
 * <p>
 *     �ڴ˴����Ӵ����������Ϣ
 * </p>
 *
 *
 * @author author
 * @version tempProject version
 */
 public class ClientUI extends AbstractClientUI{
       
       protected ManageEventHandler createEventHandler() {
		return new MyEventHandler(this, getUIControl());
	}
       
	public void setBodySpecialData(CircularlyAccessibleValueObject[] vos)
			throws Exception {}

	protected void setHeadSpecialData(CircularlyAccessibleValueObject vo,
			int intRow) throws Exception {}

	protected void setTotalHeadSpecialData(CircularlyAccessibleValueObject[] vos)
			throws Exception {	}

	protected void initSelfData() {
		
		 
	}
	
		
	 protected List<IUserDefButtonCommand> creatUserButtons(){
		 
		  List<IUserDefButtonCommand> bos = new ArrayList<IUserDefButtonCommand>();
		  return bos;
		}

	public void setDefaultData() throws Exception {
		 
	}
	@Override
	 public void afterEdit(BillEditEvent e)
	     {
		if(e.getKey().equalsIgnoreCase("pk_expensetype")){
			try {
				
				 
				 IUAPQueryBS  iUAPQueryBS =    (IUAPQueryBS)NCLocator.getInstance().lookup(IUAPQueryBS.class.getName()); 
				 UIRefPane uPane=(UIRefPane)(e.getSource());
				
				 Collection results =iUAPQueryBS.retrieveByClause(ExpenseTypeVO.class, "pk_expensetype='"+ uPane.getRefPK()+"'");
				 if(results.size()>0){
					 ExpenseTypeVO etvo=(ExpenseTypeVO)results.iterator().next();
					 this.getBillCardPanel().setHeadItem("expensetype", etvo.getExpensetype());
					 this.getBillCardPanel().setHeadItem("expensecode", etvo.getExpensecode());
					 this.getBillCardPanel().setHeadItem("expensename", etvo.getExpensename());
					 
				 }
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	 System.out.println(e);
	    }


}
