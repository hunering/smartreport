package nc.ui.smp.report.income;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReport;
import nc.ui.pub.ButtonObject;
import nc.ui.pub.beans.UIDialog;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.report.ReportBaseClass;
import nc.ui.pub.report.ReportItem;
import nc.ui.report.base.ReportUIBase;
import nc.vo.logging.Debug;
import nc.vo.pub.BusinessException;
import nc.vo.pub.cquery.FldgroupVO;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.report.ReportModelVO;
import nc.vo.smp.clsexe.ClsexeVO;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.income.ClsexeIncomePerBranch;
import nc.vo.smp.report.income.IncomeQueryVO;
import nc.vo.smp.report.income.IncomeReportVO;

/**
 * ͳ����ϸ��
 * @author Allen
 *
 */
public class IncomeReportUI extends ReportUIBase{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private IncomeQueryVO qryVo;		//��ѯ����
	private IncomeReportQueryDlg qryDlg;//��ѯ�Ի���
	private Vector<ReportItem> dynamicItems = new Vector<ReportItem>();	//��̬��
	private Map<String, CourseVO> courseMap = new HashMap<String, CourseVO>();
	ReportItem[] fixedItems; // ����ģ��Ĭ�Ϻ��е���
	String[] columnsPerClsexe = {
			//"studentnum", "total_money", "corp_money", "branch_money"
			"����", "���", "�ܲ�����", "�ֹ�˾����", "��Ч����", "ʦ������", "��������"
	};

	public IncomeReportUI(){
		super();
		init();
	}
	
	public void init(){
		
		reBuildButtons();
		getConditionPanel().setVisible(false);	//ȥ����ͷ��ѯ����
		this.getReportBase().showZeroLikeNull(false);
		this.getReportBase().setTatolRowShow(false);
		buildCourseVO();
		fixedItems = this.getReportBase().getBody_Items();
		
		//��װ������
/*		ReportItem[] items = getDynamicColumns();		//��̬��
		if(items!=null && items.length>0){
			ReportItem[] currtItems = this.getReportBase().getBody_Items();		//��ǰ��
			ReportItem[] newItems = new ReportItem[items.length+currtItems.length];		//ƴװ���µ���
			System.arraycopy(currtItems, 0, newItems, 0, currtItems.length);
			System.arraycopy(items, 0, newItems, currtItems.length, items.length);
			this.getReportBase().setBody_Items(newItems);	//���ñ�����
		}
*/		
	}
	
	protected void buildCourseVO() {
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		CourseVO[] vos;
		try {
			vos = sv.getCourseVO(null);
			for(int i=0;i<vos.length;i++){
				courseMap.put(vos[i].getPk_course(), vos[i]);
			}
		} catch (BusinessException e) {
				e.printStackTrace();
				Debug.error("��ȡCourseVO�����쳣��");
			}
	}
	
	
	public Map<String,List<ReportItem>> getItemGroup(ReportItem[] newItems){
		Map<String,List<ReportItem>> groupItemMap = new HashMap<String,List<ReportItem>>();
		List<ReportItem> groupList = null;
		for(int i=0;i<newItems.length;i++){
			newItems[i].setIDColName(i+"");		//���õ�ǰ�����ڵ�λ��
			String tablename = newItems[i].getTableName();
			if(tablename!=null){
				if(groupItemMap.get(tablename)==null){
					groupList = new ArrayList<ReportItem>();
					groupItemMap.put(tablename, groupList);
				}else{
					groupList = groupItemMap.get(tablename);
				}
				newItems[i].setPos(i);		
				groupList.add(newItems[i]);
			}
		}
		return groupItemMap;
	}
	
	public FldgroupVO[] getFldgroupVO(Map<String,List<ReportItem>> groupItemMap){
		
		if(groupItemMap!=null && groupItemMap.size()>0){
			List rtList = new ArrayList();
			Set keySet = groupItemMap.keySet();
			Iterator it = keySet.iterator();
			int groupid = 1;
			while(it.hasNext()){
				String key = (String) it.next();
				List list = groupItemMap.get(key);
				if(list.size()<2){		//�����������2��
					continue;
				}
				//ע�⣺��һ��FldgroupVO��ǰ����item���
				ReportItem item = (ReportItem) list.get(0);
				FldgroupVO vo = new FldgroupVO();
				vo.setGroupid(groupid);
				vo.setGroupname(item.getTableName());
				vo.setGrouptype("0");
				vo.setToplevelflag("Y");
				vo.setItem1(item.getIDColName());
				vo.setItem2(((ReportItem) list.get(1)).getIDColName());
				rtList.add(vo);
				
				for(int i=2;i<list.size();i++){
					groupid++;
					item = (ReportItem) list.get(i);
					vo = new FldgroupVO();
					vo.setGroupid(groupid);
					vo.setGroupname(item.getTableName());
					vo.setGrouptype("2");
					vo.setToplevelflag("N");
					vo.setItem1(item.getTableName());
					vo.setItem2(item.getIDColName());
					rtList.add(vo);
				}
			}
			return (FldgroupVO[]) rtList.toArray(new FldgroupVO[0]);
		}
		return null;
	}
	
	public void setFieldGroup(FldgroupVO[] vos) throws Exception{
		
		if(vos!=null && vos.length>0){
			this.getReportBase().getReportInfoCtrl().setFldgroups(vos);
			// ���÷�����Ϣ
			this.getReportBase().getReportGeneralUtil().procFieldGroup();
			//  ��ʾ�б�ͷ����
			this.getReportBase().getReportGeneralUtil().makeMultiHeader(this.getReportBase().getSuperTable());
		}
	}
	
	/**
	 * ȥ������Ҫ�İ�ť
	 */
	protected void reBuildButtons(){
		ButtonObject[] btns = this.getButtons();
		for(ButtonObject btn : btns){
			if(!btn.getName().equals("��ѯ") && !btn.getName().equals("��ӡ"))
				this.unRegisterButton(btn);
		}
		this.updateAllButtons();
	}
	
	/**
	 * ��ȡ��̬��
	 * @return
	 */
	protected Vector<ReportItem> getDynamicColumns(){
		
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		try {
			ClsexeVO[] vos = sv.getClsexeVO(qryVo);
			if(vos!=null && vos.length>0){
				dynamicItems.clear();
				int dynamicItemsCount = 0;
				for(int i=0;i<vos.length;i++){
					for (int j=0; j<columnsPerClsexe.length; j++) {
						CourseVO course = courseMap.get(vos[i].getPk_course());
						if(shouldAddColumn(j, course)) {
							dynamicItems.add(dynamicItemsCount, new ReportItem());
							dynamicItems.get(dynamicItemsCount).setKey(vos[i].getPk_clsexe() + columnsPerClsexe[j]);
							dynamicItems.get(dynamicItemsCount).setName(columnsPerClsexe[j]);
							if(j==0) {
								dynamicItems.get(dynamicItemsCount).setDataType(BillItem.INTEGER);
								dynamicItems.get(dynamicItemsCount).setDefaultValue("0");
							} else {
								dynamicItems.get(dynamicItemsCount).setDataType(BillItem.DECIMAL);								
								dynamicItems.get(dynamicItemsCount).setDefaultValue("0.00");
							}
							dynamicItems.get(dynamicItemsCount).setWidth(80);
							dynamicItems.get(dynamicItemsCount).setShowOrder(20+dynamicItemsCount);	//��20��ʼ����
							dynamicItems.get(dynamicItemsCount).setTableName(vos[i].getTitle());	//�γ����

							dynamicItemsCount++;
						}
					}
				}
			}
		}catch (BusinessException e) {
				e.printStackTrace();
				Debug.error("��ȡ��̬�з����쳣��");
			}
		
		
		return dynamicItems;
	}
	
	boolean shouldAddColumn(int i, CourseVO course) {
		boolean ifAddColumn = false;
		if (course != null) {
			switch (i) {
			case 0:
			case 1:
				// "����", "���"
				ifAddColumn = true;
				break;
			case 2:
				// "�ܲ�����"
				if (course.getHeaderquarter_percentage()!=null && course.getHeaderquarter_percentage().doubleValue() > 0.0f) {
					ifAddColumn = true;
				}
				break;
			case 3:
				// "�ֹ�˾����"
				if (course.getBranch_percentage() != null && course.getBranch_percentage().doubleValue() > 0.0f) {
					ifAddColumn = true;
				}
				break;
			case 4:
				// "��Ч����"
				if (course.getJixiao_percentage() != null && course.getJixiao_percentage().doubleValue() > 0.0f) {
					ifAddColumn = true;
				}
				break;
			case 5:
				// "ʦ������"
				if (course.getShidao_percentage()!=null && course.getShidao_percentage().doubleValue() > 0.0f) {
					ifAddColumn = true;
				}
				break;
			case 6:
				// "��������"
				if (course.getWuxiang_percentage()!=null && course.getWuxiang_percentage().doubleValue() > 0.0f) {
					ifAddColumn = true;
				}
				break;
			}
		}
		return ifAddColumn;
	}
	@Override
	protected void initColumnGroups() {
		super.initColumnGroups();
	}

	@Override
	public void onButtonClicked(ButtonObject arg0) {
		// TODO Auto-generated method stub
		super.onButtonClicked(arg0);
	}
	
	@Override
	public void onQuery() throws BusinessException {
		
		int act = this.getQueryDlg().showModal();
		if (act == UIDialog.ID_CANCEL) {
			return;
		}
		qryVo = getQueryDlg().getQryVo();
		Object[] items= getDynamicColumns().toArray();
		//ReportItem[] items = (ReportItem[]) getDynamicColumns().toArray();		//��̬��
		if(items!=null && items.length>0){
			//ReportItem[] currtItems = this.getReportBase().getBody_Items();		//��ǰ��
			ReportItem[] newItems = new ReportItem[items.length+fixedItems.length];		//ƴװ���µ���
			System.arraycopy(fixedItems, 0, newItems, 0, 1);
			System.arraycopy(items, 0, newItems, 1, items.length);
			System.arraycopy(fixedItems, 1, newItems, items.length+1, fixedItems.length-1);
			this.getReportBase().setBody_Items(newItems);	//���ñ�����
			
			Map groupItemMap = this.getItemGroup(newItems);
			FldgroupVO[] vos = this.getFldgroupVO(groupItemMap);
			try {
				this.setFieldGroup(vos);
			} catch (Exception e) {
				Debug.debug("�����з��鷢���쳣��"+e.getMessage());
			}
		}
		
		

		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		
		IncomeReportVO[] incomeReportVOs = sv.getCorpIncomeData(qryVo);
		setBodyData(incomeReportVOs);
	}
	
	/**
	 * ���ñ�������
	 * @param vos
	 */
	public void setBodyData(IncomeReportVO[] incomeVOs){
		ReportBaseClass reportBase = this.getReportBase();
		reportBase.getBillModel().clearBodyData();
		for(int i=0;i<incomeVOs.length;i++) {
			String fields[] = incomeVOs[i].getAttributeNames();
			for(String field:fields){
				if(field.equals("branchname")) {
					reportBase.getBillData().addLine();
					this.getReportBase().setBodyValueAt(incomeVOs[i].getAttributeValue(field), i, field);				
				} else if(field.equals("summationperbranch")) {
					ClsexeIncomePerBranch summationPerBranch = (ClsexeIncomePerBranch)incomeVOs[i].getAttributeValue(field);
					this.getReportBase().setBodyValueAt(summationPerBranch.getTotalMoney(), i, "total_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getGroupMoney(), i, "group_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getBranchMoney(), i, "branch_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getJxMoney(), i, "jx_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getSdMoney(), i, "sd_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getWuxiangMoney(), i, "wx_income_perclsexe");
				} else {
					ClsexeIncomePerBranch clsexePerBranch = (ClsexeIncomePerBranch)incomeVOs[i].getAttributeValue(field);
					this.getReportBase().setBodyValueAt(clsexePerBranch.getStudentNum(), i
							, clsexePerBranch.getPk_clsexe()+columnsPerClsexe[0]);
					this.getReportBase().setBodyValueAt(clsexePerBranch.getTotalMoney(), i
							, clsexePerBranch.getPk_clsexe()+columnsPerClsexe[1]);
					this.getReportBase().setBodyValueAt(clsexePerBranch.getGroupMoney(), i
							, clsexePerBranch.getPk_clsexe()+columnsPerClsexe[2]);
					this.getReportBase().setBodyValueAt(clsexePerBranch.getBranchMoney(), i
							, clsexePerBranch.getPk_clsexe()+columnsPerClsexe[3]);


//					StringBuilder sb = new StringBuilder();
//					sb.append("������");
//					sb.append(clsexePerBranch.getStudentNum());
//					sb.append("; ��");
//					sb.append(clsexePerBranch.getTotalMoney());
//					sb.append("; �ܹ�˾���룺");
//					sb.append(clsexePerBranch.getGroupMoney());
//					sb.append("; �ֹ�˾���룺");
//					sb.append(clsexePerBranch.getBranchMoney());
//					this.getReportBase().setBodyValueAt(sb.toString(), i, clsexePerBranch.getPk_clsexe());
					
				}
			}
		

			//reportBase.setBodyValueAt(incomeVOs[i], i, strKey);			
		}
	}
	
	private void applyIncomeReportVO(IncomeReportVO incomeVO) {
		ReportItem[] currtItems = this.getReportBase().getBody_Items();
	}
	
	public IncomeReportQueryDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new IncomeReportQueryDlg(this);
		}
		return qryDlg;
	}

	public String getModuleCode() {
		return "98H260";
	}
}
