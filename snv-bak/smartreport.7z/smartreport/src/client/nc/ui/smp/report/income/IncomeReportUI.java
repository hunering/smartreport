package nc.ui.smp.report.income;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReport;
import nc.ui.pub.ButtonObject;
import nc.ui.pub.beans.UIDialog;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.report.ReportBaseClass;
import nc.ui.pub.report.ReportItem;
import nc.ui.report.base.ReportUIBase;
import nc.vo.logging.Debug;
import nc.vo.pub.BusinessException;
import nc.vo.pub.lang.UFDouble;
import nc.vo.smp.clsexe.ClsexeVO;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.income.ClsexeIncomePerBranch;
import nc.vo.smp.report.income.IncomeQueryVO;
import nc.vo.smp.report.income.IncomeReportVO;

/**
 * ͳ����ϸ��
 * @author LINQI
 *
 */
public class IncomeReportUI extends ReportUIBase{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private IncomeQueryVO qryVo;		//��ѯ����
	private IncomeReportQueryDlg qryDlg;//��ѯ�Ի���
	private ReportItem[] dynamicItems;	//��̬��
	private Map<String, CourseVO> courseMap = new HashMap<String, CourseVO>();
	
	public IncomeReportUI(){
		super();
		init();
	}
	
	public void init(){
		
		reBuildButtons();
		getConditionPanel().setVisible(false);	//ȥ����ͷ��ѯ����
		this.getReportBase().showZeroLikeNull(false);
		this.getReportBase().setTatolRowShow(false);
		buildCourseVO();
		
		//��װ������
/*		ReportItem[] items = getDynamicColumns();		//��̬��
		if(items!=null && items.length>0){
			ReportItem[] currtItems = this.getReportBase().getBody_Items();		//��ǰ��
			ReportItem[] newItems = new ReportItem[items.length+currtItems.length];		//ƴװ���µ���
			System.arraycopy(currtItems, 0, newItems, 0, currtItems.length);
			System.arraycopy(items, 0, newItems, currtItems.length, items.length);
			this.getReportBase().setBody_Items(newItems);	//���ñ�����
		}
*/		
	}
	
	protected void buildCourseVO() {
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		CourseVO[] vos;
		try {
			vos = sv.getCourseVO(null);
			for(int i=0;i<vos.length;i++){
				courseMap.put(vos[i].getPk_course(), vos[i]);
			}
		} catch (BusinessException e) {
				e.printStackTrace();
				Debug.error("��ȡCourseVO�����쳣��");
			}
	}
	
	/**
	 * ȥ������Ҫ�İ�ť
	 */
	protected void reBuildButtons(){
		ButtonObject[] btns = this.getButtons();
		for(ButtonObject btn : btns){
			if(!btn.getName().equals("��ѯ") && !btn.getName().equals("��ӡ"))
				this.unRegisterButton(btn);
		}
		this.updateAllButtons();
	}
	
	/**
	 * ��ȡ��̬��
	 * @return
	 */
	protected ReportItem[] getDynamicColumns(){
		
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		try {
			ClsexeVO[] vos = sv.getClsexeVO(qryVo);
			if(vos!=null && vos.length>0){
				dynamicItems = new ReportItem[vos.length];
				for(int i=0;i<vos.length;i++){
					dynamicItems[i] = new ReportItem();
					dynamicItems[i].setKey(vos[i].getPk_clsexe());
					dynamicItems[i].setName(vos[i].getTitle());
					dynamicItems[i].setDataType(BillItem.DECIMAL);
					dynamicItems[i].setWidth(80);
					dynamicItems[i].setShowOrder(20+i);	//��20��ʼ����
				}
			}
		}catch (BusinessException e) {
				e.printStackTrace();
				Debug.error("��ȡ��̬�з����쳣��");
			}
		
		
		return dynamicItems;
	}
	
	@Override
	protected void initColumnGroups() {
		// TODO Auto-generated method stub
		super.initColumnGroups();
	}

	@Override
	public void onButtonClicked(ButtonObject arg0) {
		// TODO Auto-generated method stub
		super.onButtonClicked(arg0);
	}
	
	@Override
	public void onQuery() throws BusinessException {
		
		int act = this.getQueryDlg().showModal();
		if (act == UIDialog.ID_CANCEL) {
			return;
		}
		qryVo = getQueryDlg().getQryVo();
		ReportItem[] items = getDynamicColumns();		//��̬��
		if(items!=null && items.length>0){
			ReportItem[] currtItems = this.getReportBase().getBody_Items();		//��ǰ��
			ReportItem[] newItems = new ReportItem[items.length+currtItems.length];		//ƴװ���µ���
			System.arraycopy(currtItems, 0, newItems, 0, currtItems.length);
			System.arraycopy(items, 0, newItems, currtItems.length, items.length);
			this.getReportBase().setBody_Items(newItems);	//���ñ�����
		}

		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		
		IncomeReportVO[] incomeReportVOs = sv.getCorpIncomeData(qryVo);
		setBodyData(incomeReportVOs);
//		for(IncomeReportVO incomeVO : incomeReportVOs){
//			String fields[] = incomeVO.getAttributeNames();
//			for(String field:fields){
//				if(!field.equals("branchname")) {
//					ClsexePerBranch clsexePerBranch = (ClsexePerBranch)incomeVO.getAttributeValue(field);
//				}
//				this.getReportBase().setBodyValueAt(incomeVO.getAttributeValue(field), 0, field);
//			}
//		}
	}
	
	/**
	 * ���ñ�������
	 * @param vos
	 */
	public void setBodyData(IncomeReportVO[] incomeVOs){
		ReportBaseClass reportBase = this.getReportBase();
		reportBase.getBillModel().clearBodyData();
		for(int i=0;i<incomeVOs.length;i++) {
			String fields[] = incomeVOs[i].getAttributeNames();
			for(String field:fields){
				if(field.equals("branchname")) {
					reportBase.getBillData().addLine();
					this.getReportBase().setBodyValueAt(incomeVOs[i].getAttributeValue(field), i, field);				
				} else if(field.equals("summationperbranch")) {
					ClsexeIncomePerBranch summationPerBranch = (ClsexeIncomePerBranch)incomeVOs[i].getAttributeValue(field);
					this.getReportBase().setBodyValueAt(summationPerBranch.getTotalMoney(), i, "total_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getGroupMoney(), i, "group_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getBranchMoney(), i, "branch_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getJxMoney(), i, "jx_income_perclsexe");
					this.getReportBase().setBodyValueAt(summationPerBranch.getSdMoney(), i, "sd_income_perclsexe");
				} else {
					ClsexeIncomePerBranch clsexePerBranch = (ClsexeIncomePerBranch)incomeVOs[i].getAttributeValue(field);
				}
			}
		

			//reportBase.setBodyValueAt(incomeVOs[i], i, strKey);			
		}
	}
	
	private void applyIncomeReportVO(IncomeReportVO incomeVO) {
		ReportItem[] currtItems = this.getReportBase().getBody_Items();
	}
	
	public IncomeReportQueryDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new IncomeReportQueryDlg(this);
		}
		return qryDlg;
	}

	public String getModuleCode() {
		return "98H260";
	}
}
