package nc.ui.smp.report.expensedetail;

import java.util.List;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReport;
import nc.ui.pub.beans.UIDialog;
import nc.ui.report.base.ReportUIBase;
import nc.vo.smp.report.expensedetail.ExpenseDetailReportVO;
import nc.vo.smp.report.expensedetail.QueryDateVO;

public class ClientUI  extends ReportUIBase{
	private QueryDateVO qryVo;		//��ѯ����
	private DateSelectDlg qryDlg;//��ѯ�Ի���
  
	public DateSelectDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new DateSelectDlg(this);
		}
		return qryDlg;
	}
	public String getModuleCode() {
		return "98H101";
	}
	@Override
	protected void onQuery() throws Exception {
		
		int act = this.getQueryDlg().showModal();
		if (act == UIDialog.ID_CANCEL) {
			return;
		}
		qryVo = getQueryDlg().getQueryDateVO();
		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		List<ExpenseDetailReportVO> vos = sv.getExpenseDetail(qryVo);
		int size=vos.size();
		ExpenseDetailReportVO[] arrVos=vos.toArray(new ExpenseDetailReportVO[size]);
		//�ȵ���ϵͳ�ķ������ɱ�����Ȼ��Ե�Ԫ���������ֵ
		this.setBodyDataVO(arrVos, false);	
		 
	}
	
}
