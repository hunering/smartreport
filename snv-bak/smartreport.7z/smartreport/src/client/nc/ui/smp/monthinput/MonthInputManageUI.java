package nc.ui.smp.monthinput;

import nc.ui.trade.bill.AbstractManageController;
import nc.ui.trade.manage.ManageEventHandler;
import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.trade.pub.IBillStatus;

/**
 * <b> �����¶�¼��������� </b>
 * 
 * 
 * 
 * @author author
 * @version tempProject version
 */
public class MonthInputManageUI extends nc.ui.trade.manage.BillManageUI  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MonthInputManageUI(){
		super();
		this.getBillCardPanel().setAutoExecHeadEditFormula(true);		//���ñ�ͷ�༭��ʽ��ִ��
	}

	protected ManageEventHandler createEventHandler() {
		return new MonthInputEventHandler(this,this.getUIControl());                    
	}
	@Override
	protected AbstractManageController createController() {
		// TODO Auto-generated method stub
		return new MonthInputController();
	}

	public void setBodySpecialData(CircularlyAccessibleValueObject[] vos)
			throws Exception {
	}

	protected void setHeadSpecialData(CircularlyAccessibleValueObject vo,
			int intRow) throws Exception {
	}

	protected void setTotalHeadSpecialData(CircularlyAccessibleValueObject[] vos)
			throws Exception {
	}

	protected void initSelfData() {
	}

	public void setDefaultData() throws Exception {
		
		this.getBillCardPanel().getHeadTailItem("vbillstatus").setValue(IBillStatus.FREE);
		this.getBillCardPanel().getHeadTailItem("vbilltype").setValue(this.getUIControl().getBillType());
		this.getBillCardPanel().getHeadTailItem("pk_corp").setValue(_getCorp().getPk_corp());
		this.getBillCardPanel().getHeadTailItem("voperatorid").setValue(_getOperator());
	}


}
