package nc.ui.smp.report.performancelist;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import nc.bs.framework.common.NCLocator;
import nc.itf.smp.ISMPReport;
import nc.ui.pub.ButtonObject;
import nc.ui.pub.beans.UIDialog;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.report.ReportBaseClass;
import nc.ui.pub.report.ReportItem;
import nc.ui.report.base.ReportUIBase;
import nc.vo.logging.Debug;
import nc.vo.pub.BusinessException;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.report.ReportModelVO;
import nc.vo.smp.clsexe.ClsexeVO;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.cost.CostQueryVO;
import nc.vo.smp.report.cost.CostReportVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.income.ClsexeIncomePerBranch;
import nc.vo.smp.report.income.IncomeQueryVO;
import nc.vo.smp.report.income.IncomeReportVO;
import nc.vo.smp.report.performancelist.PerformanceDetailVO;
import nc.vo.smp.report.performancelist.PerformanceQueryVO;

/**
 * ͳ����ϸ��
 * @author Allen
 *
 */
public class PerformanceListReportUI extends ReportUIBase{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private PerformanceQueryVO qryVo;		//��ѯ����
	private PerformanceListReportQueryDlg qryDlg;//��ѯ�Ի���
	
	public PerformanceListReportUI(){
		super();
		init();
	}
	
	public void init(){
		
		reBuildButtons();
		getConditionPanel().setVisible(false);	//ȥ����ͷ��ѯ����
		this.getReportBase().showZeroLikeNull(false);
		this.getReportBase().setTatolRowShow(false);
	}
	
	/**
	 * ȥ������Ҫ�İ�ť
	 */
	protected void reBuildButtons(){
		ButtonObject[] btns = this.getButtons();
		for(ButtonObject btn : btns){
			if(!btn.getName().equals("��ѯ") && !btn.getName().equals("��ӡ"))
				this.unRegisterButton(btn);
		}
		this.updateAllButtons();
	}
	
	/**
	 * ��ȡ��̬��
	 * @return
	 */
	@Override
	protected void initColumnGroups() {
		super.initColumnGroups();
	}

	@Override
	public void onButtonClicked(ButtonObject arg0) {
		// TODO Auto-generated method stub
		super.onButtonClicked(arg0);
	}
	
	@Override
	public void onQuery() throws BusinessException {
		
		int act = this.getQueryDlg().showModal();
		if (act == UIDialog.ID_CANCEL) {
			return;
		}
		qryVo = getQueryDlg().getQryVo();

		ISMPReport sv = (ISMPReport) NCLocator.getInstance().lookup(ISMPReport.class.getName());
		
		PerformanceDetailVO[] costReportVOs = sv.getPerformanceList(qryVo);
		setBodyData(costReportVOs);
	}
	
	/**
	 * ���ñ�������
	 * @param vos
	 */
	public void setBodyData(PerformanceDetailVO[] costReportVOs){
		ReportBaseClass reportBase = this.getReportBase();
		reportBase.getBillModel().clearBodyData();
		for(int i=0;i<costReportVOs.length;i++) {
			reportBase.getBillData().addLine();
			String fields[] = costReportVOs[i].getAttributeNames();
			for(String field:fields){
				this.getReportBase().setBodyValueAt(costReportVOs[i].getAttributeValue(field), i, field);
			}
		}
	}
	
	public PerformanceListReportQueryDlg getQueryDlg() {
		if (qryDlg == null) {
			qryDlg = new PerformanceListReportQueryDlg(this);
		}
		return qryDlg;
	}

	public String getModuleCode() {
		return "98H262";
	}
}
