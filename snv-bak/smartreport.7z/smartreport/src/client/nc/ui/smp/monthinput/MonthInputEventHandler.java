/*
 *
 * TODO Ҫ���Ĵ����ɵ��ļ���ģ�壬��ת��
 * ���� �� ��ѡ�� �� Java �� ������ʽ �� ����ģ��
 */
package nc.ui.smp.monthinput;

import nc.ui.pub.ButtonObject;
import nc.ui.trade.businessaction.IBusinessController;
import nc.ui.trade.controller.IControllerBase;
import nc.ui.trade.manage.BillManageUI;
import nc.ui.trade.manage.ManageEventHandler;
import nc.vo.pub.CircularlyAccessibleValueObject;

/**
 * 
 * TODO Ҫ���Ĵ����ɵ�����ע�͵�ģ�壬��ת�� ���� �� ��ѡ�� �� Java �� ������ʽ �� ����ģ��
 */
public class MonthInputEventHandler extends ManageEventHandler {


	public MonthInputEventHandler(BillManageUI billUI,
			IControllerBase control) {
		super(billUI, control);
		// TODO Auto-generated constructor stub
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.handler.EventHandler#createBusinessAction()
	 */
	protected IBusinessController createBusinessAction() {
		return super.createBusinessAction();
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#onBoLineDel()
	 */
	protected void onBoLineDel() throws Exception {
		super.onBoLineDel();
	}

	@Override
	protected void onBoDelete() throws Exception {
		super.onBoDelete();
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#onBoAssign()
	 */
	protected void onBoElse(int intBtn) throws Exception {
		super.onBoElse(intBtn);
	}
	
	@Override
	protected void onBoRefresh() throws Exception {
		// TODO Auto-generated method stub
		super.onBoRefresh();
	}
	
	@Override
	protected void onBoQuery() throws Exception {
		// TODO Auto-generated method stub
		super.onBoQuery();
	}

	@Override
	protected String getHeadCondition() {
		// TODO Auto-generated method stub
		if(this._getCorp().getPk_corp().equals("0001")){	//���ſ��Բ鿴��������
			return null;
		}
		return super.getHeadCondition();
	}

	/**
	 * �����ѯ
	 */
	protected void onBoBodyQuery() throws Exception {
		StringBuffer strWhere = new StringBuffer();
		if (askForBodyQueryCondition(strWhere) == false)
			return;// �û������˲�ѯ
		String str = strWhere.toString();
		doBodyQuery(str);
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#processCopyedBodyVOsBeforePaste(nc.vo.pub.CircularlyAccessibleValueObject[])
	 */
	protected void processCopyedBodyVOsBeforePaste(CircularlyAccessibleValueObject[] vos) {
		super.processCopyedBodyVOsBeforePaste(vos);
	}
	
	protected void onBoSave() throws Exception {
//		this.getBillCardPanelWrapper().getBillCardPanel().dataNotNullValidate();	//�ǿ�У��
		super.onBoSave();
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#processNewBodyVO(nc.vo.pub.CircularlyAccessibleValueObject)
	 */
	protected CircularlyAccessibleValueObject processNewBodyVO(CircularlyAccessibleValueObject newBodyVO) {
		return super.processNewBodyVO(newBodyVO);
	}


	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#onBoAdd(nc.ui.pub.ButtonObject)
	 */
	public void onBoAdd(ButtonObject bo) throws Exception {
		super.onBoAdd(bo);
		this.getBillCardPanelWrapper().getBillCardPanel().getHeadItem("vbillno").setEdit(true);
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#onBoLineAdd()
	 */
	protected void onBoLineAdd() throws Exception {
		super.onBoLineAdd();
	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#onBoLineIns()
	 */
	protected void onBoLineIns() throws Exception {
		super.onBoLineIns();

	}

	/*
	 * ���� Javadoc��
	 * 
	 * @see nc.ui.trade.bill.BillEventHandler#onBoLinePaste()
	 */
	protected void onBoLinePaste() throws Exception {
		super.onBoLinePaste();
	}

	
}