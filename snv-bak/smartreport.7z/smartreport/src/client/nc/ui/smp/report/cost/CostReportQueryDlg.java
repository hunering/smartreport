/**
 * 
 */
package nc.ui.smp.report.cost;

import java.awt.Container;
import java.awt.event.ActionEvent;

import javax.swing.table.TableCellEditor;

import nc.ui.pub.ClientEnvironment;
import nc.ui.pub.beans.MessageDialog;
import nc.vo.jcom.lang.StringUtil;
import nc.vo.pub.lang.UFDate;
import nc.vo.smp.report.cost.CostQueryVO;
import nc.vo.smp.report.income.IncomeQueryVO;

/**
 * ��ѯ�Ի���
 * �������ڣ�2012-03-06
 * @author Allen
 *
 */
public class CostReportQueryDlg extends nc.ui.pub.query.QueryConditionClient {

	private static final long serialVersionUID = 7059148648371835678L;
	
	private CostReportNormalPnl normalPanel;
	
	private CostQueryVO qryVo;
	
	private ClientEnvironment clientEnv;

	public CostQueryVO getQryVo() {
		return qryVo;
	}

	/**
	 * 
	 */
	public CostReportQueryDlg() {
		super();
		initialize();
	}

	/**
	 * @param parent
	 */
	public CostReportQueryDlg(Container parent) {
		super(parent);
		initialize();
	}

	private void initialize() {
		
		this.hideUnitButton();	//���ض൥λ���հ�ť
		this.setShowDefine(false);	//��ʾ�Զ���ҳǩ
		this.getUIPanelNormal().add(getNormalPanel());
		this.setSize(520, 380);
		
//		�����Զ����ѯģ��
//		this.setTempletID(getClientEnvironment().getCorporation().getPk_corp(), "M1050570", getClientEnvironment().getUser().getPrimaryKey(), "");
	}
	
	private CostReportNormalPnl getNormalPanel() {
		if (normalPanel == null) {
			normalPanel = new CostReportNormalPnl();
		}
		return normalPanel;
	}
	
	@Override
	public void closeOK() {
		if (!checkValue()) {
			return;
		}
		setValuesToQueryVO();
		super.closeOK();
	}
	
	private boolean checkValue() {
		
		String strMonth = this.getNormalPanel().getRefMonth(0, 0, 0, 0).getText();
		if (StringUtil.isEmptyWithTrim(strMonth)) {
			MessageDialog.showErrorDlg(this, "����", "��ѯ�·ݲ���Ϊ�գ�");
			return false;
		}
		return true;
	}
	
	private void setValuesToQueryVO() {
		
//		ConditionVO[] cvos = this.getConditionVO();
//		for(ConditionVO cvo : cvos){
//			System.out.println(cvo.getFieldCode()+">>>"+cvo.getSQLStr());
//		}
		
		qryVo = new CostQueryVO();
		qryVo.setUnitcode(getClientEnvironment().getCorporation().getUnitcode());
		qryVo.setPk_corp(getClientEnvironment().getCorporation().getPrimaryKey());
		qryVo.setMonth(getNormalPanel().getRefMonth(0, 0, 0, 0).getText());
		qryVo.setFromDate(new UFDate(qryVo.getMonth() + "-1"));
		qryVo.setEndDate(new UFDate(qryVo.getMonth() + "-" + qryVo.getFromDate().getDaysMonth()));
		
	}
	
	public ClientEnvironment getClientEnvironment(){
		if(clientEnv==null){
			clientEnv = ClientEnvironment.getInstance();
		}
		return clientEnv;
	}
	
	/* (non-Javadoc)
	 * @see nc.ui.mbt.m1050101.IRefPaneActionListener#afterAction(java.awt.event.ActionEvent)
	 */
	public void afterAction(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see nc.ui.mbt.m1050101.IRefPaneActionListener#beforeAction(java.awt.event.ActionEvent)
	 */
	public void beforeAction(ActionEvent e) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	protected void afterEdit(TableCellEditor editor, int row, int col) {
		// TODO Auto-generated method stub
		super.afterEdit(editor, row, col);
	}

	@Override
	public void changeValueRef(String fieldcode, Object editor) {
		// TODO Auto-generated method stub
		super.changeValueRef(fieldcode, editor);
	}

	@Override
	public void changeValueRef(String tableCode, String fieldcode, Object editor) {
		// TODO Auto-generated method stub
		super.changeValueRef(tableCode, fieldcode, editor);
	}

	 
	

}
