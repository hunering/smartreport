/*     */ package nc.bs.pub.report;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import nc.jdbc.framework.JdbcSession;
/*     */ import nc.jdbc.framework.PersistenceManager;
/*     */ import nc.jdbc.framework.SQLParameter;
/*     */ import nc.jdbc.framework.exception.DbException;
/*     */ import nc.jdbc.framework.mapping.IMappingMeta;
/*     */ import nc.jdbc.framework.processor.ArrayListProcessor;
/*     */ import nc.jdbc.framework.processor.BeanMappingListProcessor;
/*     */ import nc.jdbc.framework.processor.ColumnProcessor;
/*     */ import nc.vo.pub.report.ReportBusinessException;
/*     */ import nc.vo.pub.report.ReportModelVO;
/*     */ import nc.vo.pub.report.ReportTempletVO;
/*     */ 
/*     */ public class ReportModelDAO
/*     */ {
/*  26 */   private static final IMappingMeta mappingMeta = new IMappingMeta()
/*     */   {
/*     */     public String[] getAttributes() {
/*  29 */       return new String[] { "id", "pkCorp", "pkTemplet", "nodeCode", "columnCode", "columnSystem", "columnUser", "columnWidth", "reportPos", "itemOrder", "columnType", "dataType", "selectType", "ifDefault", "ifMust", "ifNo", "colExpressions", "groupOrder", "orderOrder", "orderType", "ifSum", "resid_system", "resid_user", "isThMark", "idColName" };
/*     */     }
/*     */ 
/*     */     public String[] getColumns()
/*     */     {
/*  59 */       return new String[] { "pk_model", "pk_corp", "pk_templet", "node_code", "column_code", "column_system", "column_user", "column_width", "report_pos", "item_order", "column_type", "data_type", "select_type", "if_default", "if_must", "if_no", "col_expressions", "group_order", "order_order", "order_type", "if_sum", "resid_system", "resid_user", "is_thmark", "idcolname" };
/*     */     }
/*     */ 
/*     */     public String getPrimaryKey()
/*     */     {
/*  89 */       return "pk_model";
/*     */     }
/*     */ 
/*     */     public String getTableName() {
/*  93 */       return "pub_report_model";
/*     */     }
/*  26 */   };
/*     */ 
/* 101 */   private static final IMappingMeta mappingMeta_Join = new IMappingMeta()
/*     */   {
/*     */     public String[] getAttributes() {
/* 104 */       return new String[] { "id", "pkCorp", "pkTemplet", "nodeCode", "columnCode", "columnSystem", "columnUser", "columnWidth", "reportPos", "itemOrder", "columnType", "dataType", "selectType", "ifDefault", "ifMust", "ifNo", "colExpressions", "groupOrder", "orderOrder", "orderType", "ifSum", "resid_system", "resid_user", "isThMark", "idColName" };
/*     */     }
/*     */ 
/*     */     public String[] getColumns()
/*     */     {
/* 134 */       return new String[] { "pk_model", "pk_corp", "pk_templet", "node_code", "column_code", "column_system", "column_user", "column_width", "report_pos", "item_order", "column_type", "data_type", "select_type", "if_default", "if_must", "if_no", "col_expressions", "group_order", "order_order", "order_type", "if_sum", "resid_system", "resid_user", "is_thmark", "idcolname" };
/*     */     }
/*     */ 
/*     */     public String getPrimaryKey()
/*     */     {
/* 164 */       return "id";
/*     */     }
/*     */ 
/*     */     public String getTableName() {
/* 168 */       return "pub_report_model";
/*     */     }
/* 101 */   };
/*     */ 
/*     */   public void delete(ReportModelVO vo)
/*     */     throws ReportBusinessException
/*     */   {
/* 185 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 187 */       sessionManager = PersistenceManager.getInstance();
/* 188 */       sessionManager.deleteObject(vo, mappingMeta);
/*     */     }
/*     */     catch (DbException e) {
/* 191 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 193 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteArray(ReportModelVO[] vos)
/*     */     throws ReportBusinessException
/*     */   {
/* 206 */     if (vos == null)
/* 207 */       return;
/* 208 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 210 */       sessionManager = PersistenceManager.getInstance();
/* 211 */       sessionManager.deleteObject(vos, mappingMeta);
/*     */     }
/*     */     catch (DbException e) {
/* 214 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 216 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteInitFields(ReportModelVO[] vos, String corp)
/*     */     throws ReportBusinessException
/*     */   {
/* 230 */     String sql = null;
/* 231 */     if (corp.equals("0001"))
/* 232 */       sql = "delete from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and pk_corp <> '@@@@'";
/*     */     else {
/* 234 */       sql = "delete from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and pk_corp = '" + corp + "'";
/*     */     }
/* 236 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 238 */       sessionManager = PersistenceManager.getInstance();
/* 239 */       JdbcSession session = sessionManager.getJdbcSession();
/* 240 */       for (int i = 0; i < vos.length; ++i) {
/* 241 */         SQLParameter parameter = new SQLParameter();
/* 242 */         parameter.addParam(vos[i].getNodeCode());
/* 243 */         parameter.addParam(vos[i].getColumnCode());
/* 244 */         if (vos[i].getReportPos() == null)
/* 245 */           parameter.addNullParam(4);
/*     */         else {
/* 247 */           parameter.addParam(vos[i].getReportPos().intValue());
/*     */         }
/* 249 */         session.addBatch(sql, parameter);
/*     */       }
/* 251 */       session.executeBatch();
/*     */     }
/*     */     catch (DbException e) {
/* 254 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 256 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteQuoteArray(ReportModelVO[] vos)
/*     */     throws ReportBusinessException
/*     */   {
/* 271 */     String sql = "delete from pub_report_model where node_code = ? and column_code in (select column_code from pub_report_model where pk_model = ?) and report_pos = ?";
/* 272 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 274 */       sessionManager = PersistenceManager.getInstance();
/* 275 */       JdbcSession session = sessionManager.getJdbcSession();
/* 276 */       for (int i = 0; i < vos.length; ++i) {
/* 277 */         SQLParameter parameter = new SQLParameter();
/* 278 */         parameter.addParam(vos[i].getNodeCode());
/* 279 */         parameter.addParam(vos[i].getColumnCode());
/* 280 */         if (vos[i].getReportPos() == null)
/* 281 */           parameter.addNullParam(4);
/*     */         else {
/* 283 */           parameter.addParam(vos[i].getReportPos().intValue());
/*     */         }
/* 285 */         session.addBatch(sql, parameter);
/*     */       }
/* 287 */       session.executeBatch();
/*     */     }
/*     */     catch (DbException e) {
/* 290 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 292 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteTemplet(String strTempletID)
/*     */     throws ReportBusinessException
/*     */   {
/* 310 */     String sql = "delete from pub_report_model where pk_templet = ?";
/* 311 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 313 */       sessionManager = PersistenceManager.getInstance();
/* 314 */       JdbcSession session = sessionManager.getJdbcSession();
/* 315 */       SQLParameter parameter = new SQLParameter();
/* 316 */       parameter.addParam(strTempletID);
/* 317 */       session.executeUpdate(sql, parameter);
/*     */     }
/*     */     catch (DbException e) {
/* 320 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 322 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean ifDeletingFldQuoted(String strNodeCode, String columnCode, Integer iReportPos, String corp)
/*     */     throws ReportBusinessException
/*     */   {
/* 338 */     String sql = null;
/* 339 */     if (corp == null)
/* 340 */       sql = "select count(*) from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and select_type in (1, 2)";
/*     */     else {
/* 342 */       sql = "select count(*) from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and select_type in (1, 2) and pk_corp in ('@@@@', '0001', '" + corp + "')";
/*     */     }
/* 344 */     return judgeResult(sql, strNodeCode, columnCode, iReportPos);
/*     */   }
/*     */ 
/*     */   public boolean ifFldExisted(String strNodeCode, String columnCode, Integer iReportPos)
/*     */     throws ReportBusinessException
/*     */   {
/* 359 */     String sql = "select count(*) from pub_report_model where node_code = ? and column_code = ? and report_pos = ?";
/*     */ 
/* 361 */     return judgeResult(sql, strNodeCode, columnCode, iReportPos);
/*     */   }
/*     */ 
/*     */   public boolean ifFldExisted(String strNodeCode, String columnCode, Integer iReportPos, String pkCorp)
/*     */     throws ReportBusinessException
/*     */   {
/* 374 */     String sql = "select count(*) from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and pk_corp in ('@@@@', '0001', '" + pkCorp + "')";
/*     */ 
/* 377 */     return judgeResult(sql, strNodeCode, columnCode, iReportPos);
/*     */   }
/*     */ 
/*     */   public boolean ifQuoted(String strNodeCode, String key, Integer iReportPos)
/*     */     throws ReportBusinessException
/*     */   {
/* 390 */     String sql = "select count(*) from pub_report_model where node_code = ? and column_code in (select column_code from pub_report_model where pk_model = ? and pk_corp <> '@@@@') and report_pos = ? and select_type in (1, 2)";
/* 391 */     return judgeResult(sql, strNodeCode, key, iReportPos);
/*     */   }
/*     */ 
/*     */   private boolean judgeResult(String sql, String code1, String code2, Integer iReportPos)
/*     */     throws ReportBusinessException
/*     */   {
/* 404 */     int iTemp = 0;
/* 405 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 407 */       sessionManager = PersistenceManager.getInstance();
/* 408 */       JdbcSession session = sessionManager.getJdbcSession();
/* 409 */       SQLParameter parameter = new SQLParameter();
/* 410 */       parameter.addParam(code1);
/* 411 */       parameter.addParam(code2);
/* 412 */       if (iReportPos == null)
/* 413 */         parameter.addNullParam(4);
/*     */       else
/* 415 */         parameter.addParam(iReportPos.intValue());
/* 416 */       Object obj = session.executeQuery(sql, parameter, new ColumnProcessor());
/*     */ 
/* 418 */       if (obj != null)
/* 419 */         iTemp = new Integer(obj.toString()).intValue();
/*     */     }
/*     */     catch (DbException e) {
/* 422 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 424 */       sessionManager.release();
/*     */     }
/*     */ 
/* 427 */     return (iTemp > 0);
/*     */   }
/*     */ 
/*     */   public String insert(ReportModelVO reportModel)
/*     */     throws ReportBusinessException
/*     */   {
/* 442 */     PersistenceManager sessionManager = null;
/* 443 */     String key = null;
/*     */     try {
/* 445 */       sessionManager = PersistenceManager.getInstance();
/* 446 */       key = sessionManager.insertObject(reportModel, mappingMeta);
/*     */     }
/*     */     catch (DbException e)
/*     */     {
/* 450 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 452 */       sessionManager.release();
/*     */     }
/* 454 */     return key;
/*     */   }
/*     */ 
/*     */   public String[] insertArray(ReportModelVO[] reportModels)
/*     */     throws ReportBusinessException
/*     */   {
/* 470 */     PersistenceManager sessionManager = null;
/* 471 */     String[] keys = null;
/*     */     try {
/* 473 */       sessionManager = PersistenceManager.getInstance();
/* 474 */       keys = sessionManager.insertObject(reportModels, mappingMeta);
/*     */     }
/*     */     catch (DbException e)
/*     */     {
/* 478 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 480 */       sessionManager.release();
/*     */     }
/* 482 */     return keys;
/*     */   }
/*     */ 
/*     */   public String[] insertRelativeArray(ReportModelVO reportModelOri, ReportTempletVO[] reportTemplets)
/*     */     throws ReportBusinessException
/*     */   {
/* 501 */     PersistenceManager sessionManager = null;
/* 502 */     String[] keys = null;
/*     */     try {
/* 504 */       sessionManager = PersistenceManager.getInstance();
/* 505 */       List list = new ArrayList();
/* 506 */       for (int i = 0; i < reportTemplets.length; ++i) {
/* 507 */         ReportModelVO reportModel = (ReportModelVO)reportModelOri.clone();
/* 508 */         String pkCorp = reportTemplets[i].getPkCorp();
/*     */ 
/* 510 */         if (pkCorp.equals("@@@@"))
/* 511 */           pkCorp = reportModel.getPkCorp();
/* 512 */         reportModel.setPkCorp(pkCorp);
/* 513 */         String strTempletID = reportTemplets[i].getPrimaryKey();
/* 514 */         reportModel.setPkTemplet(strTempletID);
/* 515 */         list.add(reportModel);
/*     */       }
/* 517 */       keys = sessionManager.insertObject(list.toArray(new ReportModelVO[0]), mappingMeta);
/*     */     }
/*     */     catch (DbException e)
/*     */     {
/* 521 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 523 */       sessionManager.release();
/*     */     }
/* 525 */     return keys;
/*     */   }
/*     */ 
/*     */   public String[] queryDefTempletContainsMultiheader(String strNodeCode, String columnCode, Integer iReportPos, String corp)
/*     */     throws ReportBusinessException
/*     */   {
/* 541 */     String sql = null;
/* 542 */     if (corp == null)
/* 543 */       sql = "select distinct pk_templet from pub_report_group where pk_templet in (select t1.pk_templet from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where t1.node_code = ? and column_code = ? and report_pos = ? and t2.pk_corp <> '@@@@')";
/*     */     else {
/* 545 */       sql = "select distinct pk_templet from pub_report_group where pk_templet in (select t1.pk_templet from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where t1.node_code = ? and column_code = ? and report_pos = ? and t2.pk_corp in ('0001', '" + corp + "'))";
/*     */     }
/* 547 */     PersistenceManager sessionManager = null;
/* 548 */     String[] ids = null;
/*     */     try {
/* 550 */       sessionManager = PersistenceManager.getInstance();
/* 551 */       JdbcSession session = sessionManager.getJdbcSession();
/* 552 */       SQLParameter p = new SQLParameter();
/* 553 */       p.addParam(strNodeCode);
/* 554 */       p.addParam(columnCode);
/* 555 */       p.addParam(iReportPos);
/* 556 */       Object result = session.executeQuery(sql, p, new ArrayListProcessor());
/* 557 */       if (result != null)
/*     */       {
/* 559 */         ArrayList list = (ArrayList)result;
/* 560 */         ids = new String[list.size()];
/* 561 */         Iterator it = list.iterator();
/* 562 */         int index = 0;
/* 563 */         while (it.hasNext())
/*     */         {
/* 565 */           Object[] attrs = (Object[])(Object[])it.next();
/* 566 */           ids[(index++)] = attrs[0].toString();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (DbException e) {
/* 571 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 573 */       sessionManager.release();
/*     */     }
/* 575 */     return ids;
/*     */   }
/*     */ 
/*     */   public int queryItemOrderByTempletId(String strNodeCode, String columnCode, Integer iReportPos, String corp, String pkTemplet)
/*     */     throws ReportBusinessException
/*     */   {
/* 589 */     String sql = null;
/* 590 */     if (corp.equals("0001"))
/* 591 */       sql = "select item_order from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and pk_corp <> '@@@@' and pk_templet = ?";
/*     */     else {
/* 593 */       sql = "select item_order from pub_report_model where node_code = ? and column_code = ? and report_pos = ? and pk_corp = '" + corp + "' and pk_templet = ?";
/*     */     }
/* 595 */     PersistenceManager sessionManager = null;
/* 596 */     int iTemp = -1;
/*     */     try {
/* 598 */       sessionManager = PersistenceManager.getInstance();
/* 599 */       JdbcSession session = sessionManager.getJdbcSession();
/* 600 */       SQLParameter p = new SQLParameter();
/* 601 */       p.addParam(strNodeCode);
/* 602 */       p.addParam(columnCode);
/* 603 */       p.addParam(iReportPos);
/* 604 */       Object result = session.executeQuery(sql, p, new ColumnProcessor());
/* 605 */       if (result != null)
/* 606 */         iTemp = Integer.parseInt(result.toString());
/*     */     }
/*     */     catch (DbException e) {
/* 609 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 611 */       sessionManager.release();
/*     */     }
/* 613 */     return iTemp;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectDefault(String node, boolean bInit)
/*     */     throws ReportBusinessException
/*     */   {
/* 624 */     String sql = null;
/*     */ 
/* 626 */     if (bInit)
/* 627 */       sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user,is_thmark,idcolname from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where t2.pk_corp ='@@@@' and t1.node_code = ? order by report_pos, item_order";
/*     */     else {
/* 629 */       sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user,is_thmark,idcolname from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where select_type <> 2 and t2.pk_corp ='@@@@' and t1.node_code = ? order by report_pos, item_order";
/*     */     }
/*     */ 
/* 638 */     ReportModelVO[] reportModels = null;
/* 639 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 641 */       sessionManager = PersistenceManager.getInstance();
/* 642 */       JdbcSession session = sessionManager.getJdbcSession();
/* 643 */       SQLParameter p = new SQLParameter();
/* 644 */       p.addParam(node);
/* 645 */       List list = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta));
/* 646 */       if (list.size() > 0)
/* 647 */         reportModels = (ReportModelVO[])(ReportModelVO[])list.toArray(new ReportModelVO[list.size()]);
/*     */     }
/*     */     catch (DbException e) {
/* 650 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 652 */       sessionManager.release();
/*     */     }
/* 654 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectDefaultTemplet(String templet)
/*     */     throws ReportBusinessException
/*     */   {
/* 674 */     String sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where select_type <> 2 and t2.pk_corp = '@@@@' and t1.pk_templet = ? order by report_pos, item_order";
/*     */ 
/* 676 */     ReportModelVO[] reportModels = null;
/* 677 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 679 */       sessionManager = PersistenceManager.getInstance();
/* 680 */       JdbcSession session = sessionManager.getJdbcSession();
/* 681 */       SQLParameter p = new SQLParameter();
/* 682 */       p.addParam(templet);
/* 683 */       List list = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta_Join));
/* 684 */       if (list.size() > 0)
/* 685 */         reportModels = (ReportModelVO[])(ReportModelVO[])list.toArray(new ReportModelVO[list.size()]);
/*     */     }
/*     */     catch (DbException e) {
/* 688 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 690 */       sessionManager.release();
/*     */     }
/* 692 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectDefaultTempletNew(String templet)
/*     */     throws ReportBusinessException
/*     */   {
/* 711 */     String sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where select_type <> 2 and t2.pk_corp = '@@@@' and t1.pk_corp = '@@@@' and t1.pk_templet = ? order by report_pos, item_order";
/*     */ 
/* 713 */     ReportModelVO[] reportModels = null;
/* 714 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 716 */       sessionManager = PersistenceManager.getInstance();
/* 717 */       JdbcSession session = sessionManager.getJdbcSession();
/* 718 */       SQLParameter p = new SQLParameter();
/* 719 */       p.addParam(templet);
/* 720 */       List result = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta_Join));
/* 721 */       if ((result != null) && (result.size() > 0))
/* 722 */         reportModels = (ReportModelVO[])(ReportModelVO[])result.toArray(new ReportModelVO[0]);
/*     */     }
/*     */     catch (DbException e)
/*     */     {
/* 726 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 728 */       sessionManager.release();
/*     */     }
/* 730 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectDefaultWithCorp(String corp, String node)
/*     */     throws ReportBusinessException
/*     */   {
/* 742 */     String sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user,is_thmark,idcolname from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where t2.pk_corp ='@@@@' and t1.node_code = ?";
/*     */ 
/* 744 */     sql = sql + " and select_type <> 2";
/*     */ 
/* 746 */     if (corp.equals("0001"))
/* 747 */       sql = sql + " and (t1.pk_corp = '@@@@' or t1.pk_corp = '0001')";
/*     */     else {
/* 749 */       sql = sql + " and (t1.pk_corp = '@@@@' or t1.pk_corp = '0001' or t1.pk_corp = '" + corp + "')";
/*     */     }
/* 751 */     sql = sql + " order by report_pos, item_order";
/*     */ 
/* 754 */     ReportModelVO[] reportModels = null;
/* 755 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 757 */       sessionManager = PersistenceManager.getInstance();
/* 758 */       JdbcSession session = sessionManager.getJdbcSession();
/* 759 */       SQLParameter p = new SQLParameter();
/* 760 */       p.addParam(node);
/* 761 */       List list = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta));
/* 762 */       if (list.size() > 0)
/* 763 */         reportModels = (ReportModelVO[])(ReportModelVO[])list.toArray(new ReportModelVO[list.size()]);
/*     */     }
/*     */     catch (DbException e) {
/* 766 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 768 */       sessionManager.release();
/*     */     }
/* 770 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectTemplet(String corp, String templet)
/*     */     throws ReportBusinessException
/*     */   {
/* 789 */     String sql = "select pk_model, pk_corp, pk_templet, node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user,is_thmark,idcolname from pub_report_model where pk_templet = ? order by report_pos, item_order";
/*     */ 
/* 791 */     ReportModelVO[] reportModels = null;
/* 792 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 794 */       sessionManager = PersistenceManager.getInstance();
/* 795 */       JdbcSession session = sessionManager.getJdbcSession();
/* 796 */       SQLParameter p = new SQLParameter();
/* 797 */       p.addParam(templet);
/* 798 */       List list = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta));
/* 799 */       if (list.size() > 0)
/* 800 */         reportModels = (ReportModelVO[])(ReportModelVO[])list.toArray(new ReportModelVO[list.size()]);
/*     */     }
/*     */     catch (DbException e) {
/* 803 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 805 */       sessionManager.release();
/*     */     }
/* 807 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectTemplet(String templatePK) throws ReportBusinessException {
/* 811 */     String sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user,is_thmark,idcolname from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where t1.pk_templet = ? order by t2.pk_corp desc, report_pos, item_order, column_type";
/*     */ 
/* 814 */     ReportModelVO[] reportModels = null;
/* 815 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 817 */       sessionManager = PersistenceManager.getInstance();
/* 818 */       JdbcSession session = sessionManager.getJdbcSession();
/* 819 */       SQLParameter p = new SQLParameter();
/* 820 */       p.addParam(templatePK);
/* 821 */       List list = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta_Join));
/* 822 */       if (list.size() > 0) {
/* 823 */         for (Iterator iter = list.iterator(); iter.hasNext(); ){
/* 824 */          ReportModelVO element = (ReportModelVO)iter.next();
/*     */          
/* 829 */         reportModels = (ReportModelVO[])(ReportModelVO[])list.toArray(new ReportModelVO[list.size()]);
/*     */       }
}}
/*     */     
/*     */     catch (DbException e)
/*     */     {
/* 834 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 836 */       sessionManager.release();
/*     */     }
/* 838 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public ReportModelVO[] selectTemplet(String corp, String templet, String node)
/*     */     throws ReportBusinessException
/*     */   {
/* 856 */     String sql = "select pk_model, t1.pk_corp, t1.pk_templet, t1.node_code, column_code, order_type, if_sum, col_expressions, column_type, if_default, data_type, if_must, select_type, if_no, column_system, column_user, column_width, group_order, order_order, item_order, report_pos,resid_system,resid_user,is_thmark,idcolname from pub_report_model t1 inner join pub_report_templet t2 on t1.pk_templet = t2.pk_templet where t1.pk_templet = ? or (t2.pk_corp = '@@@@' and select_type = 2 and t2.node_code = ?) order by t2.pk_corp desc, report_pos, item_order, column_type";
/*     */ 
/* 860 */     ReportModelVO[] reportModels = null;
/* 861 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 863 */       sessionManager = PersistenceManager.getInstance();
/* 864 */       JdbcSession session = sessionManager.getJdbcSession();
/* 865 */       SQLParameter p = new SQLParameter();
/* 866 */       p.addParam(templet);
/* 867 */       p.addParam(node);
/* 868 */       List list = (List)session.executeQuery(sql, p, new BeanMappingListProcessor(ReportModelVO.class, mappingMeta_Join));
/* 869 */       if (list.size() > 0) {
/* 870 */         for (Iterator iter = list.iterator(); iter.hasNext(); )
/* 871 */         {  
/*     */         ReportModelVO element = (ReportModelVO)iter.next();
/* 876 */         reportModels = (ReportModelVO[])(ReportModelVO[])list.toArray(new ReportModelVO[list.size()]);
/*     */       }}
/*     */     }
/*     */     catch (DbException e)
/*     */     {
/* 881 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 883 */       sessionManager.release();
/*     */     }
/* 885 */     return reportModels;
/*     */   }
/*     */ 
/*     */   public void update(ReportModelVO reportModel)
/*     */     throws ReportBusinessException
/*     */   {
/* 901 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 903 */       sessionManager = PersistenceManager.getInstance();
/* 904 */       sessionManager.updateObject(reportModel, mappingMeta);
/*     */     }
/*     */     catch (DbException e) {
/* 907 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 909 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateArray(ReportModelVO[] reportModels)
/*     */     throws ReportBusinessException
/*     */   {
/* 925 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 927 */       sessionManager = PersistenceManager.getInstance();
/* 928 */       sessionManager.updateObject(reportModels, mappingMeta);
/*     */     }
/*     */     catch (DbException e) {
/* 931 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 933 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateInitFields(ReportModelVO[] reportModels, String corp)
/*     */     throws ReportBusinessException
/*     */   {
/* 950 */     String sql = null;
/* 951 */     if (corp.equals("0001"))
/* 952 */       sql = "update pub_report_model set column_system = ?, column_user = ? where node_code = ? and column_code = ? and report_pos = ? and pk_corp <> '@@@@'";
/*     */     else {
/* 954 */       sql = "update pub_report_model set column_system = ?, column_user = ? where node_code = ? and column_code = ? and report_pos = ? and pk_corp = '" + corp + "'";
/*     */     }
/* 956 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 958 */       sessionManager = PersistenceManager.getInstance();
/* 959 */       JdbcSession session = sessionManager.getJdbcSession();
/* 960 */       ReportModelVO reportModel = null;
/* 961 */       for (int i = 0; i < reportModels.length; ++i) {
/* 962 */         reportModel = reportModels[i];
/* 963 */         SQLParameter parameter = new SQLParameter();
/*     */ 
/* 965 */         parameter.addParam(reportModel.getColumnSystem());
/*     */ 
/* 967 */         parameter.addParam(reportModel.getColumnUser());
/*     */ 
/* 969 */         parameter.addParam(reportModel.getNodeCode());
/*     */ 
/* 971 */         parameter.addParam(reportModel.getColumnCode());
/*     */ 
/* 973 */         parameter.addParam(reportModel.getReportPos().intValue());
/* 974 */         session.addBatch(sql, parameter);
/*     */       }
/* 976 */       session.executeBatch();
/*     */     }
/*     */     catch (DbException e) {
/* 979 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 981 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateQuoteArray(ReportModelVO[] reportModels)
/*     */     throws ReportBusinessException
/*     */   {
/* 996 */     String sql = "update pub_report_model set column_code = ?, column_system = ? where node_code = ? and column_code in (select column_code from pub_report_model where pk_model = ?) and report_pos = ?";
/* 997 */     PersistenceManager sessionManager = null;
/*     */     try {
/* 999 */       sessionManager = PersistenceManager.getInstance();
/* 1000 */       JdbcSession session = sessionManager.getJdbcSession();
/* 1001 */       ReportModelVO reportModel = null;
/*     */ 
/* 1003 */       for (int i = 0; i < reportModels.length; ++i) {
/* 1004 */         reportModel = reportModels[i];
/* 1005 */         SQLParameter parameter = new SQLParameter();
/* 1006 */         parameter.addParam(reportModel.getColumnCode());
/*     */ 
/* 1008 */         parameter.addParam(reportModel.getColumnSystem());
/*     */ 
/* 1010 */         parameter.addParam(reportModel.getNodeCode());
/* 1011 */         parameter.addParam(reportModel.getPrimaryKey());
/*     */ 
/* 1013 */         parameter.addParam(reportModel.getReportPos().intValue());
/* 1014 */         session.addBatch(sql, parameter);
/*     */       }
/*     */ 
/* 1017 */       session.executeBatch();
/*     */     }
/*     */     catch (DbException e) {
/* 1020 */       throw new ReportBusinessException(e.getMessage());
/*     */     } finally {
/* 1022 */       sessionManager.release();
/*     */     }
/*     */   }
/*     */ }

 