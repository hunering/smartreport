/*     */ package nc.bs.trade.comsave;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Array;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import nc.bs.framework.server.util.NewObjectService;
/*     */ import nc.bs.logging.Logger;
/*     */ import nc.bs.ml.NCLangResOnserver;
/*     */ import nc.bs.trade.business.HYSuperDMO;
/*     */ import nc.bs.trade.business.IBDBusiCheck;
/*     */ import nc.bs.trade.business.NullBDBusiCheck;
/*     */ import nc.vo.pub.AggregatedValueObject;
/*     */ import nc.vo.pub.BusinessException;
/*     */ import nc.vo.pub.CircularlyAccessibleValueObject;
/*     */ import nc.vo.pub.SuperVO;
/*     */ import nc.vo.trade.pub.IBDGetCheckClass;
/*     */ import nc.vo.trade.pub.IExAggVO;
/*     */ import nc.vo.trade.pub.IRetCurrentDataAfterSave;
/*     */ import nc.vo.trade.pub.IServerSideFactory;
/*     */ 
/*     */ public class BillSave extends ComSave
/*     */   implements IBillSave
/*     */ {
/*     */   private SuperVO[] dealChildVO(SuperVO[] items)
/*     */     throws BusinessException
/*     */   {
/*  37 */     if (items == null)
/*  38 */       return null;
/*  39 */     Vector v = new Vector();
/*  40 */     for (int i = 0; i < items.length; ++i)
/*     */     {
/*  42 */       if (items[i].getStatus() != 3)
/*  43 */         v.addElement(items[i]);
/*     */     }
/*  45 */     if (v.size() > 0)
/*     */     {
/*  47 */       SuperVO[] vos = (SuperVO[])(SuperVO[])Array.newInstance(items.getClass().getComponentType(), v.size());
/*     */ 
/*  51 */       v.copyInto(vos);
/*  52 */       return vos;
/*     */     }
/*  54 */     return null; }
/*     */ 
/*     */   private boolean isNew(AggregatedValueObject billVO) throws BusinessException {
/*  57 */     return ((billVO.getParentVO().getPrimaryKey() == null) || (billVO.getParentVO().getPrimaryKey().length() == 0));
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBaseDoc(AggregatedValueObject billVo, boolean isQueryData)
/*     */     throws BusinessException
/*     */   {
/*  69 */     if (billVo == null) {
/*  70 */       throw new BusinessException(NCLangResOnserver.getInstance().getStrByID("uffactory_hyeaa", "UPPuffactory_hyeaa-000039"));
/*     */     }
/*  72 */     if (billVo.getParentVO() == null)
/*     */     {
/*  74 */       return saveBodyVOs(billVo, isQueryData);
/*     */     }
/*     */ 
/*  77 */     return saveBillCom(billVo);
/*     */   }
/*     */ 
/*     */   public AggregatedValueObject saveBD(AggregatedValueObject billVo, Object userObj)
/*     */     throws BusinessException
/*     */   {
/*     */     try
/*     */     {
/*  91 */       if (userObj instanceof IServerSideFactory)
/*     */       {
/*  93 */         return saveBD_new(billVo, userObj);
/*     */       }
/*     */ 
/*  96 */       if (userObj != null)
/*     */       {
/*  98 */         IBDBusiCheck bdbusi = getBDBusiCheckInstance(userObj);
/*     */ 
/* 100 */         bdbusi.check(1, billVo, userObj);
/*     */ 
/* 103 */         if (userObj instanceof IRetCurrentDataAfterSave)
/* 104 */           billVo = saveBaseDoc(billVo, false);
/*     */         else {
/* 106 */           billVo = saveBaseDoc(billVo, true);
/*     */         }
/*     */ 
/* 109 */         bdbusi.dealAfter(1, billVo, userObj);
/*     */ 
/* 111 */         return billVo;
/*     */       }
/*     */ 
/* 114 */       return saveBaseDoc(billVo, true);
/*     */     }
/*     */     catch (BusinessException e)
/*     */     {
/* 118 */       throw e;
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 122 */       Logger.error(e.getMessage(), e);
/* 123 */       throw new BusinessException(NCLangResOnserver.getInstance().getStrByID("uffactory_hyeaa", "UPPuffactory_hyeaa-000012") + e.getMessage());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 129 */       Logger.error(e.getMessage(), e);
/* 130 */       throw new BusinessException(NCLangResOnserver.getInstance().getStrByID("uffactory_hyeaa", "UPPuffactory_hyeaa-000012"), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private IBDBusiCheck getBDBusiCheckInstance(Object userObj)
/*     */     throws ClassNotFoundException, InstantiationException, IllegalAccessException
/*     */   {
/* 149 */     IBDBusiCheck bdbusi = null;
/*     */ 
/* 151 */     if (userObj instanceof IBDGetCheckClass)
/*     */     {
/* 153 */       IBDGetCheckClass bdchk = (IBDGetCheckClass)userObj;
/* 154 */       String checkClass = bdchk.getCheckClass();
/* 155 */       if ((checkClass != null) && (checkClass.trim().length() != 0))
/*     */       {
/* 159 */         Object o = NewObjectService.newInstance(checkClass.trim());
/* 160 */         Logger.error("nc.bs.trade.comsave.BillSave hardcode module name as \"uap\"");
/* 161 */         if (o instanceof IBDBusiCheck)
/* 162 */           bdbusi = (IBDBusiCheck)o;
/*     */       }
/*     */     }
/* 165 */     if (bdbusi == null)
/* 166 */       bdbusi = new NullBDBusiCheck();
/* 167 */     return bdbusi;
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBD_new(AggregatedValueObject billVo, Object userObj)
/*     */     throws Exception
/*     */   {
/* 177 */     IServerSideFactory factory = (IServerSideFactory)userObj;
/*     */ 
/* 179 */     IBDBusiCheck busiCheck = factory.getBDBusiCheckInstance();
/*     */ 
/* 181 */     busiCheck.check(1, billVo, userObj);
/*     */ 
/* 183 */     AggregatedValueObject result = saveBaseDoc_new(billVo, factory);
/*     */ 
/* 185 */     busiCheck.dealAfter(1, result, userObj);
/*     */ 
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBaseDoc_new(AggregatedValueObject billVo, IServerSideFactory factory)
/*     */     throws Exception
/*     */   {
/* 196 */     if (billVo == null) {
/* 197 */       throw new BusinessException(NCLangResOnserver.getInstance().getStrByID("uffactory_hyeaa", "UPPuffactory_hyeaa-000039"));
/*     */     }
/* 199 */     if (billVo.getParentVO() == null)
/*     */     {
/* 201 */       return saveBodyVOs_new(billVo, factory);
/*     */     }
/*     */ 
/* 204 */     return saveBillCom(billVo);
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBodyVOs_new(AggregatedValueObject billVO, IServerSideFactory factory)
/*     */     throws BusinessException
/*     */   {
/* 214 */     HYSuperDMO dmo = new HYSuperDMO();
/*     */ 
/* 217 */     SuperVO[] items = (SuperVO[])(SuperVO[])billVO.getChildrenVO();
/* 218 */     if (billVO instanceof IExAggVO) {
/* 219 */       items = (SuperVO[])(SuperVO[])((IExAggVO)billVO).getAllChildrenVO();
/*     */     }
/* 221 */     saveItems(dmo, items, null, null);
/*     */ 
/* 223 */     AggregatedValueObject retVO = billVO;
/*     */ 
/* 225 */     IQueryAfterSave queryAfterSave = factory.getQueryAfterSaveInstance();
/*     */     try
/*     */     {
/* 228 */       retVO.setChildrenVO(queryAfterSave.queryBodyVOsAfterSave());
/*     */     }
/*     */     catch (Exception e) {
/* 231 */       Logger.error(e);
/* 232 */       if (e instanceof BusinessException)
/*     */       {
/* 234 */         throw ((BusinessException)e);
/*     */       }
/*     */ 
/* 238 */       throw new BusinessException(e.getMessage(), e);
/*     */     }
/*     */ 
/* 243 */     return retVO;
/*     */   }
/*     */ 
/*     */   public ArrayList saveBill(AggregatedValueObject billVo)
/*     */     throws BusinessException
/*     */   {
/* 256 */     ArrayList retAry = new ArrayList();
/* 257 */     AggregatedValueObject retVo = saveBillCom(billVo);
/* 258 */     retAry.add(retVo.getParentVO().getPrimaryKey());
/* 259 */     retAry.add(retVo);
/* 260 */     return retAry;
/*     */   }
/*     */ 
/*     */   public AggregatedValueObject saveBillCom(AggregatedValueObject billVo)
/*     */     throws BusinessException
/*     */   {
/* 279 */     if (billVo == null) {
/* 280 */       throw new BusinessException(NCLangResOnserver.getInstance().getStrByID("uffactory_hyeaa", "UPPuffactory_hyeaa-000041"));
/*     */     }
/* 282 */     if (billVo.getParentVO() == null)
/*     */     {
/* 284 */       System.out.println("���棺saveBill�õ��Ĳ����ı�ͷVOδnull��δ�ܱ����κ�����");
/* 285 */       return null;
/*     */     }
/* 287 */     HYSuperDMO dmo = null;
/* 288 */     AggregatedValueObject retVO = null;
/*     */ 
/* 292 */     dmo = new HYSuperDMO();
/* 293 */     if (isNew(billVo))
/*     */     {
/* 295 */       retVO = saveBillWhenAdd(billVo, dmo);
/*     */     }
/*     */     else
/*     */     {
/* 299 */       retVO = saveBillWhenEdit(billVo, dmo);
/*     */     }
/* 301 */     return retVO;
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBillWhenAdd(AggregatedValueObject vo, HYSuperDMO dmo)
/*     */     throws BusinessException
/*     */   {
/* 318 */     SuperVO headVO = (SuperVO)vo.getParentVO();
/*     */ 
/* 323 */     headVO.setAttributeValue("dr", new Integer(0));
/* 324 */     String key = dmo.insert(headVO);
/*     */ 
/* 327 */     SuperVO[] items = (SuperVO[])(SuperVO[])vo.getChildrenVO();
/* 328 */     if (vo instanceof IExAggVO)
/*     */     {
/* 330 */       items = (SuperVO[])(SuperVO[])((IExAggVO)vo).getAllChildrenVO();
/*     */     }
/* 332 */     if (items != null)
/*     */     {
/* 335 */       for (int i = 0; i < items.length; ++i)
/*     */       {
/* 337 */         items[i].setAttributeValue("dr", new Integer(0));
/* 338 */         items[i].setStatus(2);
/*     */       }
/* 340 */       saveItems(dmo, items, headVO.getPKFieldName(), key);
/*     */     }
/*     */ 
/* 343 */     vo.setParentVO(dmo.queryByPrimaryKey(headVO.getClass(), key));
/* 344 */     return vo;
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBillWhenEdit(AggregatedValueObject billVO, HYSuperDMO dmo)
/*     */     throws BusinessException
/*     */   {
/* 359 */     SuperVO headvo = (SuperVO)billVO.getParentVO();
/* 360 */     String billPK = headvo.getPrimaryKey();
/* 361 */     String mainPKFiledName = headvo.getPKFieldName();
/* 362 */     headvo.setAttributeValue("dr", new Integer(0));
/* 363 */     dmo.update(headvo);
/* 364 */     boolean isMultiChild = false;
/*     */ 
/* 366 */     SuperVO[] items = (SuperVO[])(SuperVO[])billVO.getChildrenVO();
/* 367 */     if (billVO instanceof IExAggVO)
/*     */     {
/* 369 */       isMultiChild = true;
/* 370 */       items = (SuperVO[])(SuperVO[])((IExAggVO)billVO).getAllChildrenVO();
/*     */     }
/* 372 */     if (items != null) {
/* 373 */       saveItems(dmo, items, mainPKFiledName, billPK);
/*     */     }
/* 375 */     billVO.setParentVO(dmo.queryByPrimaryKey(headvo.getClass(), billPK));
/* 376 */     if ((items != null) && (items.length > 0))
/* 377 */       setChildData(billVO, isMultiChild, dmo);
/* 378 */     return billVO;
/*     */   }
/*     */ 
/*     */   private AggregatedValueObject saveBodyVOs(AggregatedValueObject billVO, boolean isQueryData)
/*     */     throws BusinessException
/*     */   {
/*     */     try
/*     */     {
/* 395 */       HYSuperDMO dmo = new HYSuperDMO();
/*     */ 
/* 398 */       SuperVO[] items = (SuperVO[])(SuperVO[])billVO.getChildrenVO();
/* 399 */       if (billVO instanceof IExAggVO) {
/* 400 */         items = (SuperVO[])(SuperVO[])((IExAggVO)billVO).getAllChildrenVO();
/*     */       }
/* 402 */       saveItems(dmo, items, null, null);
/*     */ 
/* 404 */       AggregatedValueObject retVO = billVO;
/* 405 */       if (isQueryData)
/*     */       {
/* 407 */         retVO = (AggregatedValueObject)billVO.getClass().newInstance();
/* 408 */         if (items.length > 0)
/* 409 */           if (items[0].getParentPKFieldName() != null) {
/* 410 */             retVO.setChildrenVO(dmo.queryByWhereClause(items[0].getClass(), items[0].getParentPKFieldName() + "='" + items[0].getAttributeValue(items[0].getParentPKFieldName()) + "' and isnull(dr,0)=0"));
/*     */           }
/*     */           else
/*     */           {
/* 419 */             retVO.setChildrenVO(dmo.queryByWhereClause(items[0].getClass(), "isnull(dr,0)=0"));
/*     */           }
/*     */       }
/* 422 */       return retVO;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 426 */       Logger.error(e.getMessage(), e);
/* 427 */       throw new BusinessException("HYPubBO::saveBillWhenEdit(AggregatedValueObject) Exception! " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setChildData(AggregatedValueObject vo, boolean isMultiChild, HYSuperDMO dmo)
/*     */     throws BusinessException
/*     */   {
/* 444 */     if (isMultiChild)
/*     */     {
/* 446 */       IExAggVO exAggVO = (IExAggVO)vo;
/* 447 */       for (int i = 0; i < exAggVO.getTableCodes().length; ++i)
/*     */       {
/* 449 */         String tableCode = exAggVO.getTableCodes()[i];
/* 450 */         SuperVO[] items = (SuperVO[])(SuperVO[])exAggVO.getTableVO(tableCode);
/* 451 */         exAggVO.setTableVO(tableCode, dealChildVO(items));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 456 */       SuperVO[] itemVos = (SuperVO[])(SuperVO[])vo.getChildrenVO();
/* 457 */       SuperVO headVo = (SuperVO)vo.getParentVO();
/* 458 */       vo.setChildrenVO(dmo.queryByWhereClause(itemVos[0].getClass(), itemVos[0].getParentPKFieldName() + "='" + headVo.getPrimaryKey() + "' and isnull(dr,0)=0"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public AggregatedValueObject[] saveBDs(AggregatedValueObject[] billVos, Object userObj)
/*     */     throws BusinessException
/*     */   {
/* 477 */     if (billVos == null) return null;
/*     */ 
/* 479 */     AggregatedValueObject[] ret = new AggregatedValueObject[billVos.length];
/* 480 */     for (int i = 0; i < billVos.length; ++i) {
/* 481 */       ret[i] = saveBD(billVos[i], userObj);
/*     */     }
/*     */ 
/* 484 */     return ret;
/*     */   }
/*     */ 
/*     */   public AggregatedValueObject[] saveBillComVos(AggregatedValueObject[] billVos)
/*     */     throws BusinessException
/*     */   {
/* 497 */     if (billVos == null) {
/* 498 */       throw new BusinessException(NCLangResOnserver.getInstance().getStrByID("uffactory_hyeaa", "UPPuffactory_hyeaa-000042"));
/*     */     }
/* 500 */     HYSuperDMO dmo = null;
/*     */ 
/* 502 */     dmo = new HYSuperDMO();
/*     */ 
/* 504 */     SuperVO[] headVos = new SuperVO[billVos.length];
/* 505 */     for (int i = 0; i < headVos.length; ++i)
/*     */     {
/* 507 */       headVos[i] = ((SuperVO)billVos[i].getParentVO());
/*     */     }
/* 509 */     String[] keyAry = dmo.insertArray(headVos);
/*     */ 
/* 512 */     Vector insertVec = new Vector();
/* 513 */     for (int i = 0; i < billVos.length; ++i)
/*     */     {
/* 515 */       SuperVO headVo = (SuperVO)billVos[i].getParentVO();
/* 516 */       SuperVO[] vos = (SuperVO[])(SuperVO[])billVos[i].getChildrenVO();
/* 517 */       if (vos != null) {
/* 518 */         for (int j = 0; j < vos.length; ++j)
/*     */         {
/* 521 */           vos[j].setAttributeValue(headVo.getPKFieldName(), keyAry[i]);
/* 522 */           vos[j].setAttributeValue("dr", new Integer(0));
/* 523 */           vos[j].setStatus(2);
/* 524 */           insertVec.addElement(vos[j]);
/*     */         }
/*     */       }
/*     */     }
/* 528 */     if (insertVec.size() > 0)
/*     */     {
/* 530 */       Hashtable insertDataHas = new Hashtable();
/* 531 */       SuperVO itemVo = (SuperVO)insertVec.get(0);
/* 532 */       insertDataHas.put(itemVo.getTableName(), insertVec);
/* 533 */       saveItemHas(dmo, insertDataHas, null);
/*     */     }
/* 535 */     return billVos;
/*     */   }
/*     */ }

 