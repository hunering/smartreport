/*     */ package nc.vo.pub;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ import nc.bs.logging.Logger;
/*     */ 
/*     */ public class BeanHelper
/*     */ {
/*  32 */   protected static final Object[] NULL_ARGUMENTS = new Object[0];
/*     */ 
/*  34 */   private static Map<String, Map<Integer, Map<String, Method>>> cache = new HashMap();
/*     */ 
/*  36 */   private static BeanHelper bhelp = new BeanHelper();
/*     */   private static final int GETID = 0;
/*     */   private static final int SETID = 1;
/*  42 */   ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
/*     */ 
/*     */   public static BeanHelper getInstance() {
/*  45 */     return bhelp;
/*     */   }
/*     */ 
/*     */   protected static PropertyDescriptor[] getPropertyDescriptor(Class beanCls)
/*     */   {
/*     */     try
/*     */     {
/*  53 */       BeanInfo beanInfo = Introspector.getBeanInfo(beanCls);
/*  54 */       return beanInfo.getPropertyDescriptors();
/*     */     } catch (IntrospectionException e) {
/*  56 */       Logger.error("Failed getPropertyDescriptor", e);
/*  57 */       throw new RuntimeException("Failed to instrospect bean: " + beanCls, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static List<String> getPropertys(Object bean)
/*     */   {
/*  63 */     return Arrays.asList(getInstance().getPropertiesAry(bean));
/*     */   }
/*     */ 
/*     */   public String[] getPropertiesAry(Object bean)
/*     */   {
/*  68 */     Map cMethod = null;
/*  69 */     this.rwl.readLock().lock();
/*     */     try {
/*  71 */       cMethod = cacheMethod(bean.getClass());
/*     */     } finally {
/*  73 */       this.rwl.readLock().unlock();
/*     */     }
/*  75 */     String[] retProps = (String[])((Map)cMethod.get(Integer.valueOf(1))).keySet().toArray(new String[0]);
/*     */ 
/*  77 */     return retProps;
/*     */   }
/*     */ 
/*     */   public static Object getProperty(Object bean, String propertyName)
/*     */   {
/*     */     try {
/*  83 */       Method method = getInstance().getMethod(bean, propertyName, false);
/*  84 */       if (method == null)
/*  85 */         return null;
/*  86 */       return method.invoke(bean, NULL_ARGUMENTS);
/*     */     } catch (Exception e) {
/*  88 */       String errStr = "Failed to get property: " + propertyName;
/*  89 */       Logger.warn(errStr, e);
/*  90 */       throw new RuntimeException(errStr, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Method getMethod(Object bean, String propertyName) {
/*  95 */     return getInstance().getMethod(bean, propertyName, true);
/*     */   }
/*     */ 
/*     */   private Method getMethod(Object bean, String propertyName, boolean isSetMethod)
/*     */   {
/* 101 */     Method method = null;
/* 102 */     this.rwl.readLock().lock();
/* 103 */     Map cMethod = null;
/*     */     try {
/* 105 */       cMethod = cacheMethod(bean.getClass());
/*     */     } finally {
/* 107 */       this.rwl.readLock().unlock();
/*     */     }
/* 109 */     if (isSetMethod)
/* 110 */       method = (Method)((Map)cMethod.get(Integer.valueOf(1))).get(propertyName);
/*     */     else {
/* 112 */       method = (Method)((Map)cMethod.get(Integer.valueOf(0))).get(propertyName);
/*     */     }
/* 114 */     return method;
/*     */   }
/*     */ 
/*     */   private Map<Integer, Map<String, Method>> cacheMethod(Class beanCls) {
/* 118 */     String key = beanCls.getName();
/* 119 */     Map cMethod = (Map)cache.get(key);
/* 120 */     if (cMethod == null) {
/* 121 */       this.rwl.readLock().unlock();
/* 122 */       this.rwl.writeLock().lock();
/*     */       try {
/* 124 */         cMethod = (Map)cache.get(key);
/* 125 */         if (cMethod == null) {
/* 126 */           cMethod = new HashMap();
/* 127 */           Map getMap = new HashMap();
/* 128 */           Map setMap = new HashMap();
/* 129 */           cMethod.put(Integer.valueOf(0), getMap);
/* 130 */           cMethod.put(Integer.valueOf(1), setMap);
/* 131 */           cache.put(key, cMethod);
/* 132 */           PropertyDescriptor[] pdescriptor = getPropertyDescriptor(beanCls);
/* 133 */           for (PropertyDescriptor pd : pdescriptor) {
/* 134 */             if (pd.getReadMethod() != null) {
/* 135 */               getMap.put(pd.getName().toLowerCase(), pd.getReadMethod());
/*     */             }
/* 137 */             if (pd.getWriteMethod() != null)
/* 138 */               setMap.put(pd.getName().toLowerCase(), pd.getWriteMethod());
/*     */           }
/*     */         }
/*     */       }
/*     */       finally {
/* 143 */         this.rwl.readLock().lock();
/* 144 */         this.rwl.writeLock().unlock();
/*     */       }
/*     */     }
/* 147 */     return cMethod;
/*     */   }
/*     */ 
/*     */   public static void invokeMethod(Object bean, Method method, Object value) {
/*     */     try {
/* 152 */       if (method == null)
/* 153 */         return;
/* 154 */       Object[] arguments = { value };
/* 155 */       method.invoke(bean, arguments);
/*     */     } catch (Exception e) {
/* 157 */       String errStr = "Failed to set property: " + method.getName();
/* 158 */       Logger.error(errStr, e);
/* 159 */       throw new RuntimeException(errStr, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setProperty(Object bean, String propertyName, Object value)
/*     */   {
/*     */     try {
/* 166 */       Method method = getInstance().getMethod(bean, propertyName, true);
/* 167 */       if (method == null)
/* 168 */         return;
/* 169 */       Object[] arguments = { value };
/* 170 */       method.invoke(bean, arguments);
/*     */     } catch (Exception e) {
/* 172 */       String errStr = "Failed to set property: " + propertyName + " on bean: " + bean.getClass().getName() + " with value:" + value;
/*     */ 
/* 175 */       Logger.error(errStr, e);
/* 176 */       throw new RuntimeException(errStr, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Method[] getAllGetMethod(Class beanCls, String[] fieldNames)
/*     */   {
/* 186 */     Method[] methods = null;
/* 187 */     Map cMethod = null;
/* 188 */     List al = new ArrayList();
/* 189 */     this.rwl.readLock().lock();
/*     */     try {
/* 191 */       cMethod = cacheMethod(beanCls);
/*     */     } finally {
/* 193 */       this.rwl.readLock().unlock();
/*     */     }
/* 195 */     Map map = (Map)cMethod.get(Integer.valueOf(0));
/*     */ 
/* 197 */     for (String str : fieldNames) {
/* 198 */       al.add(map.get(str));
/*     */     }
/* 200 */     methods = (Method[])al.toArray(new Method[al.size()]);
/* 201 */     return methods;
/*     */   }
/*     */ }

 