/*     */ package nc.vo.pub;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ public abstract class SuperVO extends CircularlyAccessibleValueObject
/*     */ {
/*     */   private static final long serialVersionUID = 1386231098909087720L;
/*  34 */   private static transient Map<Class, String[]> map = new HashMap();
/*     */ 
/*  36 */   private static transient ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  50 */     SuperVO vo = null;
/*     */     try {
/*  52 */       vo = (SuperVO)super.getClass().newInstance();
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/*  56 */     String[] fieldNames = getAttributeNames();
/*  57 */     if (fieldNames != null) {
/*  58 */       for (int i = 0; i < fieldNames.length; ++i) {
/*     */         try {
/*  60 */           vo.setAttributeValue(fieldNames[i], getAttributeValue(fieldNames[i]));
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*  67 */     vo.setDirty(isDirty());
/*  68 */     vo.setStatus(getStatus());
/*  69 */     return vo;
/*     */   }
/*     */ 
/*     */   public boolean equalsContent(Object obj)
/*     */   {
/*  81 */     if (obj == this)
/*  82 */       return true;
/*  83 */     if (obj == null)
/*  84 */       return false;
/*  85 */     if (obj.getClass() != super.getClass())
/*  86 */       return false;
/*  87 */     return equalsContent((SuperVO)obj, getAttributeNames());
/*     */   }
/*     */ 
/*     */   public boolean equalsContent(SuperVO vo, String[] fieldnames)
/*     */   {
/*  94 */     if ((fieldnames == null) || (vo == null)) {
/*  95 */       return false;
/*     */     }
/*  97 */     for (String field : fieldnames)
/*  98 */       if (!(isAttributeEquals(getAttributeValue(field), vo.getAttributeValue(field))))
/*     */       {
/* 100 */         return false;
/*     */       }
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   public String[] getAttributeNames()
/*     */   {
/* 109 */     rwl.readLock().lock();
/*     */     try {
/* 111 */       String[] arrayOfString = getAttributeAry();
/*     */ 
/* 114 */       return arrayOfString;
/*     */     }
/*     */     finally
/*     */     {
/* 113 */       rwl.readLock().unlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String[] getAttributeAry() {
/* 118 */     String[] arys = (String[])map.get(super.getClass());
/* 119 */     if (arys == null) {
/* 120 */       rwl.readLock().unlock();
/* 121 */       rwl.writeLock().lock();
/*     */       try {
/* 123 */         arys = (String[])map.get(super.getClass());
/* 124 */         if (arys == null)
/*     */         {
/* 126 */           Set set = new HashSet();
/* 127 */           String[] strAry = BeanHelper.getInstance().getPropertiesAry(this);
/*     */ 
/* 129 */           for (String str : strAry)
/* 130 */             if ((getPKFieldName() != null) && (str.equals("primarykey")))
/*     */             {
/* 132 */               set.add(getPKFieldName()); } else {
/* 133 */               if ((str.equals("status")) || (str.equals("dirty")))
/*     */                 continue;
/* 135 */               set.add(str);
/*     */             }
/* 137 */           arys = (String[])set.toArray(new String[set.size()]);
/* 138 */           map.put(super.getClass(), arys);
/*     */         }
/*     */       } finally {
/* 141 */         rwl.readLock().lock();
/* 142 */         rwl.writeLock().unlock();
/*     */       }
/*     */     }
/* 145 */     return arys;
/*     */   }
/*     */ 
/*     */   public Object getAttributeValue(String attributeName)
/*     */   {
/* 158 */     if ((attributeName == null) || (attributeName.length() == 0))
/* 159 */       return null;
/* 160 */     if ((getPKFieldName() != null) && (attributeName.equals(getPKFieldName())))
/* 161 */       attributeName = "primarykey";
/* 162 */     return BeanHelper.getProperty(this, attributeName);
/*     */   }
/*     */ 
/*     */   public abstract String getParentPKFieldName();
/*     */ 
/*     */   public abstract String getPKFieldName();
/*     */ 
/*     */   public abstract String getTableName();
/*     */ 
/*     */   private boolean isAttributeEquals(Object attrOld, Object attrNew)
/*     */   {
/* 197 */     if (attrOld == attrNew)
/* 198 */       return true;
/* 199 */     if ((attrOld == null) || (attrNew == null)) {
/* 200 */       return false;
/*     */     }
/* 202 */     return attrOld.equals(attrNew);
/*     */   }
/*     */ 
/*     */   public static void main(String[] s) {
/* 206 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   public void setAttributeValue(String attributeName, Object value)
/*     */   {
/* 213 */     if ((attributeName == null) || (attributeName.length() == 0))
/* 214 */       return;
/* 215 */     if ((getPKFieldName() != null) && (attributeName.equals(getPKFieldName())))
/* 216 */       attributeName = "primarykey";
/* 217 */     BeanHelper.setProperty(this, attributeName, value);
/*     */   }
/*     */ 
/*     */   public void setPrimaryKey(String key) {
/* 221 */     if (getPKFieldName() == null)
/* 222 */       return;
/* 223 */     BeanHelper.setProperty(this, getPKFieldName().toLowerCase(), key);
/*     */   }
/*     */ 
/*     */   public String getPrimaryKey() {
/* 227 */     if (getPKFieldName() == null)
/* 228 */       return null;
/* 229 */     return ((String)BeanHelper.getProperty(this, getPKFieldName().toLowerCase()));
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */     throws ValidationException
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getEntityName()
/*     */   {
/* 247 */     return null;
/*     */   }
/*     */ }

 