/*     */ package nc.vo.pub.report;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import nc.vo.ml.AbstractNCLangRes;
/*     */ import nc.vo.ml.NCLangRes4VoTransl;
/*     */ import nc.vo.pub.NullFieldException;
/*     */ import nc.vo.pub.ValidationException;
/*     */ import nc.vo.pub.ValueObject;
/*     */ import nc.vo.pub.lang.UFBoolean;
/*     */ 
/*     */ public class ReportModelVO extends ValueObject
/*     */ {
/*     */   public String id;
/*     */   public String pkCorp;
/*     */   public String pkTemplet;
/*     */   public String nodeCode;
/*     */   public String columnCode;
/*     */   public String columnSystem;
/*     */   public String columnUser;
/*     */   public Integer columnWidth;
/*     */   public Integer reportPos;
/*     */   public Integer itemOrder;
/*     */   public Integer columnType;
/*     */   public Integer dataType;
/*     */   public Integer selectType;
/*  36 */   public UFBoolean ifDefault = new UFBoolean(false);
/*  37 */   public UFBoolean ifMust = new UFBoolean(false);
/*  38 */   public UFBoolean ifNo = new UFBoolean(false);
/*     */   public String colExpressions;
/*     */   public Integer groupOrder;
/*     */   public Integer orderOrder;
/*     */   public String orderType;
/*     */   public UFBoolean ifSum;
/*     */   public UFBoolean isThMark;
/*     */   public String idColName;
/*     */   private String resid_system;
/*     */   private String resid_user;
/*     */ 
/*     */   public ReportModelVO()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ReportModelVO(String newId)
/*     */   {
/*  69 */     this.id = newId;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  79 */     Object o = null;
/*     */     try {
/*  81 */       o = super.clone(); } catch (Exception e) {
/*     */     }
/*  83 */     ReportModelVO reportModel = (ReportModelVO)o;
/*     */ 
/*  87 */     return reportModel;
/*     */   }
/*     */ 
/*     */   public String getColExpressions()
/*     */   {
/*  96 */     return this.colExpressions;
/*     */   }
/*     */ 
/*     */   public String getColumnCode()
/*     */   {
/* 105 */     return this.columnCode;
/*     */   }
/*     */ 
/*     */   public String getColumnSystem()
/*     */   {
/* 114 */     return this.columnSystem;
/*     */   }
/*     */ 
/*     */   public Integer getColumnType()
/*     */   {
/* 123 */     return this.columnType;
/*     */   }
/*     */ 
/*     */   public String getColumnUser()
/*     */   {
/* 132 */     return this.columnUser;
/*     */   }
/*     */ 
/*     */   public Integer getColumnWidth()
/*     */   {
/* 141 */     return this.columnWidth;
/*     */   }
/*     */ 
/*     */   public Integer getDataType()
/*     */   {
/* 150 */     return this.dataType;
/*     */   }
/*     */ 
/*     */   public String getEntityName()
/*     */   {
/* 160 */     return "ReportModel";
/*     */   }
/*     */ 
/*     */   public Integer getGroupOrder()
/*     */   {
/* 169 */     return this.groupOrder;
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/* 178 */     return this.id;
/*     */   }
/*     */ 
/*     */   public UFBoolean getIfDefault()
/*     */   {
/* 187 */     return this.ifDefault;
/*     */   }
/*     */ 
/*     */   public UFBoolean getIfMust()
/*     */   {
/* 196 */     return this.ifMust;
/*     */   }
/*     */ 
/*     */   public UFBoolean getIfNo()
/*     */   {
/* 205 */     return this.ifNo;
/*     */   }
/*     */ 
/*     */   public UFBoolean getIfSum()
/*     */   {
/* 214 */     return this.ifSum;
/*     */   }
/*     */ 
/*     */   public Integer getItemOrder()
/*     */   {
/* 223 */     return this.itemOrder;
/*     */   }
/*     */ 
/*     */   public String getNodeCode()
/*     */   {
/* 232 */     return this.nodeCode;
/*     */   }
/*     */ 
/*     */   public Integer getOrderOrder()
/*     */   {
/* 241 */     return this.orderOrder;
/*     */   }
/*     */ 
/*     */   public String getOrderType()
/*     */   {
/* 249 */     return this.orderType;
/*     */   }
/*     */ 
/*     */   public String getPkCorp()
/*     */   {
/* 258 */     return this.pkCorp;
/*     */   }
/*     */ 
/*     */   public String getPkTemplet()
/*     */   {
/* 267 */     return this.pkTemplet;
/*     */   }
/*     */ 
/*     */   public String getPrimaryKey()
/*     */   {
/* 277 */     return this.id;
/*     */   }
/*     */ 
/*     */   public Integer getReportPos()
/*     */   {
/* 286 */     return this.reportPos;
/*     */   }
/*     */ 
/*     */   public Integer getSelectType()
/*     */   {
/* 295 */     return this.selectType;
/*     */   }
/*     */ 
/*     */   public void setColExpressions(String newColExpressions)
/*     */   {
/* 305 */     this.colExpressions = newColExpressions;
/*     */   }
/*     */ 
/*     */   public void setColumnCode(String newColumnCode)
/*     */   {
/* 315 */     this.columnCode = newColumnCode;
/*     */   }
/*     */ 
/*     */   public void setColumnSystem(String newColumnSystem)
/*     */   {
/* 325 */     this.columnSystem = newColumnSystem;
/*     */   }
/*     */ 
/*     */   public void setColumnType(Integer newColumnType)
/*     */   {
/* 335 */     this.columnType = newColumnType;
/*     */   }
/*     */ 
/*     */   public void setColumnUser(String newColumnUser)
/*     */   {
/* 345 */     this.columnUser = newColumnUser;
/*     */   }
/*     */ 
/*     */   public void setColumnWidth(Integer newColumnWidth)
/*     */   {
/* 355 */     this.columnWidth = newColumnWidth;
/*     */   }
/*     */ 
/*     */   public void setDataType(Integer newDataType)
/*     */   {
/* 365 */     this.dataType = newDataType;
/*     */   }
/*     */ 
/*     */   public void setGroupOrder(Integer newGroupOrder)
/*     */   {
/* 375 */     this.groupOrder = newGroupOrder;
/*     */   }
/*     */ 
/*     */   public void setId(String newId)
/*     */   {
/* 385 */     this.id = newId;
/*     */   }
/*     */ 
/*     */   public void setIfDefault(UFBoolean newIfDefault)
/*     */   {
/* 395 */     this.ifDefault = newIfDefault;
/*     */   }
/*     */ 
/*     */   public void setIfMust(UFBoolean newIfMust)
/*     */   {
/* 405 */     this.ifMust = newIfMust;
/*     */   }
/*     */ 
/*     */   public void setIfNo(UFBoolean newIfNo)
/*     */   {
/* 415 */     this.ifNo = newIfNo;
/*     */   }
/*     */ 
/*     */   public void setIfSum(UFBoolean newIfSum)
/*     */   {
/* 425 */     this.ifSum = newIfSum;
/*     */   }
/*     */ 
/*     */   public void setItemOrder(Integer newItemOrder)
/*     */   {
/* 435 */     this.itemOrder = newItemOrder;
/*     */   }
/*     */ 
/*     */   public void setNodeCode(String newNodeCode)
/*     */   {
/* 445 */     this.nodeCode = newNodeCode;
/*     */   }
/*     */ 
/*     */   public void setOrderOrder(Integer newOrderOrder)
/*     */   {
/* 455 */     this.orderOrder = newOrderOrder;
/*     */   }
/*     */ 
/*     */   public void setOrderType(String newOrderType)
/*     */   {
/* 464 */     this.orderType = newOrderType;
/*     */   }
/*     */ 
/*     */   public void setPkCorp(String newPkCorp)
/*     */   {
/* 474 */     this.pkCorp = newPkCorp;
/*     */   }
/*     */ 
/*     */   public void setPkTemplet(String newPkTemplet)
/*     */   {
/* 484 */     this.pkTemplet = newPkTemplet;
/*     */   }
/*     */ 
/*     */   public void setPrimaryKey(String newId)
/*     */   {
/* 494 */     this.id = newId;
/*     */   }
/*     */ 
/*     */   public void setReportPos(Integer newReportPos)
/*     */   {
/* 504 */     this.reportPos = newReportPos;
/*     */   }
/*     */ 
/*     */   public void setSelectType(Integer newSelectType)
/*     */   {
/* 514 */     this.selectType = newSelectType;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 521 */     return this.columnSystem;
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */     throws ValidationException
/*     */   {
/* 532 */     ArrayList errFields = new ArrayList();
/*     */ 
/* 534 */     if (this.id == null) {
/* 535 */       errFields.add(new String("id"));
/*     */     }
/* 537 */     if (this.pkCorp == null) {
/* 538 */       errFields.add(new String("pkCorp"));
/*     */     }
/* 540 */     if (this.pkTemplet == null) {
/* 541 */       errFields.add(new String("pkTemplet"));
/*     */     }
/* 543 */     if (this.columnCode == null) {
/* 544 */       errFields.add(new String("columnCode"));
/*     */     }
/* 546 */     if (this.orderType == null) {
/* 547 */       errFields.add(new String("orderType"));
/*     */     }
/* 549 */     if (this.columnType == null) {
/* 550 */       errFields.add(new String("columnType"));
/*     */     }
/* 552 */     if (this.ifDefault == null) {
/* 553 */       errFields.add(new String("ifDefault"));
/*     */     }
/* 555 */     if (this.dataType == null) {
/* 556 */       errFields.add(new String("dataType"));
/*     */     }
/* 558 */     if (this.ifMust == null) {
/* 559 */       errFields.add(new String("ifMust"));
/*     */     }
/* 561 */     if (this.selectType == null) {
/* 562 */       errFields.add(new String("selectType"));
/*     */     }
/* 564 */     if (this.ifNo == null) {
/* 565 */       errFields.add(new String("ifNo"));
/*     */     }
/* 567 */     if (this.columnSystem == null) {
/* 568 */       errFields.add(new String("columnSystem"));
/*     */     }
/* 570 */     if (this.columnUser == null) {
/* 571 */       errFields.add(new String("columnUser"));
/*     */     }
/* 573 */     if (this.columnWidth == null) {
/* 574 */       errFields.add(new String("columnWidth"));
/*     */     }
/* 576 */     if (this.itemOrder == null) {
/* 577 */       errFields.add(new String("itemOrder"));
/*     */     }
/* 579 */     if (this.reportPos == null) {
/* 580 */       errFields.add(new String("reportPos"));
/*     */     }
/* 582 */     if (this.ifSum == null) {
/* 583 */       errFields.add(new String("ifSum"));
/*     */     }
/*     */ 
/* 591 */     StringBuffer message = new StringBuffer();
/* 592 */     message.append(NCLangRes4VoTransl.getNCLangRes().getStrByID("common", "MC11") + ":");
/* 593 */     if (errFields.size() > 0) {
/* 594 */       String[] temp = (String[])errFields.toArray(new String[0]);
/* 595 */       message.append(temp[0]);
/* 596 */       for (int i = 1; i < temp.length; i++) {
/* 597 */         message.append(",");
/* 598 */         message.append(temp[i]);
/*     */       }
/*     */ 
/* 601 */       throw new NullFieldException(message.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getResid_system()
/*     */   {
/* 609 */     return this.resid_system;
/*     */   }
/*     */ 
/*     */   public void setResid_system(String resid_system)
/*     */   {
/* 615 */     this.resid_system = resid_system;
/*     */   }
/*     */ 
/*     */   public String getResid_user()
/*     */   {
/* 621 */     return this.resid_user;
/*     */   }
/*     */ 
/*     */   public void setResid_user(String resid_user)
/*     */   {
/* 627 */     this.resid_user = resid_user;
/*     */   }
/*     */   public UFBoolean getIsThMark() {
/* 630 */     if (this.isThMark == null) {
/* 631 */       return UFBoolean.FALSE;
/*     */     }
/* 633 */     return this.isThMark;
/*     */   }
/*     */   public void setIsThMark(UFBoolean isThMark) {
/* 636 */     this.isThMark = isThMark;
/*     */   }
/*     */ 
/*     */   public String getIdColName() {
/* 640 */     return this.idColName;
/*     */   }
/*     */ 
/*     */   public void setIdColName(String idColName) {
/* 644 */     this.idColName = idColName;
/*     */   }
/*     */ }