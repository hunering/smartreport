/*    */ package nc.ui.trade.report.sort;
/*    */ 
/*    */ import nc.vo.trade.report.TableField;
/*    */ 
/*    */ public class SortListItem
/*    */ {
/* 18 */   private TableField tf = null;
/*    */ 
/* 20 */   private boolean asc = false;
/*    */ 
/*    */   public SortListItem()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SortListItem(TableField tf)
/*    */   {
/* 30 */     this.tf = tf;
/*    */   }
/*    */ 
/*    */   public TableField getTableField()
/*    */   {
/* 35 */     return this.tf;
/*    */   }
/*    */ 
/*    */   public void setTableField(TableField tf1)
/*    */   {
/* 40 */     this.tf = tf1;
/*    */   }
/*    */ 
/*    */   public boolean isAsc()
/*    */   {
/* 45 */     return this.asc;
/*    */   }
/*    */ 
/*    */   public void setAsc(boolean asc)
/*    */   {
/* 50 */     this.asc = asc;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 60 */     return this.tf.getFieldShowName();
/*    */   }
/*    */ }