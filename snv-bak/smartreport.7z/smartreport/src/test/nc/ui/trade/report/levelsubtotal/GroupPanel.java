/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import javax.swing.BoxLayout;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UILabel;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.style.Style;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class GroupPanel extends UIPanel
/*     */ {
/*     */   private UIPanel topPane;
/*     */   private UIPanel bottomPane;
/*     */   private GroupListPanel groupListPane;
/*  29 */   private TableField[] allGroupCols = null;
/*     */ 
/*  31 */   private TableField[] groupCols = null;
/*     */ 
/*     */   public GroupPanel(TableField[] allGroupCols, TableField[] groupCols)
/*     */   {
/*  39 */     this.allGroupCols = allGroupCols;
/*  40 */     this.groupCols = groupCols;
/*  41 */     initLayout();
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/*  49 */     setLayout(new BoxLayout(this, 1));
/*  50 */     add(getTopPane());
/*  51 */     add(getGroupListPanel());
/*  52 */     add(getBottomPane());
/*     */   }
/*     */ 
/*     */   protected UIPanel getBottomPane()
/*     */   {
/*  60 */     if (this.bottomPane == null)
/*     */     {
/*  62 */       this.bottomPane = new UIPanel();
/*  63 */       this.bottomPane.setLayout(new BorderLayout());
/*  64 */       UILabel tipLabel = new UILabel();
/*  65 */       tipLabel.setBackground(Style.getColor(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000136")));
/*  66 */       tipLabel.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000137"));
/*     */ 
/*  68 */       this.bottomPane.add(tipLabel);
/*     */     }
/*  70 */     return this.bottomPane;
/*     */   }
/*     */ 
/*     */   protected UIPanel getTopPane()
/*     */   {
/*  78 */     if (this.topPane == null)
/*     */     {
/*  80 */       this.topPane = new UIPanel();
/*  81 */       this.topPane.setLayout(new BorderLayout());
/*  82 */       UILabel label = new UILabel();
/*  83 */       label.setHorizontalAlignment(0);
/*  84 */       label.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000138"));
/*  85 */       this.topPane.add(label);
/*     */     }
/*  87 */     return this.topPane;
/*     */   }
/*     */ 
/*     */   protected GroupListPanel getGroupListPanel()
/*     */   {
/*  95 */     if (this.groupListPane == null)
/*     */     {
/*  97 */       this.groupListPane = new GroupListPanel(this.allGroupCols, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000139"), this.groupCols, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000140"));
/*     */     }
/*     */ 
/* 100 */     return this.groupListPane;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */   }
/*     */ }