/*    */ package nc.ui.trade.report.levelsubtotal;
/*    */ 
/*    */ import nc.vo.pub.BusinessException;
/*    */ 
/*    */ public class CodeLevelSettingException extends BusinessException
/*    */ {
/*    */   public CodeLevelSettingException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CodeLevelSettingException(String s)
/*    */   {
/* 30 */     super(s);
/*    */   }
/*    */ }