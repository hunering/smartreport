/*    */ package nc.ui.trade.report.levelsubtotal;
/*    */ 
/*    */ import javax.swing.AbstractCellEditor;
/*    */ 
/*    */ public class SupplementEditor extends AbstractCellEditor
/*    */ {
/*    */   public SupplementEditor()
/*    */   {
/* 23 */     initLayout();
/*    */   }
/*    */ 
/*    */   private void initLayout()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Object getCellEditorValue()
/*    */   {
/* 43 */     return null;
/*    */   }
/*    */ }