/*     */ package nc.ui.trade.report.columnfilter;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UIDialog;
/*     */ import nc.ui.pub.beans.UILabel;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.UITextField;
/*     */ 
/*     */ public class RenameDialog extends UIDialog
/*     */ {
/*     */   private UIPanel bottomPane;
/*     */   private UIPanel centerPane;
/*     */   private UITextField nameField;
/*     */   private UIButton okBt;
/*     */   private UIButton cancelBt;
/*  39 */   private ButtonEventHandler eventHandler = new ButtonEventHandler();
/*     */ 
/*     */   public RenameDialog(Container parent, String title)
/*     */   {
/*  47 */     super(parent, title);
/*  48 */     initLayout();
/*  49 */     initListeners();
/*     */   }
/*     */ 
/*     */   public void setOldName(String name)
/*     */   {
/*  54 */     getNameField().setText(name);
/*     */   }
/*     */ 
/*     */   public String getNewName()
/*     */   {
/*  59 */     return getNameField().getText();
/*     */   }
/*     */ 
/*     */   private void initListeners()
/*     */   {
/*  67 */     getOkBt().addActionListener(this.eventHandler);
/*  68 */     getCancelBt().addActionListener(this.eventHandler);
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/*  77 */     Container container = getContentPane();
/*  78 */     container.setLayout(new BorderLayout());
/*  79 */     container.add(getBottomPane(), "South");
/*  80 */     container.add(getCenterPane(), "Center");
/*  81 */     setSize(new Dimension(200, 80));
/*     */   }
/*     */ 
/*     */   private UIPanel getCenterPane()
/*     */   {
/*  89 */     if (this.centerPane == null)
/*     */     {
/*  91 */       this.centerPane = new UIPanel();
/*  92 */       UILabel label = new UILabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000056"));
/*  93 */       this.centerPane.add(label);
/*  94 */       this.centerPane.add(getNameField());
/*     */     }
/*  96 */     return this.centerPane;
/*     */   }
/*     */ 
/*     */   private UITextField getNameField()
/*     */   {
/* 104 */     if (this.nameField == null)
/*     */     {
/* 106 */       this.nameField = new UITextField();
/* 107 */       this.nameField.setPreferredSize(new Dimension(100, 20));
/*     */     }
/* 109 */     return this.nameField;
/*     */   }
/*     */ 
/*     */   private UIPanel getBottomPane()
/*     */   {
/* 117 */     if (this.bottomPane == null)
/*     */     {
/* 119 */       this.bottomPane = new UIPanel();
/* 120 */       this.bottomPane.add(getOkBt());
/* 121 */       this.bottomPane.add(getCancelBt());
/*     */     }
/* 123 */     return this.bottomPane;
/*     */   }
/*     */ 
/*     */   private UIButton getOkBt()
/*     */   {
/* 128 */     if (this.okBt == null)
/*     */     {
/* 130 */       this.okBt = new UIButton();
/* 131 */       this.okBt.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000044"));
/*     */     }
/* 133 */     return this.okBt;
/*     */   }
/*     */ 
/*     */   private UIButton getCancelBt()
/*     */   {
/* 138 */     if (this.cancelBt == null)
/*     */     {
/* 140 */       this.cancelBt = new UIButton();
/* 141 */       this.cancelBt.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000008"));
/*     */     }
/* 143 */     return this.cancelBt;
/*     */   }
/*     */ 
/*     */   class ButtonEventHandler
/*     */     implements ActionListener
/*     */   {
/*     */     ButtonEventHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 156 */       if (e.getSource() == RenameDialog.this.okBt)
/*     */       {
/* 158 */         RenameDialog.this.closeOK();
/*     */       }
/* 160 */       else if (e.getSource() == RenameDialog.this.cancelBt)
/*     */       {
/* 162 */         RenameDialog.this.closeCancel();
/*     */       }
/*     */     }
/*     */   }
/*     */ }