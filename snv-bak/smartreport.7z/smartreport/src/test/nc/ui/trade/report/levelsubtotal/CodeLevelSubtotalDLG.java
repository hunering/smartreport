/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerModel;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.SpringLayout;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UIComboBox;
/*     */ import nc.ui.pub.beans.UILabel;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.UIRadioButton;
/*     */ import nc.ui.pub.beans.UISpinner;
/*     */ import nc.ui.pub.beans.UITextField;
/*     */ import nc.ui.pub.beans.dialog.DialogThemePanel;
/*     */ import nc.ui.pub.beans.dialog.StandardUIDialog;
/*     */ import nc.ui.pub.beans.layout.SpringUtilities;
/*     */ import nc.ui.trade.component.ListToListPanel;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class CodeLevelSubtotalDLG extends StandardUIDialog
/*     */ {
/*  42 */   private TableField[] dataCols = null;
/*     */ 
/*  44 */   private TableField[] sumCols = null;
/*     */ 
/*  46 */   private TableField[] allSumCols = null;
/*     */ 
/*  48 */   private ListToListPanel sumPane = null;
/*     */ 
/*  50 */   private UIPanel filterPane = null;
/*     */ 
/*  52 */   private UIPanel filterEditorPane = null;
/*     */ 
/*  54 */   private UITextField filterField = null;
/*     */ 
/*  56 */   private UIButton filterBt = null;
/*     */ 
/*  58 */   private UITextField levelModeField = null;
/*     */ 
/*  60 */   private UISpinner beginLevelSpinner = null;
/*     */ 
/*  62 */   private UISpinner endLevelSpinner = null;
/*     */ 
/*  64 */   private ListToListPanel groupPane = null;
/*     */ 
/*  66 */   private UIPanel settingPane = null;
/*     */ 
/*  68 */   private ButtonGroup sumDirection = null;
/*     */ 
/*  70 */   private UIPanel sumDirPane = null;
/*     */ 
/*  73 */   private UIRadioButton upBt = null;
/*     */ 
/*  75 */   private UIRadioButton downBt = null;
/*     */ 
/*  77 */   private UIComboBox levelField = null;
/*     */ 
/*  79 */   private HashMap helpMsgMap = null;
/*     */ 
/*  81 */   private CodeLevelSubtotalDescription resultDesc = null;
/*     */ 
/*  83 */   private AllEventHandler allEventHandler = new AllEventHandler();
/*     */ 
/*     */   public CodeLevelSubtotalDLG(Container parent, TableField[] dataCols, TableField[] allSumCols, TableField[] sumCols)
/*     */   {
/* 107 */     super(parent);
/* 108 */     this.dataCols = dataCols;
/* 109 */     this.sumCols = sumCols;
/* 110 */     this.allSumCols = allSumCols;
/* 111 */     initHelpMsgMap();
/* 112 */     initLayout();
/* 113 */     initListeners();
/*     */   }
/*     */ 
/*     */   private void initHelpMsgMap()
/*     */   {
/* 121 */     this.helpMsgMap = new HashMap();
/* 122 */     this.helpMsgMap.put("filter", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000102") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000103") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000104"));
/*     */ 
/* 125 */     this.helpMsgMap.put("levelmode", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000105") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000106") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000107"));
/*     */ 
/* 128 */     this.helpMsgMap.put("levelcol", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000108"));
/* 129 */     this.helpMsgMap.put("groupcol", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000109") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000110") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000111"));
/*     */ 
/* 132 */     this.helpMsgMap.put("beginlevel", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000112") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000113"));
/*     */ 
/* 134 */     this.helpMsgMap.put("endlevel", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000114") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000115"));
/*     */ 
/* 136 */     this.helpMsgMap.put("sumdir", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000116") + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000117"));
/*     */ 
/* 139 */     this.helpMsgMap.put("containsorigin", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000118"));
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/* 148 */     setSize(new Dimension(750, 720));
/* 149 */     setErrorMsgSize(new Dimension(680, 500));
/*     */ 
/* 151 */     setResizable(true);
/*     */ 
/* 153 */     this.themePanel.setTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000119"));
/* 154 */     this.themePanel.setDetailTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000120"));
/*     */ 
/* 156 */     Container contentPane = this.editorPanel;
/* 157 */     contentPane.setLayout(new BoxLayout(contentPane, 1));
/* 158 */     contentPane.add(getSumPane());
/* 159 */     contentPane.add(getFilterPane());
/* 160 */     contentPane.add(getGroupPane());
/* 161 */     contentPane.add(getSettingPane());
/*     */ 
/* 163 */     getFilterPane().setVisible(false);
/*     */   }
/*     */ 
/*     */   private void initListeners()
/*     */   {
/* 169 */     getFilterBt().addActionListener(this.allEventHandler);
/*     */   }
/*     */ 
/*     */   private JSpinner getBeginLevelSpinner()
/*     */   {
/* 177 */     if (this.beginLevelSpinner == null)
/*     */     {
/* 179 */       SpinnerModel model = new SpinnerNumberModel();
/* 180 */       this.beginLevelSpinner = new UISpinner(model);
/*     */     }
/* 182 */     return this.beginLevelSpinner;
/*     */   }
/*     */ 
/*     */   private JSpinner getEndLevelSpinner()
/*     */   {
/* 190 */     if (this.endLevelSpinner == null)
/*     */     {
/* 192 */       SpinnerModel model = new SpinnerNumberModel();
/* 193 */       this.endLevelSpinner = new UISpinner(model);
/*     */     }
/* 195 */     return this.endLevelSpinner;
/*     */   }
/*     */ 
/*     */   private UIPanel getFilterEditorPane()
/*     */   {
/* 202 */     if (this.filterEditorPane == null)
/*     */     {
/* 204 */       this.filterEditorPane = new UIPanel();
/* 205 */       this.filterEditorPane.setLayout(new BoxLayout(this.filterEditorPane, 0));
/* 206 */       this.filterEditorPane.add(getFilterField());
/* 207 */       this.filterEditorPane.add(getFilterBt());
/*     */     }
/* 209 */     return this.filterEditorPane;
/*     */   }
/*     */ 
/*     */   private UITextField getLevelModeField()
/*     */   {
/* 219 */     if (this.levelModeField == null)
/*     */     {
/* 221 */       this.levelModeField = new UITextField();
/* 222 */       this.levelModeField.setText("2/2/2/2/2");
/*     */     }
/* 224 */     return this.levelModeField;
/*     */   }
/*     */ 
/*     */   private ListToListPanel getSumPane()
/*     */   {
/* 233 */     if (this.sumPane == null)
/*     */     {
/* 235 */       this.sumPane = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000121"), this.allSumCols, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000122"), this.sumCols);
/*     */     }
/* 237 */     return this.sumPane;
/*     */   }
/*     */ 
/*     */   private ListToListPanel getGroupPane()
/*     */   {
/* 245 */     if (this.groupPane == null)
/*     */     {
/* 247 */       this.groupPane = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000123"), this.dataCols, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000099"), null);
/*     */     }
/* 249 */     return this.groupPane;
/*     */   }
/*     */ 
/*     */   public CodeLevelSubtotalDescription getDescription()
/*     */   {
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   private UIPanel getSettingPane()
/*     */   {
/* 261 */     if (this.settingPane == null)
/*     */     {
/* 263 */       this.settingPane = new UIPanel();
/* 264 */       this.settingPane.setLayout(new SpringLayout());
/*     */ 
/* 267 */       this.settingPane.add(getTipLabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000124"), "levelcol"));
/* 268 */       this.settingPane.add(getLevelField());
/*     */ 
/* 271 */       this.settingPane.add(getTipLabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000125"), "levelmode"));
/* 272 */       this.settingPane.add(getLevelModeField());
/*     */ 
/* 277 */       this.settingPane.add(getTipLabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000126"), "beginlevel"));
/* 278 */       this.settingPane.add(getBeginLevelSpinner());
/*     */ 
/* 281 */       this.settingPane.add(getTipLabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000127"), "endlevel"));
/* 282 */       this.settingPane.add(getEndLevelSpinner());
/*     */ 
/* 285 */       this.settingPane.add(getTipLabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000128"), "sumdir"));
/* 286 */       this.settingPane.add(getSumDirPane());
/*     */ 
/* 292 */       getSumDirection();
/* 293 */       SpringUtilities.makeCompactGrid(this.settingPane, 5, 2, 10, 10, 20, 10);
/*     */     }
/* 295 */     return this.settingPane;
/*     */   }
/*     */ 
/*     */   private UILabel getTipLabel(String text, String tipId)
/*     */   {
/* 300 */     UILabel label = new UILabel(text);
/* 301 */     label.setToolTipText("" + this.helpMsgMap.get(tipId));
/* 302 */     return label;
/*     */   }
/*     */ 
/*     */   private UIButton getFilterBt()
/*     */   {
/* 309 */     if (this.filterBt == null)
/*     */     {
/* 311 */       this.filterBt = new UIButton();
/* 312 */       this.filterBt.setText("...");
/*     */     }
/* 314 */     return this.filterBt;
/*     */   }
/*     */ 
/*     */   private UITextField getFilterField()
/*     */   {
/* 321 */     if (this.filterField == null)
/*     */     {
/* 323 */       this.filterField = new UITextField(20);
/* 324 */       this.filterField.setEditable(false);
/*     */     }
/* 326 */     return this.filterField;
/*     */   }
/*     */ 
/*     */   private ButtonGroup getSumDirection()
/*     */   {
/* 334 */     if (this.sumDirection == null)
/*     */     {
/* 336 */       this.sumDirection = new ButtonGroup();
/* 337 */       this.sumDirection.add(getUpBt());
/* 338 */       this.sumDirection.add(getDownBt());
/*     */     }
/* 340 */     return this.sumDirection;
/*     */   }
/*     */ 
/*     */   private UIPanel getSumDirPane()
/*     */   {
/* 348 */     if (this.sumDirPane == null)
/*     */     {
/* 350 */       this.sumDirPane = new UIPanel();
/* 351 */       this.sumDirPane.add(getUpBt());
/* 352 */       this.sumDirPane.add(getDownBt());
/*     */     }
/* 354 */     return this.sumDirPane;
/*     */   }
/*     */ 
/*     */   private UIRadioButton getDownBt()
/*     */   {
/* 362 */     if (this.downBt == null)
/*     */     {
/* 364 */       this.downBt = new UIRadioButton();
/* 365 */       this.downBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000129"));
/*     */     }
/* 367 */     return this.downBt;
/*     */   }
/*     */ 
/*     */   private UIRadioButton getUpBt()
/*     */   {
/* 375 */     if (this.upBt == null)
/*     */     {
/* 377 */       this.upBt = new UIRadioButton();
/* 378 */       this.upBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000130"));
/* 379 */       this.upBt.setSelected(true);
/*     */     }
/* 381 */     return this.upBt;
/*     */   }
/*     */ 
/*     */   private UIPanel getFilterPane()
/*     */   {
/* 388 */     if (this.filterPane == null)
/*     */     {
/* 390 */       this.filterPane = new UIPanel();
/* 391 */       this.filterPane.setBorder(BorderFactory.createTitledBorder(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000131")));
/* 392 */       this.filterPane.setLayout(new BoxLayout(this.filterPane, 0));
/* 393 */       this.filterPane.add(Box.createGlue());
/* 394 */       this.filterPane.add(getFilterEditorPane());
/* 395 */       this.filterPane.add(Box.createHorizontalStrut(20));
/* 396 */       this.filterPane.add(getTipLabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000132"), "filter"));
/* 397 */       this.filterPane.add(Box.createGlue());
/*     */     }
/* 399 */     return this.filterPane;
/*     */   }
/*     */ 
/*     */   private UIComboBox getLevelField()
/*     */   {
/* 404 */     if (this.levelField == null)
/*     */     {
/* 406 */       if (this.dataCols == null)
/* 407 */         this.levelField = new UIComboBox();
/*     */       else
/* 409 */         this.levelField = new UIComboBox(this.dataCols);
/*     */     }
/* 411 */     return this.levelField;
/*     */   }
/*     */ 
/*     */   private void setResultDescription() throws CodeLevelSettingException
/*     */   {
/* 416 */     this.resultDesc = new CodeLevelSubtotalDescription();
/* 417 */     if ((getLevelModeField().getText() == null) || (getLevelModeField().getText().trim().equals("")))
/* 418 */       throw new CodeLevelSettingException(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000133"));
/* 419 */     this.resultDesc.setLevelMode(getLevelModeField().getText());
/* 420 */     if (getLevelField().getSelectedIndex() == -1)
/* 421 */       throw new CodeLevelSettingException(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000134"));
/* 422 */     this.resultDesc.setLevelCol(((TableField)getLevelField().getSelectdItemValue()).getFieldName());
/* 423 */     if ((getSumPane().getRightData() == null) || (getSumPane().getRightData().length == 0))
/* 424 */       throw new CodeLevelSettingException(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000135"));
/* 425 */     this.resultDesc.setSumCols(extractKeysFromFields((TableField[])getSumPane().getRightData()));
/* 426 */     this.resultDesc.setBeginLevel(((Integer)getBeginLevelSpinner().getValue()).intValue());
/* 427 */     this.resultDesc.setEndLevel(((Integer)getEndLevelSpinner().getValue()).intValue());
/* 428 */     if (getFilterField().getText() != null)
/* 429 */       this.resultDesc.setFilterFormula(getFilterField().getText());
/* 430 */     if ((getGroupPane().getRightData() != null) && (getGroupPane().getRightData().length != 0))
/*     */     {
/* 432 */       TableField[] fields = (TableField[])getSumPane().getRightData();
/* 433 */       String strGroup = "";
/* 434 */       for (int i = 0; i < fields.length; i++)
/*     */       {
/* 436 */         strGroup = strGroup + convertVOFieldNameToReportModelFieldName(fields[i].getFieldName());
/* 437 */         if (i != fields.length - 1)
/* 438 */           strGroup = strGroup + ",";
/*     */       }
/* 440 */       this.resultDesc.setGroupCol(strGroup);
/*     */     }
/* 442 */     this.resultDesc.setSumColUp(getUpBt().isSelected());
/*     */   }
/*     */ 
/*     */   private String convertVOFieldNameToReportModelFieldName(String voFieldName)
/*     */   {
/* 448 */     if (voFieldName.indexOf('.') == -1) {
/* 449 */       return voFieldName;
/*     */     }
/* 451 */     return voFieldName.substring(0, voFieldName.indexOf('.')) + "_" + voFieldName.substring(voFieldName.indexOf('.') + 1, voFieldName.length());
/*     */   }
/*     */ 
/*     */   private String[] extractKeysFromFields(TableField[] fields)
/*     */   {
/* 459 */     if ((fields == null) || (fields.length == 0))
/* 460 */       return null;
/* 461 */     String[] result = new String[fields.length];
/* 462 */     for (int i = 0; i < result.length; i++)
/*     */     {
/* 464 */       result[i] = fields[i].getFieldName();
/*     */     }
/* 466 */     return result;
/*     */   }
/*     */ 
/*     */   public CodeLevelSubtotalDescription getResultDesc()
/*     */   {
/* 473 */     return this.resultDesc;
/*     */   }
/*     */ 
/*     */   protected void complete() throws Exception
/*     */   {
/* 478 */     setResultDescription();
/*     */   }
/*     */ 
/*     */   class AllEventHandler
/*     */     implements ActionListener
/*     */   {
/*     */     AllEventHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  93 */       if (e.getSource() == CodeLevelSubtotalDLG.this.filterBt);
/*     */     }
/*     */   }
/*     */ }