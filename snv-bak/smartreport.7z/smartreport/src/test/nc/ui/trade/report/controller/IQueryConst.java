package nc.ui.trade.report.controller;

import java.util.HashMap;

public abstract interface IQueryConst
{
  public abstract String getConstDescription();

  public abstract HashMap getSqlWhereConstant();
}