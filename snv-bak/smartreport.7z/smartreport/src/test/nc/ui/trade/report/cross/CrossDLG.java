/*     */ package nc.ui.trade.report.cross;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.dnd.DropTargetContext;
/*     */ import java.awt.dnd.DropTargetDragEvent;
/*     */ import java.awt.dnd.DropTargetDropEvent;
/*     */ import java.awt.dnd.DropTargetEvent;
/*     */ import java.awt.dnd.DropTargetListener;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.border.EtchedBorder;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import nc.bs.logging.Logger;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UICheckBox;
/*     */ import nc.ui.pub.beans.UIList;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.UIScrollPane;
/*     */ import nc.ui.pub.beans.dialog.DialogThemePanel;
/*     */ import nc.ui.pub.beans.dialog.StandardUIDialog;
/*     */ import nc.ui.trade.report.controller.CrossInfo;
/*     */ import nc.vo.pub.report.ReportModelVO;
/*     */ 
/*     */ public class CrossDLG extends StandardUIDialog
/*     */   implements DropTargetListener, MouseMotionListener
/*     */ {
/*     */   private UIList list_content;
/*     */   private UIList list_column;
/*     */   private UIList list_row;
/*     */   private UIList source_list;
/*     */   private UIButton exchangeBt;
/*  61 */   private DialogEventHandler allEventHandler = new DialogEventHandler();
/*     */ 
/*  64 */   private ReportModelVO[] modelVOs = null;
/*     */   private UIPanel leftPanel;
/*     */   private UIPanel rightPanel;
/*     */   private UIPanel rowPanel;
/*     */   private UIPanel colPanel;
/*     */   private UIPanel valuePanel;
/*     */   private UIPanel funcPanel;
/*     */   private UICheckBox fuheBox;
/*     */   private CrossInfo result;
/*     */   private UIList curList;
/*  88 */   private UIList currentDragList = null;
/*     */ 
/*  90 */   private boolean onDrag = false;
/*     */ 
/*     */   public CrossDLG(Container parent, ReportModelVO[] modelVOs)
/*     */   {
/*  97 */     super(parent);
/*  98 */     this.modelVOs = modelVOs;
/*  99 */     initLayout();
/* 100 */     initListeners();
/* 101 */     initAllList();
/*     */   }
/*     */ 
/*     */   private void initListeners()
/*     */   {
/* 109 */     getExchangeBt().addActionListener(this.allEventHandler);
/* 110 */     getFuheBox().addItemListener(this.allEventHandler);
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/* 118 */     setSize(790, 575);
/* 119 */     setResizable(true);
/* 120 */     this.themePanel.setTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000074"));
/* 121 */     this.themePanel.setDetailTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000075"));
/* 122 */     setErrorMsgSize(new Dimension(700, 375));
/* 123 */     this.allEventHandler = new DialogEventHandler();
/* 124 */     setTitle(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000074"));
/* 125 */     this.editorPanel.setLayout(new BorderLayout());
/* 126 */     UIPanel pane = new UIPanel();
/* 127 */     pane.add(getLeftPanel(), "West");
/* 128 */     pane.add(getRightPanel(), "Center");
/* 129 */     this.editorPanel.add(pane, "Center");
/*     */   }
/*     */ 
/*     */   private void initData()
/*     */   {
/* 139 */     if ((this.modelVOs == null) || (this.modelVOs.length == 0))
/*     */     {
/* 141 */       return;
/*     */     }
/* 143 */     for (int i = 0; i < this.modelVOs.length; i++)
/*     */     {
/* 145 */       if (this.modelVOs[i].getSelectType().intValue() == 1)
/*     */       {
/* 147 */         ListItemWrapperObject ele = new ListItemWrapperObject();
/* 148 */         ele.setShowName(this.modelVOs[i].getColumnUser());
/* 149 */         ele.setTrueName(this.modelVOs[i].getColumnCode());
/* 150 */         ele.setDataType(this.modelVOs[i].getDataType().intValue());
/* 151 */         ele.setFuHe(false);
/* 152 */         ((DefaultListModel)this.source_list.getModel()).addElement(ele);
/*     */       }
/*     */     }
/* 155 */     ListItemWrapperObject ele = new ListItemWrapperObject();
/* 156 */     ele.setFuHe(false);
/* 157 */     ele.setShowName(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000076"));
/* 158 */     ele.setTrueName("&type");
/* 159 */     ele.setDataType(-1);
/* 160 */     ((DefaultListModel)this.list_column.getModel()).addElement(ele);
/*     */   }
/*     */ 
/*     */   private void doExchange()
/*     */   {
/* 217 */     ListModel tempM = this.list_row.getModel();
/*     */ 
/* 219 */     this.list_row.setModel(this.list_column.getModel());
/* 220 */     this.list_column.setModel(tempM);
/*     */   }
/*     */ 
/*     */   private void checkCanFuhe()
/*     */   {
/* 229 */     if ((this.curList == this.list_row) || (this.curList == this.list_column))
/*     */     {
/* 231 */       if (checkData() == 1)
/*     */       {
/* 233 */         this.fuheBox.setEnabled(true);
/* 234 */         this.fuheBox.setSelected(false);
/*     */       }
/* 236 */       else if (checkData() == 2)
/*     */       {
/* 238 */         this.fuheBox.setEnabled(true);
/* 239 */         this.fuheBox.setSelected(true);
/*     */       }
/*     */       else {
/* 242 */         this.fuheBox.setEnabled(false);
/*     */       }
/*     */     }
/* 245 */     else this.fuheBox.setEnabled(false);
/*     */   }
/*     */ 
/*     */   private int checkData()
/*     */   {
/* 253 */     if ((this.curList.getSelectedValues() != null) && (this.curList.getSelectedValues().length >= 2))
/*     */     {
/* 256 */       Object[] items = (Object[])this.curList.getSelectedValues();
/* 257 */       for (int i = 0; i < items.length; i++)
/*     */       {
/* 259 */         if (((ListItemWrapperObject)items[i]).getTrueName().equals("&type"))
/*     */         {
/* 261 */           return 0;
/*     */         }
/*     */       }
/* 263 */       return 1;
/*     */     }
/* 265 */     if ((this.curList.getSelectedValues() != null) && (this.curList.getSelectedValues().length == 1))
/*     */     {
/* 268 */       ListItemWrapperObject item = (ListItemWrapperObject)this.curList.getSelectedValue();
/*     */ 
/* 270 */       if ((!item.getTrueName().equals("&type")) && (item.isFuHe()))
/*     */       {
/* 272 */         return 2;
/*     */       }
/*     */     }
/* 275 */     return 0;
/*     */   }
/*     */ 
/*     */   private void setCrossInfoResult()
/*     */   {
/* 283 */     this.result = new CrossInfo();
/* 284 */     this.result.setCrossCols(getCrossCols());
/* 285 */     this.result.setCrossRows(getCrossRows());
/* 286 */     this.result.setCrossValues(getCrossValues());
/*     */   }
/*     */ 
/*     */   public CrossInfo getCrossInfoResult()
/*     */   {
/* 291 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void update(Graphics g)
/*     */   {
/* 301 */     paint(g);
/*     */   }
/*     */ 
/*     */   protected ListItemWrapperObject[] getCrossRows()
/*     */   {
/* 309 */     int size = this.list_row.getModel().getSize();
/*     */ 
/* 311 */     if (size == 0)
/* 312 */       return null;
/* 313 */     ArrayList al = new ArrayList();
/*     */ 
/* 315 */     for (int i = 0; i < size; i++)
/*     */     {
/* 317 */       al.add(this.list_row.getModel().getElementAt(i));
/*     */     }
/* 319 */     return (ListItemWrapperObject[])al.toArray(new ListItemWrapperObject[0]);
/*     */   }
/*     */ 
/*     */   protected ListItemWrapperObject[] getCrossCols()
/*     */   {
/* 328 */     int size = this.list_column.getModel().getSize();
/*     */ 
/* 330 */     if (size == 0)
/* 331 */       return null;
/* 332 */     ArrayList al = new ArrayList();
/* 333 */     for (int i = 0; i < size; i++)
/*     */     {
/* 335 */       al.add(this.list_column.getModel().getElementAt(i));
/*     */     }
/* 337 */     return (ListItemWrapperObject[])al.toArray(new ListItemWrapperObject[0]);
/*     */   }
/*     */ 
/*     */   protected ListItemWrapperObject[] getCrossValues()
/*     */   {
/* 346 */     int size = this.list_content.getModel().getSize();
/*     */ 
/* 348 */     if (size == 0)
/* 349 */       return null;
/* 350 */     ArrayList al = new ArrayList();
/* 351 */     for (int i = 0; i < size; i++)
/*     */     {
/* 353 */       al.add(this.list_content.getModel().getElementAt(i));
/*     */     }
/* 355 */     return (ListItemWrapperObject[])al.toArray(new ListItemWrapperObject[0]);
/*     */   }
/*     */ 
/*     */   private UIPanel getLeftPanel()
/*     */   {
/* 361 */     if (this.leftPanel == null)
/*     */     {
/* 363 */       this.leftPanel = new UIPanel();
/* 364 */       this.leftPanel.setLayout(new BorderLayout());
/* 365 */       this.leftPanel.setBorder(new TitledBorder(new EtchedBorder(), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000077"), 0, 0, null, null));
/*     */ 
/* 368 */       this.leftPanel.add(new UIScrollPane(getSource_list()));
/* 369 */       this.leftPanel.setPreferredSize(new Dimension(160, 400));
/*     */     }
/* 371 */     return this.leftPanel;
/*     */   }
/*     */ 
/*     */   private UIPanel getRightPanel()
/*     */   {
/* 376 */     if (this.rightPanel == null)
/*     */     {
/* 378 */       this.rightPanel = new UIPanel();
/* 379 */       this.rightPanel.setLayout(new GridLayout(2, 2));
/* 380 */       this.rightPanel.setBorder(new TitledBorder(new EtchedBorder(), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000011"), 0, 0, null, null));
/*     */ 
/* 383 */       this.rightPanel.add(getFuncPanel());
/* 384 */       UIScrollPane listColPane = new UIScrollPane(getList_column());
/* 385 */       listColPane.setBorder(BorderFactory.createTitledBorder(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000078")));
/* 386 */       this.rightPanel.add(listColPane);
/* 387 */       UIScrollPane listRowPane = new UIScrollPane(getList_row());
/* 388 */       listRowPane.setBorder(BorderFactory.createTitledBorder(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000079")));
/* 389 */       this.rightPanel.add(listRowPane);
/* 390 */       UIScrollPane listValuePane = new UIScrollPane(getList_content());
/* 391 */       listValuePane.setBorder(BorderFactory.createTitledBorder(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000080")));
/* 392 */       this.rightPanel.add(listValuePane);
/*     */     }
/*     */ 
/* 395 */     return this.rightPanel;
/*     */   }
/*     */ 
/*     */   private void initAllList()
/*     */   {
/* 401 */     ((DefaultListModel)this.source_list.getModel()).removeAllElements();
/* 402 */     ((DefaultListModel)this.list_row.getModel()).removeAllElements();
/* 403 */     ((DefaultListModel)this.list_column.getModel()).removeAllElements();
/* 404 */     ((DefaultListModel)this.list_content.getModel()).removeAllElements();
/*     */ 
/* 406 */     this.list_row.setCellRenderer(new CrossItemRender());
/* 407 */     this.list_column.setCellRenderer(new CrossItemRender());
/*     */ 
/* 409 */     new DropTarget(this.list_row, this);
/* 410 */     new DropTarget(this.list_column, this);
/* 411 */     new DropTarget(this.list_content, this);
/* 412 */     new DropTarget(this.source_list, this);
/*     */ 
/* 414 */     this.list_row.addMouseMotionListener(this);
/* 415 */     this.list_column.addMouseMotionListener(this);
/* 416 */     this.list_content.addMouseMotionListener(this);
/* 417 */     this.source_list.addMouseMotionListener(this);
/*     */ 
/* 419 */     initData();
/*     */   }
/*     */ 
/*     */   public UIPanel getColPanel()
/*     */   {
/* 428 */     if (this.colPanel == null)
/*     */     {
/* 430 */       this.colPanel = new UIPanel();
/*     */     }
/*     */ 
/* 433 */     return this.colPanel;
/*     */   }
/*     */ 
/*     */   public UIPanel getFuncPanel()
/*     */   {
/* 441 */     if (this.funcPanel == null)
/*     */     {
/* 443 */       this.funcPanel = new UIPanel();
/* 444 */       this.funcPanel.add(getExchangeBt());
/* 445 */       this.funcPanel.add(getFuheBox());
/*     */     }
/* 447 */     return this.funcPanel;
/*     */   }
/*     */ 
/*     */   public UIPanel getRowPanel()
/*     */   {
/* 455 */     if (this.rowPanel == null)
/*     */     {
/* 457 */       this.rowPanel = new UIPanel();
/* 458 */       JScrollPane scroll_row = new JScrollPane();
/* 459 */       this.rightPanel.add(scroll_row);
/*     */ 
/* 461 */       this.list_row = new DroppableList();
/* 462 */       this.list_row.setDragEnabled(true);
/* 463 */       this.list_row.addListSelectionListener(this.allEventHandler);
/*     */ 
/* 465 */       scroll_row.setViewportView(this.list_row);
/*     */     }
/* 467 */     return this.rowPanel;
/*     */   }
/*     */ 
/*     */   public UIPanel getValuePanel()
/*     */   {
/* 475 */     return this.valuePanel;
/*     */   }
/*     */ 
/*     */   public UIList getList_column()
/*     */   {
/* 483 */     if (this.list_column == null)
/*     */     {
/* 485 */       this.list_column = new DroppableList();
/* 486 */       this.list_column.setDragEnabled(true);
/* 487 */       this.list_column.addListSelectionListener(this.allEventHandler);
/*     */     }
/* 489 */     return this.list_column;
/*     */   }
/*     */ 
/*     */   public UIList getList_content()
/*     */   {
/* 497 */     if (this.list_content == null)
/*     */     {
/* 499 */       this.list_content = new DroppableList();
/* 500 */       this.list_content.setDragEnabled(true);
/* 501 */       this.list_content.addListSelectionListener(this.allEventHandler);
/*     */     }
/* 503 */     return this.list_content;
/*     */   }
/*     */ 
/*     */   public UIList getList_row()
/*     */   {
/* 511 */     if (this.list_row == null)
/*     */     {
/* 513 */       this.list_row = new DroppableList();
/* 514 */       this.list_row.setDragEnabled(true);
/* 515 */       this.list_row.addListSelectionListener(this.allEventHandler);
/*     */     }
/* 517 */     return this.list_row;
/*     */   }
/*     */ 
/*     */   public UIList getSource_list()
/*     */   {
/* 525 */     if (this.source_list == null)
/*     */     {
/* 527 */       this.source_list = new DroppableList();
/* 528 */       this.source_list.setDragEnabled(true);
/* 529 */       this.source_list.addListSelectionListener(this.allEventHandler);
/*     */     }
/* 531 */     return this.source_list;
/*     */   }
/*     */ 
/*     */   public UIButton getExchangeBt()
/*     */   {
/* 539 */     if (this.exchangeBt == null)
/*     */     {
/* 541 */       this.exchangeBt = new UIButton();
/*     */ 
/* 543 */       this.exchangeBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000081"));
/*     */     }
/* 545 */     return this.exchangeBt;
/*     */   }
/*     */ 
/*     */   public UICheckBox getFuheBox()
/*     */   {
/* 553 */     if (this.fuheBox == null)
/*     */     {
/* 555 */       this.fuheBox = new UICheckBox();
/* 556 */       this.fuheBox.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000082"));
/* 557 */       this.fuheBox.setEnabled(false);
/*     */     }
/* 559 */     return this.fuheBox;
/*     */   }
/*     */ 
/*     */   private void fuHeSelected()
/*     */   {
/* 564 */     DefaultListModel model = (DefaultListModel)this.curList.getModel();
/* 565 */     Object[] items = this.curList.getSelectedValues();
/* 566 */     ListItemWrapperObject tmpItem = new ListItemWrapperObject();
/* 567 */     String trueName = "";
/* 568 */     String showName = "";
/* 569 */     for (int i = 0; i < items.length; i++)
/*     */     {
/* 571 */       trueName = trueName + ((ListItemWrapperObject)items[i]).getTrueName();
/* 572 */       showName = showName + ((ListItemWrapperObject)items[i]).getShowName();
/* 573 */       if (i != items.length - 1)
/*     */       {
/* 575 */         trueName = trueName + " ";
/* 576 */         showName = showName + " ";
/*     */       }
/* 578 */       model.removeElement(items[i]);
/*     */     }
/* 580 */     tmpItem.setShowName(showName);
/* 581 */     tmpItem.setTrueName(trueName);
/* 582 */     tmpItem.setFuHe(true);
/* 583 */     model.add(0, tmpItem);
/*     */   }
/*     */ 
/*     */   private void fuHeDeselected()
/*     */   {
/* 589 */     DefaultListModel model = (DefaultListModel)this.curList.getModel();
/* 590 */     ListItemWrapperObject item = (ListItemWrapperObject)this.curList.getSelectedValue();
/*     */ 
/* 593 */     if (item.isFuHe())
/*     */     {
/* 595 */       StringTokenizer trueNames = new StringTokenizer(item.getTrueName());
/* 596 */       StringTokenizer showNames = new StringTokenizer(item.getShowName());
/* 597 */       while ((trueNames.hasMoreElements()) && (showNames.hasMoreElements()))
/*     */       {
/* 599 */         ListItemWrapperObject tmpItem = new ListItemWrapperObject();
/* 600 */         tmpItem.setFuHe(false);
/* 601 */         tmpItem.setShowName(showNames.nextToken());
/* 602 */         tmpItem.setTrueName(trueNames.nextToken());
/* 603 */         model.addElement(tmpItem);
/*     */       }
/* 605 */       model.removeElement(item);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void complete() throws Exception {
/* 610 */     setCrossInfoResult();
/*     */   }
/*     */ 
/*     */   protected String verify() {
/* 614 */     StringBuffer errorMsg = new StringBuffer();
/* 615 */     if (this.list_column.getModel().getSize() == 0) {
/* 616 */       errorMsg.append(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000083")).append(System.getProperty("line.separator"));
/*     */     }
/* 618 */     if (this.list_row.getModel().getSize() == 0) {
/* 619 */       errorMsg.append(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000084")).append(System.getProperty("line.separator"));
/*     */     }
/* 621 */     if (this.list_content.getModel().getSize() == 0) {
/* 622 */       errorMsg.append(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000085")).append(System.getProperty("line.separator"));
/*     */     }
/* 624 */     return errorMsg.toString();
/*     */   }
/*     */ 
/*     */   public void dragEnter(DropTargetDragEvent dtde) {
/*     */   }
/*     */ 
/*     */   public void dragExit(DropTargetEvent dte) {
/*     */   }
/*     */ 
/*     */   public void dragOver(DropTargetDragEvent dtde) {
/*     */   }
/*     */ 
/*     */   public void drop(DropTargetDropEvent dtde) {
/*     */     try {
/* 638 */       this.onDrag = false;
/* 639 */       Object obj = dtde.getTransferable().getTransferData(new DataFlavor(ListItemWrapperObject.class, null));
/* 640 */       if (((ListItemWrapperObject)obj).getTrueName().equals("&type"))
/* 641 */         return;
/* 642 */       ((DefaultListModel)this.currentDragList.getModel()).removeElement(obj);
/* 643 */       Object target = dtde.getDropTargetContext().getComponent();
/* 644 */       int index = 0;
/* 645 */       if (((UIList)target).getModel().getSize() != 0)
/* 646 */         index = ((UIList)target).locationToIndex(dtde.getLocation()) + 1;
/* 647 */       ((DefaultListModel)((UIList)target).getModel()).insertElementAt(obj, index);
/*     */     } catch (Exception e) {
/* 649 */       Logger.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dropActionChanged(DropTargetDragEvent dtde) {
/*     */   }
/*     */ 
/* 656 */   public void mouseDragged(MouseEvent e) { if (!this.onDrag)
/* 657 */       this.currentDragList = ((UIList)e.getSource());
/* 658 */     this.onDrag = true;
/*     */   }
/*     */ 
/*     */   public void mouseMoved(MouseEvent e)
/*     */   {
/*     */   }
/*     */ 
/*     */   class DialogEventHandler
/*     */     implements ItemListener, ActionListener, ListSelectionListener
/*     */   {
/*     */     DialogEventHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 172 */       if (e.getSource() == CrossDLG.this.exchangeBt)
/*     */       {
/* 174 */         CrossDLG.this.doExchange();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void valueChanged(ListSelectionEvent e)
/*     */     {
/* 186 */       CrossDLG.this.curList = ((UIList)e.getSource());
/* 187 */       CrossDLG.this.checkCanFuhe();
/*     */     }
/*     */ 
/*     */     public void itemStateChanged(ItemEvent e)
/*     */     {
/* 197 */       if ((e.getSource() == CrossDLG.this.fuheBox) && (CrossDLG.this.fuheBox.isEnabled()))
/*     */       {
/* 199 */         if (e.getStateChange() == 1)
/*     */         {
/* 201 */           CrossDLG.this.fuHeSelected();
/*     */         }
/*     */         else
/*     */         {
/* 205 */           CrossDLG.this.fuHeDeselected();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }