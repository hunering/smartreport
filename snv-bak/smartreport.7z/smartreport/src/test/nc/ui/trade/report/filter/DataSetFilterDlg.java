/*      */ package nc.ui.trade.report.filter;
/*      */ 
/*      */ import com.borland.jbcl.layout.VerticalFlowLayout;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.CardLayout;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Set;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.Box;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.ComboBoxModel;
/*      */ import javax.swing.DefaultListModel;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.ListModel;
/*      */ import javax.swing.SpringLayout;
/*      */ import javax.swing.border.EtchedBorder;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.tree.DefaultMutableTreeNode;
/*      */ import javax.swing.tree.DefaultTreeModel;
/*      */ import javax.swing.tree.DefaultTreeSelectionModel;
/*      */ import javax.swing.tree.TreeNode;
/*      */ import javax.swing.tree.TreePath;
/*      */ import nc.ui.ml.NCLangRes;
/*      */ import nc.ui.pub.beans.UIButton;
/*      */ import nc.ui.pub.beans.UIComboBox;
/*      */ import nc.ui.pub.beans.UIDialog;
/*      */ import nc.ui.pub.beans.UILabel;
/*      */ import nc.ui.pub.beans.UIList;
/*      */ import nc.ui.pub.beans.UIPanel;
/*      */ import nc.ui.pub.beans.UIRadioButton;
/*      */ import nc.ui.pub.beans.UIScrollPane;
/*      */ import nc.ui.pub.beans.UITextArea;
/*      */ import nc.ui.pub.beans.UITree;
/*      */ import nc.ui.pub.beans.layout.SpringUtilities;
/*      */ import nc.ui.trade.report.cross.ListItemWrapperObject;
/*      */ import nc.vo.pub.CircularlyAccessibleValueObject;
/*      */ import nc.vo.trade.report.TableField;
/*      */ 
/*      */ public class DataSetFilterDlg extends UIDialog
/*      */ {
/*      */   private UITextArea resultTextArea;
/*      */   private UIList resultList;
/*      */   private UIComboBox comboBoxValue;
/*      */   private UIComboBox comboBoxCondition;
/*      */   private UIComboBox comboBoxFilter;
/*   71 */   private TableField[] modelVOs = null;
/*      */ 
/*   73 */   private CircularlyAccessibleValueObject[] bodyDataVOs = null;
/*      */   private DataSetFilterDlgEventHandler allEventHandler;
/*      */   private UIButton moveBt;
/*      */   private UIButton okBt;
/*      */   private UIButton cancelBt;
/*      */   private UIButton delBt;
/*      */   private UIRadioButton andBt;
/*      */   private UIRadioButton orBt;
/*      */   private UIPanel panelOkCancel;
/*      */   private String fomula;
/*      */   private UIPanel panelTop;
/*      */   private UIPanel panelCombobox;
/*      */   private UIPanel panelButton;
/*      */   private UIPanel panelList;
/*      */   private UIPanel panelResult;
/*      */   private UIPanel panelButtonBottom;
/*      */   private UIPanel panelJoin;
/*      */   private UIPanel panelLevelOne;
/*      */   private UIPanel panelLevelTwo;
/*      */   private UIButton buttonNormal;
/*      */   private UIButton buttonAdvanced;
/*      */   private UIPanel panelList_2;
/*      */   private UIList listFilterItem;
/*      */   private UITree treeFunction;
/*      */   private UIList listCondition;
/*      */   private UITextArea resultTextArea_2;
/*      */   private UIPanel panelButtonBottom_2;
/*      */   private UIPanel panelOkCancel_2;
/*      */   private UIButton okBt_2;
/*      */   private UIButton cancelBt_2;
/*  147 */   private boolean isNormalState = true;
/*      */ 
/*      */   public DataSetFilterDlg(Container panret, TableField[] modelVOs, CircularlyAccessibleValueObject[] bodyDataVOs)
/*      */   {
/*  152 */     super(panret);
/*  153 */     setTitle(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000088"));
/*  154 */     this.modelVOs = modelVOs;
/*  155 */     this.bodyDataVOs = bodyDataVOs;
/*  156 */     this.allEventHandler = new DataSetFilterDlgEventHandler();
/*  157 */     setSize(480, 330);
/*  158 */     initLayout();
/*      */ 
/*  160 */     initData();
/*      */   }
/*      */ 
/*      */   private void initData()
/*      */   {
/*  170 */     if ((this.modelVOs == null) || (this.modelVOs.length == 0))
/*      */     {
/*  172 */       return;
/*      */     }
/*  174 */     initComboBoxFilter();
/*  175 */     initListFilter();
/*  176 */     initComboBoxCondition();
/*      */   }
/*      */ 
/*      */   private void initListFilter()
/*      */   {
/*  185 */     this.listFilterItem.setModel(new DefaultListModel());
/*  186 */     for (int i = 0; i < this.modelVOs.length; i++)
/*      */     {
/*  188 */       ListItemWrapperObject value = new ListItemWrapperObject();
/*  189 */       value.setShowName(this.modelVOs[i].getFieldShowName());
/*  190 */       value.setTrueName(convertVOFieldNameToReportModelFieldName(this.modelVOs[i].getFieldName()));
/*  191 */       ((DefaultListModel)this.listFilterItem.getModel()).addElement(value);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initComboBoxCondition()
/*      */   {
/*  201 */     String[] str = { "=", ">", "<", "<>", ">=", "<=" };
/*  202 */     for (int i = 0; i < str.length; i++)
/*      */     {
/*  204 */       this.comboBoxCondition.addItem(str[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initComboBoxFilter()
/*      */   {
/*  213 */     for (int i = 0; i < this.modelVOs.length; i++)
/*      */     {
/*  215 */       ListItemWrapperObject value = new ListItemWrapperObject();
/*  216 */       value.setShowName(this.modelVOs[i].getFieldShowName());
/*  217 */       value.setTrueName(convertVOFieldNameToReportModelFieldName(this.modelVOs[i].getFieldName()));
/*  218 */       this.comboBoxFilter.addItem(value);
/*      */     }
/*  220 */     if (this.comboBoxFilter.getModel().getSize() > 0)
/*      */     {
/*  222 */       this.comboBoxFilter.setSelectedIndex(0);
/*  223 */       fillComboBoxValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initLayout()
/*      */   {
/*  234 */     getContentPane().setLayout(new CardLayout());
/*  235 */     getContentPane().add("one", getPanelLevelOne());
/*  236 */     getContentPane().add("two", getPanelLevelTwo());
/*  237 */     ((CardLayout)getContentPane().getLayout()).show(getContentPane(), "one");
/*      */   }
/*      */ 
/*      */   private String convertVOFieldNameToReportModelFieldName(String voFieldName)
/*      */   {
/*  250 */     if (voFieldName.indexOf('.') == -1) {
/*  251 */       return voFieldName;
/*      */     }
/*  253 */     return voFieldName.substring(0, voFieldName.indexOf('.')) + "_" + voFieldName.substring(voFieldName.indexOf('.') + 1, voFieldName.length());
/*      */   }
/*      */ 
/*      */   private UIPanel getPanelLevelOne()
/*      */   {
/*  260 */     if (this.panelLevelOne == null)
/*      */     {
/*  262 */       this.panelLevelOne = new UIPanel();
/*      */ 
/*  265 */       this.panelLevelOne.add(getPanelTop());
/*      */ 
/*  267 */       this.panelLevelOne.add(getPanelResult());
/*  268 */       this.panelLevelOne.add(getPanelButtonBottom());
/*      */     }
/*  270 */     return this.panelLevelOne;
/*      */   }
/*      */ 
/*      */   private UIPanel getPanelLevelTwo()
/*      */   {
/*  275 */     if (this.panelLevelTwo == null)
/*      */     {
/*  277 */       this.panelLevelTwo = new UIPanel();
/*  278 */       this.panelLevelTwo = new UIPanel();
/*      */ 
/*  282 */       this.panelLevelTwo.add(getPanelList_2());
/*  283 */       this.resultTextArea_2 = new UITextArea();
/*  284 */       this.resultTextArea_2.setPreferredSize(new Dimension(380, 93));
/*  285 */       this.resultTextArea_2.setBorder(new EtchedBorder(1));
/*  286 */       this.panelLevelTwo.add(this.resultTextArea_2);
/*  287 */       this.panelLevelTwo.add(getPanelButtonBottom_2());
/*      */     }
/*      */ 
/*  293 */     return this.panelLevelTwo;
/*      */   }
/*      */ 
/*      */   private UIPanel getPanelButtonBottom_2()
/*      */   {
/*  301 */     if (this.panelButtonBottom_2 == null)
/*      */     {
/*  303 */       this.panelButtonBottom_2 = new UIPanel();
/*  304 */       this.panelButtonBottom_2.add(getPanelOkCancel_2());
/*      */ 
/*  306 */       this.buttonNormal = new UIButton();
/*  307 */       this.buttonNormal.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000089"));
/*  308 */       this.panelButtonBottom_2.add(this.buttonNormal);
/*  309 */       this.buttonNormal.addActionListener(this.allEventHandler);
/*      */     }
/*  311 */     return this.panelButtonBottom_2;
/*      */   }
/*      */ 
/*      */   private UIPanel getPanelList_2()
/*      */   {
/*  316 */     if (this.panelList_2 == null)
/*      */     {
/*  318 */       this.panelList_2 = new UIPanel();
/*  319 */       this.listCondition = new UIList();
/*  320 */       this.listCondition.setSelectionMode(0);
/*  321 */       UIScrollPane pane1 = new UIScrollPane();
/*  322 */       pane1.setViewportView(this.listCondition);
/*  323 */       pane1.setPreferredSize(new Dimension(120, 150));
/*  324 */       this.listCondition.addMouseListener(this.allEventHandler);
/*      */ 
/*  326 */       DefaultTreeSelectionModel localSelectionModel = new DefaultTreeSelectionModel();
/*  327 */       localSelectionModel.setSelectionMode(1);
/*  328 */       this.treeFunction = new UITree();
/*  329 */       this.treeFunction.setSelectionModel(localSelectionModel);
/*  330 */       UIScrollPane pane2 = new UIScrollPane();
/*  331 */       pane2.setViewportView(this.treeFunction);
/*  332 */       pane2.setPreferredSize(new Dimension(120, 150));
/*  333 */       this.treeFunction.addMouseListener(this.allEventHandler);
/*      */ 
/*  335 */       this.listFilterItem = new UIList();
/*  336 */       this.listFilterItem.setSelectionMode(0);
/*      */ 
/*  338 */       UIScrollPane pane3 = new UIScrollPane();
/*  339 */       pane3.setViewportView(this.listFilterItem);
/*  340 */       pane3.setPreferredSize(new Dimension(120, 150));
/*  341 */       this.listFilterItem.addMouseListener(this.allEventHandler);
/*      */ 
/*  343 */       this.panelList_2.add(pane3);
/*  344 */       this.panelList_2.add(pane1);
/*  345 */       this.panelList_2.add(pane2);
/*  346 */       initListAndTree();
/*      */     }
/*  348 */     return this.panelList_2;
/*      */   }
/*      */ 
/*      */   private void initListAndTree()
/*      */   {
/*  356 */     DefaultMutableTreeNode root = new DefaultMutableTreeNode(NCLangRes.getInstance().getStrByID("10241201", "UPP10241201-000283"));
/*      */ 
/*  362 */     DefaultMutableTreeNode parent = new DefaultMutableTreeNode(NCLangRes.getInstance().getStrByID("10241201", "UPP10241201-000284"));
/*      */ 
/*  364 */     DefaultMutableTreeNode child = new DefaultMutableTreeNode("abs()");
/*  365 */     parent.add(child);
/*  366 */     child = new DefaultMutableTreeNode("sgn()");
/*  367 */     parent.add(child);
/*      */ 
/*  376 */     child = new DefaultMutableTreeNode("sqrt()");
/*  377 */     parent.add(child);
/*  378 */     child = new DefaultMutableTreeNode("exp()");
/*  379 */     parent.add(child);
/*  380 */     child = new DefaultMutableTreeNode("log()");
/*  381 */     parent.add(child);
/*  382 */     child = new DefaultMutableTreeNode("sin()");
/*  383 */     parent.add(child);
/*  384 */     child = new DefaultMutableTreeNode("cos()");
/*  385 */     parent.add(child);
/*  386 */     child = new DefaultMutableTreeNode("tg()");
/*  387 */     parent.add(child);
/*      */ 
/*  390 */     child = new DefaultMutableTreeNode("zeroifnull()");
/*  391 */     parent.add(child);
/*      */ 
/*  393 */     root.add(parent);
/*      */ 
/*  395 */     parent = new DefaultMutableTreeNode(NCLangRes.getInstance().getStrByID("10241201", "UPP10241201-000285"));
/*      */ 
/*  397 */     child = new DefaultMutableTreeNode("length()");
/*  398 */     parent.add(child);
/*  399 */     child = new DefaultMutableTreeNode("toLowerCase()");
/*  400 */     parent.add(child);
/*  401 */     child = new DefaultMutableTreeNode("toUpperCase()");
/*  402 */     parent.add(child);
/*  403 */     child = new DefaultMutableTreeNode("toNumber()");
/*  404 */     parent.add(child);
/*  405 */     child = new DefaultMutableTreeNode("toString()");
/*  406 */     parent.add(child);
/*      */ 
/*  411 */     root.add(parent);
/*      */ 
/*  413 */     this.treeFunction.setModel(new DefaultTreeModel(root));
/*      */ 
/*  416 */     DefaultListModel lm = new DefaultListModel();
/*      */ 
/*  418 */     lm.addElement("()");
/*  419 */     lm.addElement("+");
/*  420 */     lm.addElement("-");
/*  421 */     lm.addElement("*");
/*  422 */     lm.addElement("/");
/*      */ 
/*  424 */     lm.addElement("=");
/*  425 */     lm.addElement(">");
/*  426 */     lm.addElement("<");
/*  427 */     lm.addElement("<=");
/*  428 */     lm.addElement(">=");
/*  429 */     lm.addElement("<>");
/*      */ 
/*  431 */     lm.addElement("!");
/*  432 */     lm.addElement("||");
/*  433 */     lm.addElement("&&");
/*  434 */     this.listCondition.setModel(lm);
/*      */   }
/*      */ 
/*      */   private void fillComboBoxValue()
/*      */   {
/*  617 */     if (this.comboBoxFilter.getSelectedItem() != null)
/*      */     {
/*  619 */       Set ls = getValueByFilterItem(this.comboBoxFilter.getSelectedItem());
/*  620 */       this.comboBoxValue.removeAllItems();
/*  621 */       if (ls != null)
/*      */       {
/*  623 */         Iterator it = ls.iterator();
/*  624 */         while (it.hasNext())
/*      */         {
/*  626 */           this.comboBoxValue.addItem(it.next());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private Set getValueByFilterItem(Object selectedItem)
/*      */   {
/*  641 */     ListItemWrapperObject item = (ListItemWrapperObject)selectedItem;
/*      */ 
/*  644 */     if ((this.bodyDataVOs == null) || (this.bodyDataVOs.length == 0))
/*  645 */       return null;
/*  646 */     Set al = new HashSet();
/*  647 */     for (int i = 0; i < this.bodyDataVOs.length; i++)
/*      */     {
/*  649 */       al.add(this.bodyDataVOs[i].getAttributeValue(item.getTrueName()));
/*      */     }
/*  651 */     return al;
/*      */   }
/*      */ 
/*      */   private void addToResultListAndArea(MiddleResult result)
/*      */   {
/*  656 */     if (result == null)
/*      */     {
/*  658 */       return;
/*      */     }
/*  660 */     if (isListContainsResult(result))
/*      */     {
/*  662 */       return;
/*      */     }
/*  664 */     ((DefaultListModel)this.resultList.getModel()).addElement(result);
/*  665 */     refreshArea();
/*      */   }
/*      */ 
/*      */   private boolean isListContainsResult(MiddleResult result)
/*      */   {
/*  673 */     int size = this.resultList.getModel().getSize();
/*  674 */     for (int i = 0; i < size; i++)
/*      */     {
/*  676 */       if (this.resultList.getModel().getElementAt(i).equals(result))
/*  677 */         return true;
/*      */     }
/*  679 */     return false;
/*      */   }
/*      */ 
/*      */   private void refreshArea()
/*      */   {
/*      */     try
/*      */     {
/*  687 */       this.resultTextArea.getDocument().remove(0, this.resultTextArea.getDocument().getLength());
/*      */ 
/*  689 */       this.resultTextArea.getDocument().insertString(0, reCombineResult(), null);
/*      */     }
/*      */     catch (BadLocationException e)
/*      */     {
/*  694 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   private String reCombineResult()
/*      */   {
/*  703 */     StringBuffer tmpFomula = new StringBuffer();
/*  704 */     int size = this.resultList.getModel().getSize();
/*  705 */     for (int i = 0; i < size; i++)
/*      */     {
/*  707 */       MiddleResult r = (MiddleResult)this.resultList.getModel().getElementAt(i);
/*      */ 
/*  709 */       if (i != 0)
/*      */       {
/*  711 */         tmpFomula.append(" ");
/*  712 */         tmpFomula.append(r.getJoin());
/*  713 */         tmpFomula.append(" ");
/*      */       }
/*  715 */       tmpFomula.append(r.getName().getTrueName());
/*  716 */       tmpFomula.append(r.getCondition());
/*  717 */       if (!r.isNumber())
/*  718 */         tmpFomula.append("\"");
/*  719 */       tmpFomula.append(r.getValue());
/*  720 */       if (!r.isNumber()) {
/*  721 */         tmpFomula.append("\"");
/*      */       }
/*      */     }
/*  724 */     return tmpFomula.toString();
/*      */   }
/*      */ 
/*      */   private MiddleResult getMiddleResult()
/*      */   {
/*  732 */     Object filter = this.comboBoxFilter.getSelectedItem();
/*  733 */     Object condition = this.comboBoxCondition.getSelectedItem();
/*  734 */     Object value = this.comboBoxValue.getSelectedItem();
/*  735 */     String join = "&&";
/*  736 */     if (this.orBt.isSelected())
/*      */     {
/*  738 */       join = "||";
/*      */     }
/*  740 */     if ((filter != null) && (condition != null) && (value != null))
/*      */     {
/*  742 */       return new MiddleResult((ListItemWrapperObject)filter, condition.toString(), value.toString(), join, this.modelVOs[this.comboBoxFilter.getSelectedIndex()].isNumber());
/*      */     }
/*      */ 
/*  745 */     return null;
/*      */   }
/*      */ 
/*      */   public String getFomula()
/*      */   {
/*  812 */     return this.fomula;
/*      */   }
/*      */ 
/*      */   public void setFomula(String fomula)
/*      */   {
/*  821 */     this.fomula = fomula;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelButton()
/*      */   {
/*  829 */     if (this.panelButton == null)
/*      */     {
/*  831 */       this.panelButton = new UIPanel();
/*  832 */       VerticalFlowLayout vf = new VerticalFlowLayout();
/*  833 */       vf.setAlignment(1);
/*  834 */       vf.setVgap(15);
/*  835 */       this.panelButton.setLayout(vf);
/*  836 */       this.moveBt = new UIButton();
/*  837 */       this.moveBt.addActionListener(this.allEventHandler);
/*  838 */       this.moveBt.setText(">");
/*  839 */       this.moveBt.setMaximumSize(this.moveBt.getPreferredSize());
/*  840 */       this.panelButton.add(this.moveBt);
/*  841 */       this.delBt = new UIButton();
/*  842 */       this.delBt.setText("<");
/*  843 */       this.delBt.setMaximumSize(this.delBt.getPreferredSize());
/*  844 */       this.panelButton.add(this.delBt);
/*  845 */       this.delBt.addActionListener(this.allEventHandler);
/*      */     }
/*  847 */     return this.panelButton;
/*      */   }
/*      */ 
/*      */   private UIPanel getPanelOkCancel()
/*      */   {
/*  852 */     if (this.panelOkCancel == null)
/*      */     {
/*  854 */       this.panelOkCancel = new UIPanel();
/*  855 */       this.okBt = new UIButton();
/*      */ 
/*  857 */       this.okBt.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000044"));
/*  858 */       this.panelOkCancel.add(this.okBt);
/*  859 */       this.okBt.addActionListener(this.allEventHandler);
/*      */ 
/*  861 */       this.cancelBt = new UIButton();
/*  862 */       this.cancelBt.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000008"));
/*  863 */       this.panelOkCancel.add(this.cancelBt);
/*  864 */       this.cancelBt.addActionListener(this.allEventHandler);
/*      */     }
/*  866 */     return this.panelOkCancel;
/*      */   }
/*      */ 
/*      */   private UIPanel getPanelOkCancel_2()
/*      */   {
/*  871 */     if (this.panelOkCancel_2 == null)
/*      */     {
/*  873 */       this.panelOkCancel_2 = new UIPanel();
/*  874 */       this.okBt_2 = new UIButton();
/*      */ 
/*  876 */       this.okBt_2.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000044"));
/*  877 */       this.panelOkCancel_2.add(this.okBt_2);
/*  878 */       this.okBt_2.addActionListener(this.allEventHandler);
/*      */ 
/*  880 */       this.cancelBt_2 = new UIButton();
/*  881 */       this.cancelBt_2.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000008"));
/*  882 */       this.panelOkCancel_2.add(this.cancelBt_2);
/*  883 */       this.cancelBt_2.addActionListener(this.allEventHandler);
/*      */     }
/*  885 */     return this.panelOkCancel_2;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelButtonBottom()
/*      */   {
/*  893 */     if (this.panelButtonBottom == null)
/*      */     {
/*  895 */       this.panelButtonBottom = new UIPanel();
/*  896 */       this.panelButtonBottom.add(getPanelOkCancel());
/*      */ 
/*  898 */       this.buttonAdvanced = new UIButton();
/*  899 */       this.buttonAdvanced.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000090"));
/*  900 */       this.panelButtonBottom.add(this.buttonAdvanced);
/*  901 */       this.buttonAdvanced.addActionListener(this.allEventHandler);
/*      */     }
/*  903 */     return this.panelButtonBottom;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelCombobox()
/*      */   {
/*  911 */     if (this.panelCombobox == null)
/*      */     {
/*  913 */       this.panelCombobox = new UIPanel();
/*  914 */       this.panelCombobox.setLayout(new SpringLayout());
/*  915 */       UILabel labelFilter = new UILabel();
/*  916 */       labelFilter.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000091"));
/*  917 */       this.panelCombobox.add(labelFilter);
/*      */ 
/*  919 */       this.comboBoxFilter = new UIComboBox();
/*  920 */       this.panelCombobox.add(this.comboBoxFilter);
/*  921 */       this.comboBoxFilter.addItemListener(this.allEventHandler);
/*      */ 
/*  923 */       UILabel labelCond = new UILabel();
/*  924 */       labelCond.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000092"));
/*  925 */       this.panelCombobox.add(labelCond);
/*      */ 
/*  927 */       this.comboBoxCondition = new UIComboBox();
/*  928 */       this.panelCombobox.add(this.comboBoxCondition);
/*      */ 
/*  930 */       UILabel labelValue = new UILabel();
/*  931 */       labelValue.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000093"));
/*  932 */       this.panelCombobox.add(labelValue);
/*      */ 
/*  934 */       this.comboBoxValue = new UIComboBox();
/*  935 */       this.panelCombobox.add(this.comboBoxValue);
/*  936 */       this.comboBoxValue.setEditable(true);
/*  937 */       SpringUtilities.makeCompactGrid(this.panelCombobox, 3, 2, 6, 6, 6, 3);
/*      */     }
/*      */ 
/*  940 */     return this.panelCombobox;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelList()
/*      */   {
/*  948 */     if (this.panelList == null)
/*      */     {
/*  950 */       this.panelList = new UIPanel();
/*  951 */       UIScrollPane scrollPane = new UIScrollPane();
/*  952 */       scrollPane.setPreferredSize(new Dimension(110, 140));
/*  953 */       this.panelList.add(scrollPane);
/*      */ 
/*  955 */       this.resultList = new UIList();
/*  956 */       this.resultList.setModel(new DefaultListModel());
/*  957 */       scrollPane.setViewportView(this.resultList);
/*      */     }
/*  959 */     return this.panelList;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelResult()
/*      */   {
/*  967 */     if (this.panelResult == null)
/*      */     {
/*  969 */       this.panelResult = new UIPanel();
/*  970 */       this.panelResult.setLayout(new BorderLayout());
/*  971 */       Box box = Box.createVerticalBox();
/*  972 */       JLabel label = new UILabel();
/*  973 */       label.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000094"));
/*  974 */       box.add(label);
/*      */ 
/*  976 */       this.resultTextArea = new UITextArea();
/*  977 */       this.resultTextArea.setPreferredSize(new Dimension(380, 80));
/*  978 */       this.resultTextArea.setBackground(getBackground());
/*  979 */       this.resultTextArea.setBorder(new EtchedBorder(1));
/*  980 */       this.resultTextArea.setEditable(false);
/*  981 */       box.add(this.resultTextArea);
/*      */ 
/*  983 */       this.panelResult.add(box);
/*      */     }
/*      */ 
/*  987 */     return this.panelResult;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelTop()
/*      */   {
/*  995 */     if (this.panelTop == null)
/*      */     {
/*  997 */       this.panelTop = new UIPanel();
/*      */ 
/*  999 */       this.panelTop.setLayout(new SpringLayout());
/* 1000 */       Box box = Box.createVerticalBox();
/* 1001 */       box.add(getPanelCombobox());
/* 1002 */       box.add(getPanelJoin());
/* 1003 */       this.panelTop.add(box);
/* 1004 */       this.panelTop.add(getPanelButton());
/* 1005 */       this.panelTop.add(getPanelList());
/* 1006 */       SpringUtilities.makeCompactGrid(this.panelTop, 1, 3, 6, 6, 16, 0);
/*      */     }
/* 1008 */     return this.panelTop;
/*      */   }
/*      */ 
/*      */   public UIPanel getPanelJoin()
/*      */   {
/* 1013 */     if (this.panelJoin == null)
/*      */     {
/* 1015 */       this.panelJoin = new UIPanel();
/* 1016 */       this.panelJoin.setLayout(new BorderLayout());
/* 1017 */       Box box = Box.createVerticalBox();
/*      */ 
/* 1019 */       ButtonGroup group = new ButtonGroup();
/* 1020 */       this.andBt = new UIRadioButton();
/* 1021 */       this.andBt.setText("and");
/* 1022 */       this.andBt.setSelected(true);
/* 1023 */       this.orBt = new UIRadioButton();
/* 1024 */       this.orBt.setText("or");
/* 1025 */       group.add(this.andBt);
/* 1026 */       group.add(this.orBt);
/* 1027 */       box.add(this.andBt);
/* 1028 */       box.add(this.orBt);
/* 1029 */       this.panelJoin.add(box);
/* 1030 */       this.panelJoin.setBorder(BorderFactory.createTitledBorder(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000095")));
/*      */     }
/* 1032 */     return this.panelJoin;
/*      */   }
/*      */ 
/*      */   public void setBodyDataVOs(CircularlyAccessibleValueObject[] bodyDataVOs)
/*      */   {
/* 1040 */     this.bodyDataVOs = bodyDataVOs;
/*      */   }
/*      */ 
/*      */   class MiddleResult
/*      */   {
/*      */     private ListItemWrapperObject name;
/*      */     private String condition;
/*      */     private String value;
/*      */     private String join;
/*  759 */     private boolean isNumber = false;
/*      */ 
/*      */     public MiddleResult(ListItemWrapperObject o_name, String s_condition, String s_value, String s_join, boolean isNum)
/*      */     {
/*  764 */       this.name = o_name;
/*  765 */       this.condition = s_condition;
/*  766 */       this.value = s_value;
/*  767 */       this.join = s_join;
/*  768 */       this.isNumber = isNum;
/*      */     }
/*      */ 
/*      */     public ListItemWrapperObject getName()
/*      */     {
/*  773 */       return this.name;
/*      */     }
/*      */ 
/*      */     public String getValue()
/*      */     {
/*  778 */       return this.value;
/*      */     }
/*      */ 
/*      */     public String getCondition()
/*      */     {
/*  783 */       return this.condition;
/*      */     }
/*      */ 
/*      */     public String getJoin()
/*      */     {
/*  788 */       return this.join;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  793 */       return this.name + " " + this.condition + " " + this.value;
/*      */     }
/*      */ 
/*      */     public boolean equals(Object obj)
/*      */     {
/*  798 */       return obj.toString().equals(toString());
/*      */     }
/*      */ 
/*      */     public boolean isNumber() {
/*  802 */       return this.isNumber;
/*      */     }
/*      */   }
/*      */ 
/*      */   class DataSetFilterDlgEventHandler
/*      */     implements ActionListener, ItemListener, MouseListener
/*      */   {
/*      */     DataSetFilterDlgEventHandler()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void actionPerformed(ActionEvent e)
/*      */     {
/*  448 */       if (e.getSource() == DataSetFilterDlg.this.moveBt)
/*      */       {
/*  450 */         DataSetFilterDlg.MiddleResult tmp = DataSetFilterDlg.this.getMiddleResult();
/*  451 */         DataSetFilterDlg.this.addToResultListAndArea(tmp);
/*      */       }
/*  453 */       else if (e.getSource() == DataSetFilterDlg.this.delBt)
/*      */       {
/*  455 */         if (DataSetFilterDlg.this.resultList.getSelectedValue() != null)
/*      */         {
/*  457 */           Object[] selectObjects = DataSetFilterDlg.this.resultList.getSelectedValues();
/*  458 */           if (selectObjects != null) {
/*  459 */             for (int i = 0; i < selectObjects.length; i++) {
/*  460 */               ((DefaultListModel)DataSetFilterDlg.this.resultList.getModel()).removeElement(selectObjects[i]);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  465 */           DataSetFilterDlg.this.refreshArea();
/*      */         }
/*      */       }
/*  468 */       else if ((e.getSource() == DataSetFilterDlg.this.okBt) || (e.getSource() == DataSetFilterDlg.this.okBt_2))
/*      */       {
/*  470 */         if (DataSetFilterDlg.this.isNormalState)
/*  471 */           DataSetFilterDlg.this.setFomula(DataSetFilterDlg.this.reCombineResult());
/*      */         else
/*  473 */           DataSetFilterDlg.this.setFomula(DataSetFilterDlg.this.resultTextArea_2.getText());
/*  474 */         DataSetFilterDlg.this.closeOK();
/*      */       }
/*  476 */       else if ((e.getSource() == DataSetFilterDlg.this.cancelBt) || (e.getSource() == DataSetFilterDlg.this.cancelBt_2))
/*      */       {
/*  478 */         DataSetFilterDlg.this.closeCancel();
/*      */       }
/*  480 */       else if (e.getSource() == DataSetFilterDlg.this.buttonNormal)
/*      */       {
/*  482 */         DataSetFilterDlg.this.isNormalState = true;
/*  483 */         ((CardLayout)DataSetFilterDlg.this.getContentPane().getLayout()).show(DataSetFilterDlg.this.getContentPane(), "one");
/*      */       }
/*  487 */       else if (e.getSource() == DataSetFilterDlg.this.buttonAdvanced)
/*      */       {
/*  489 */         DataSetFilterDlg.this.isNormalState = false;
/*  490 */         ((CardLayout)DataSetFilterDlg.this.getContentPane().getLayout()).show(DataSetFilterDlg.this.getContentPane(), "two");
/*      */       }
/*      */     }
/*      */ 
/*      */     public void itemStateChanged(ItemEvent e)
/*      */     {
/*  503 */       if ((e.getSource() == DataSetFilterDlg.this.comboBoxFilter) && (e.getStateChange() == 1))
/*      */       {
/*  506 */         DataSetFilterDlg.this.fillComboBoxValue();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void mouseClicked(MouseEvent e)
/*      */     {
/*  518 */       if (e.getClickCount() == 2)
/*      */       {
/*  520 */         if (e.getSource() == DataSetFilterDlg.this.treeFunction)
/*      */         {
/*  522 */           TreePath selPath = DataSetFilterDlg.this.treeFunction.getSelectionPath();
/*  523 */           if (selPath != null)
/*      */           {
/*  525 */             TreeNode selNode = (TreeNode)selPath.getLastPathComponent();
/*      */ 
/*  527 */             if (selNode.isLeaf())
/*      */             {
/*  529 */               String fun = selNode.toString();
/*  530 */               int pos = DataSetFilterDlg.this.resultTextArea_2.getSelectionStart();
/*  531 */               DataSetFilterDlg.this.resultTextArea_2.insert(fun, pos);
/*  532 */               DataSetFilterDlg.this.resultTextArea_2.setSelectionStart(pos + fun.length() - 1);
/*      */ 
/*  534 */               DataSetFilterDlg.this.resultTextArea_2.setSelectionEnd(pos + fun.length() - 1);
/*      */ 
/*  536 */               DataSetFilterDlg.this.resultTextArea_2.requestFocus();
/*      */             }
/*      */           }
/*      */         }
/*  540 */         else if (e.getSource() == DataSetFilterDlg.this.listFilterItem)
/*      */         {
/*  542 */           if (DataSetFilterDlg.this.listFilterItem.getSelectedValue() != null)
/*      */           {
/*  544 */             String name = ((ListItemWrapperObject)DataSetFilterDlg.this.listFilterItem.getSelectedValue()).getTrueName();
/*      */ 
/*  546 */             int pos = DataSetFilterDlg.this.resultTextArea_2.getSelectionStart();
/*  547 */             DataSetFilterDlg.this.resultTextArea_2.insert(name, pos);
/*  548 */             DataSetFilterDlg.this.resultTextArea_2.requestFocus();
/*  549 */             DataSetFilterDlg.this.resultTextArea_2.setSelectionStart(pos + name.length());
/*  550 */             DataSetFilterDlg.this.resultTextArea_2.setSelectionEnd(pos + name.length());
/*      */           }
/*      */         }
/*  553 */         else if (e.getSource() == DataSetFilterDlg.this.listCondition)
/*      */         {
/*  555 */           if (DataSetFilterDlg.this.listFilterItem.getSelectedValue() != null)
/*      */           {
/*  557 */             String str = DataSetFilterDlg.this.listCondition.getSelectedValue().toString();
/*      */ 
/*  559 */             int pos = DataSetFilterDlg.this.resultTextArea_2.getSelectionStart();
/*  560 */             DataSetFilterDlg.this.resultTextArea_2.insert(str, pos);
/*  561 */             int posmove = str.length();
/*  562 */             if (str.equals("()"))
/*      */             {
/*  564 */               posmove--;
/*      */             }
/*  566 */             DataSetFilterDlg.this.resultTextArea_2.requestFocus();
/*  567 */             DataSetFilterDlg.this.resultTextArea_2.setSelectionStart(pos + posmove);
/*  568 */             DataSetFilterDlg.this.resultTextArea_2.setSelectionEnd(pos + posmove);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void mouseEntered(MouseEvent e)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void mouseExited(MouseEvent e)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void mousePressed(MouseEvent e)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void mouseReleased(MouseEvent e)
/*      */     {
/*      */     }
/*      */   }
/*      */ }