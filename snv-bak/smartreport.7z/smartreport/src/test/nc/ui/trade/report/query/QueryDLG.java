/*     */ package nc.ui.trade.report.query;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import nc.ui.pub.query.QueryConditionClient;
/*     */ import nc.vo.pub.query.ConditionVO;
/*     */ 
/*     */ public class QueryDLG extends QueryConditionClient
/*     */ {
/*     */   public QueryDLG()
/*     */   {
/*     */   }
/*     */ 
/*     */   public QueryDLG(Container parent)
/*     */   {
/*  27 */     super(parent);
/*     */   }
/*     */ 
/*     */   public QueryDLG(Container parent, String title)
/*     */   {
/*  40 */     super(parent, title);
/*     */   }
/*     */ 
/*     */   public QueryDLG(Frame parent)
/*     */   {
/*  51 */     super(parent);
/*     */   }
/*     */ 
/*     */   public QueryDLG(Frame parent, String title)
/*     */   {
/*  64 */     super(parent, title);
/*     */   }
/*     */ 
/*     */   public QueryDLG(boolean isFixedSet)
/*     */   {
/*  75 */     super(isFixedSet);
/*     */   }
/*     */ 
/*     */   public String checkCondition()
/*     */   {
/*  82 */     String strRet = null;
/*     */ 
/*  85 */     String sResult = super.checkCondition();
/*  86 */     if ((strRet == null) || (strRet.length() == 0)) {
/*  87 */       return sResult;
/*     */     }
/*  89 */     return strRet + (sResult == null ? "" : sResult);
/*     */   }
/*     */ 
/*     */   public static String createTaleJoinClause(String[] clauses)
/*     */   {
/* 101 */     ArrayList al = new ArrayList();
/* 102 */     for (int i = 0; i < clauses.length; i++)
/*     */     {
/* 104 */       al.add(splitString(clauses[i]));
/*     */     }
/* 106 */     StringBuffer buf = new StringBuffer();
/* 107 */     HashSet set = new HashSet();
/* 108 */     for (int i = 0; i < al.size(); i++)
/*     */     {
/* 110 */       String[] ss = (String[])al.get(i);
/* 111 */       for (int j = 0; j < ss.length; j++)
/*     */       {
/* 113 */         if (!set.contains(ss[j].trim()))
/*     */         {
/* 115 */           buf.append(ss[j]);
/* 116 */           buf.append(" ");
/* 117 */           set.add(ss[j].trim());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 122 */     return buf.toString().trim();
/*     */   }
/*     */ 
/*     */   public String getTableJoinClauseForQuery()
/*     */   {
/* 132 */     ConditionVO[] vos = getConditionVO();
/* 133 */     ArrayList al = new ArrayList();
/* 134 */     for (int i = 0; i < vos.length; i++)
/*     */     {
/* 136 */       if ((vos[i].getTableCodeForMultiTable() != null) && (vos[i].getTableCodeForMultiTable().trim().length() != 0))
/*     */       {
/* 139 */         al.add(vos[i].getTableCodeForMultiTable().trim());
/*     */       }
/*     */     }
/*     */ 
/* 143 */     String[] clauses = (String[])al.toArray(new String[0]);
/*     */ 
/* 145 */     return createTaleJoinClause(clauses);
/*     */   }
/*     */ 
/*     */   public String getWhereSQL()
/*     */   {
/* 157 */     String strWhere = null;
/*     */ 
/* 160 */     String strParentWhere = super.getWhereSQL();
/* 161 */     if ((strWhere == null) || (strWhere.length() == 0))
/* 162 */       return strParentWhere;
/* 163 */     if ((strParentWhere == null) || (strParentWhere.length() == 0)) {
/* 164 */       return "";
/*     */     }
/* 166 */     return strWhere + " and " + strParentWhere;
/*     */   }
/*     */ 
/*     */   public static String[] splitString(String s)
/*     */   {
/* 178 */     if (s.charAt(s.length() - 1) != ';')
/* 179 */       s = s + ";";
/* 180 */     ArrayList al = new ArrayList();
/* 181 */     int index = 0;
/* 182 */     int start = 0;
/* 183 */     while ((index = s.indexOf(';', index)) != -1)
/*     */     {
/* 185 */       al.add(s.substring(start, index++).trim());
/* 186 */       start = index++;
/*     */     }
/*     */ 
/* 189 */     return (String[])al.toArray(new String[0]);
/*     */   }
/*     */ }