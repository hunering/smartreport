package nc.ui.trade.report.total;

import nc.vo.trade.report.TableField;
import nc.vo.trade.report.TotalField;

public abstract interface IReportQueryInfo
{
  public abstract TableField[] getGroupByFields();

  public abstract TotalField[] getTotalFields();
}