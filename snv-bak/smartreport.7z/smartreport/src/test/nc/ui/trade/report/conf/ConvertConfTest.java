/*    */ package nc.ui.trade.report.conf;
/*    */ 
/*    */ import junit.framework.TestCase;
/*    */ import junit.swingui.TestRunner;
/*    */ import nc.vo.trade.report.conf.PubRptconfVO;
/*    */ 
/*    */ public class ConvertConfTest extends TestCase
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 27 */     TestRunner.run(ConvertConfTest.class);
/*    */   }
/*    */ 
/*    */   public void testConvert()
/*    */     throws Exception
/*    */   {
/* 35 */     PubRptconfVO vo = new PubRptconfVO();
/* 36 */     vo.setVconfitems("nc.vo.teb.b00101022025.ApplyPlanMonthRepVO");
/*    */ 
/* 39 */     vo = ConvertConf.convert(vo);
/* 40 */     assertEquals("all table alias", vo.getVdef4(), "h,b");
/* 41 */     assertEquals("table jion clause", vo.getVdef5(), "ec_tbtdapply h left outer join ec_tbtdapply_b b  on h.pk_tbtdapply=b.pk_tbtdapply");
/*    */   }
/*    */ }