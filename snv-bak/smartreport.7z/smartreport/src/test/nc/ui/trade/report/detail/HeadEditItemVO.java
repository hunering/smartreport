/*    */ package nc.ui.trade.report.detail;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class HeadEditItemVO
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 153663826514475999L;
/* 14 */   private String itemKey = null;
/* 15 */   private String showName = null;
/* 16 */   private String refNodeName = null;
/*    */ 
/*    */   public String getItemKey() {
/* 19 */     return this.itemKey;
/*    */   }
/*    */   public void setItemKey(String itemKey) {
/* 22 */     this.itemKey = itemKey;
/*    */   }
/*    */   public String getRefNodeName() {
/* 25 */     return this.refNodeName;
/*    */   }
/*    */   public void setRefNodeName(String refNodeName) {
/* 28 */     this.refNodeName = refNodeName;
/*    */   }
/*    */   public String getShowName() {
/* 31 */     return this.showName;
/*    */   }
/*    */   public void setShowName(String showName) {
/* 34 */     this.showName = showName;
/*    */   }
/*    */ }