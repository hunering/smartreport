/*     */ package nc.ui.trade.report.columnfilter;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import nc.bs.logging.Logger;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UICheckBox;
/*     */ import nc.ui.pub.beans.UILabel;
/*     */ import nc.ui.pub.beans.UIList;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.dialog.DialogThemePanel;
/*     */ import nc.ui.pub.beans.dialog.StandardUIDialog;
/*     */ import nc.ui.trade.component.ListToListPanel;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class ColumnFilterDLG extends StandardUIDialog
/*     */ {
/*  31 */   private UIPanel ivjUIDialogContentPane = null;
/*     */ 
/*  33 */   private JPanel ivjTitlePane = null;
/*     */ 
/*  35 */   private JTextField ivjTitleField = null;
/*     */ 
/*  37 */   private ListToListPanel chooser = null;
/*     */ 
/*  39 */   private UICheckBox m_isAdjustColumnOrder = null;
/*     */ 
/*  41 */   private UIButton renameBt = null;
/*     */ 
/*  43 */   ItemChooserModelForModify model = null;
/*     */ 
/*  73 */   IvjEventHandler ivjEventHandler = new IvjEventHandler();
/*     */ 
/*     */   public ColumnFilterDLG(Container parent, TableField[] invisibleFields, TableField[] visibleFields, String title)
/*     */   {
/*  93 */     super(parent);
/*  94 */     this.model = new ItemChooserModelForModify(invisibleFields, visibleFields);
/*  95 */     this.chooser = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000050"), invisibleFields, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000051"), visibleFields, this.model, false);
/*     */ 
/*  97 */     UIPanel panel = new UIPanel();
/*  98 */     panel.setPreferredSize(new Dimension(55, 30));
/*  99 */     panel.add(getRenameBt());
/* 100 */     this.chooser.setExtensionPanel(panel);
/* 101 */     initialize();
/* 102 */     getTitleField().setText(title);
/*     */   }
/*     */ 
/*     */   private ListToListPanel getChooser()
/*     */   {
/* 113 */     return this.chooser;
/*     */   }
/*     */ 
/*     */   private UIPanel getUIDialogContentPane()
/*     */   {
/* 124 */     if (this.ivjUIDialogContentPane == null)
/*     */     {
/*     */       try
/*     */       {
/* 128 */         this.ivjUIDialogContentPane = this.editorPanel;
/* 129 */         this.ivjUIDialogContentPane.setName("UIDialogContentPane");
/* 130 */         this.ivjUIDialogContentPane.setLayout(new BorderLayout());
/* 131 */         this.ivjUIDialogContentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 5));
/*     */       }
/*     */       catch (Throwable ivjExc)
/*     */       {
/* 139 */         handleException(ivjExc);
/*     */       }
/*     */     }
/* 142 */     return this.ivjUIDialogContentPane;
/*     */   }
/*     */ 
/*     */   public TableField[] getVisibleField()
/*     */   {
/* 154 */     Object[] os = getChooser().getRightData();
/* 155 */     TableField[] fs = new TableField[os.length];
/* 156 */     for (int i = 0; i < os.length; i++)
/*     */     {
/* 158 */       fs[i] = ((TableField)os[i]);
/*     */     }
/* 160 */     return fs;
/*     */   }
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 165 */     return getTitleField().getText();
/*     */   }
/*     */ 
/*     */   public boolean isAdjustOrder() {
/* 169 */     return this.m_isAdjustColumnOrder.isSelected();
/*     */   }
/*     */ 
/*     */   private void handleException(Throwable exception)
/*     */   {
/* 180 */     Logger.error(exception.getMessage(), exception);
/*     */   }
/*     */ 
/*     */   private void initConnections()
/*     */     throws Exception
/*     */   {
/* 192 */     getRenameBt().addActionListener(this.ivjEventHandler);
/*     */   }
/*     */ 
/*     */   private void initialize()
/*     */   {
/*     */     try
/*     */     {
/* 203 */       setName("ColumnFilterDLG");
/* 204 */       setDefaultCloseOperation(2);
/*     */ 
/* 206 */       setSize(650, 520);
/* 207 */       setResizable(true);
/* 208 */       setErrorMsgSize(new Dimension(550, 320));
/*     */ 
/* 210 */       this.themePanel.setTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000052"));
/* 211 */       this.themePanel.setDetailTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000053"));
/*     */ 
/* 213 */       this.ivjUIDialogContentPane = this.editorPanel;
/* 214 */       this.ivjUIDialogContentPane.setLayout(new BorderLayout());
/* 215 */       this.ivjUIDialogContentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 5));
/* 216 */       initConnections();
/*     */     }
/*     */     catch (Throwable ivjExc)
/*     */     {
/* 220 */       handleException(ivjExc);
/*     */     }
/* 222 */     this.ivjUIDialogContentPane.add(getTitlePanel(), "North");
/* 223 */     this.ivjUIDialogContentPane.add(getChooser(), "Center");
/*     */   }
/*     */ 
/*     */   private JPanel getTitlePanel()
/*     */   {
/* 231 */     if (this.ivjTitlePane == null)
/*     */     {
/* 233 */       this.ivjTitlePane = new JPanel();
/* 234 */       this.ivjTitlePane.setLayout(new GridLayout(2, 1));
/* 235 */       JPanel titlePane = new JPanel();
/* 236 */       titlePane.setLayout(new BoxLayout(titlePane, 0));
/* 237 */       titlePane.add(Box.createHorizontalStrut(5));
/* 238 */       titlePane.add(new UILabel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000054")));
/* 239 */       titlePane.add(Box.createHorizontalStrut(20));
/* 240 */       titlePane.add(getTitleField());
/* 241 */       titlePane.add(Box.createHorizontalStrut(50));
/* 242 */       titlePane.add(Box.createGlue());
/* 243 */       this.ivjTitlePane.add(titlePane);
/* 244 */       JPanel sortComboPane = new JPanel();
/* 245 */       sortComboPane.setLayout(new FlowLayout(0));
/* 246 */       this.m_isAdjustColumnOrder = new UICheckBox(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000055"));
/* 247 */       this.m_isAdjustColumnOrder.setPreferredSize(new Dimension(300, 20));
/* 248 */       sortComboPane.add(this.m_isAdjustColumnOrder);
/* 249 */       this.ivjTitlePane.add(sortComboPane);
/*     */     }
/* 251 */     return this.ivjTitlePane;
/*     */   }
/*     */ 
/*     */   private JTextField getTitleField()
/*     */   {
/* 259 */     if (this.ivjTitleField == null)
/*     */     {
/* 261 */       this.ivjTitleField = new JTextField();
/* 262 */       this.ivjTitleField.setPreferredSize(new Dimension(200, 20));
/*     */     }
/* 264 */     return this.ivjTitleField;
/*     */   }
/*     */ 
/*     */   protected UIButton getRenameBt()
/*     */   {
/* 271 */     if (this.renameBt == null)
/*     */     {
/* 273 */       this.renameBt = new UIButton();
/* 274 */       this.renameBt.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000045"));
/* 275 */       this.renameBt.setPreferredSize(new Dimension(45, 20));
/*     */     }
/* 277 */     return this.renameBt;
/*     */   }
/*     */ 
/*     */   protected void complete()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   class IvjEventHandler
/*     */     implements ActionListener
/*     */   {
/*     */     IvjEventHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  48 */       if (e.getSource() == ColumnFilterDLG.this.renameBt)
/*     */       {
/*  50 */         UIList list = (UIList)ColumnFilterDLG.this.getChooser().getRightList();
/*  51 */         if (list.getSelectedIndices() != null)
/*     */         {
/*  53 */           if (list.getSelectedIndices().length > 1)
/*     */           {
/*  55 */             list.setSelectedIndex(list.getSelectedIndices()[0]);
/*     */           }
/*  57 */           int index = list.getSelectedIndex();
/*  58 */           RenameDialog renameDlg = new RenameDialog(ColumnFilterDLG.this.getChooser(), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000038"));
/*  59 */           renameDlg.setOldName(list.getSelectedValue().toString());
/*  60 */           if (renameDlg.showModal() == 1)
/*     */           {
/*  62 */             String newName = renameDlg.getNewName();
/*  63 */             if ((newName != null) && (!newName.equals("")))
/*     */             {
/*  65 */               ColumnFilterDLG.this.model.modifyValue(index, newName);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }