package nc.ui.trade.report.controller;

public abstract interface IReportCtl
{
  public abstract String _getModuleCode();

  public abstract String _getOperator();

  public abstract String _getPk_corp();

  public abstract String[] getAllTableAlias();

  public abstract String getDefaultSqlWhere();

  public abstract String getDetailReportNode();

  public abstract String getTableJoinClause();

  public abstract boolean isShowCondition();

  public abstract String[] getGroupKeys();
}