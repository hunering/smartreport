/*    */ package nc.ui.trade.report.columnfilter;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import nc.ui.trade.component.DefaultItemChooserModel;
/*    */ import nc.vo.trade.report.TableField;
/*    */ 
/*    */ public class ItemChooserModelForModify extends DefaultItemChooserModel
/*    */ {
/*    */   public ItemChooserModelForModify(Object[] _left, Object[] _right)
/*    */   {
/* 24 */     super(_left, _right);
/*    */   }
/*    */ 
/*    */   public void modifyValue(int index, Object newValue)
/*    */   {
/* 29 */     TableField tf = (TableField)this.right.get(index);
/* 30 */     TableField newtf = new TableField(tf.getFieldName(), newValue.toString());
/*    */ 
/* 32 */     this.right.set(index, newtf);
/* 33 */     setChanged();
/* 34 */     notifyObservers();
/*    */   }
/*    */ }