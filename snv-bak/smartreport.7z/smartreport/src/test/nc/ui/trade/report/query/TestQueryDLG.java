/*    */ package nc.ui.trade.report.query;
/*    */ 
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ 
/*    */ public class TestQueryDLG extends TestCase
/*    */ {
/*    */   public TestQueryDLG()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TestQueryDLG(String name)
/*    */   {
/* 26 */     super(name);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 37 */     TestRunner.run(suite());
/*    */   }
/*    */ 
/*    */   public static TestSuite suite()
/*    */   {
/* 42 */     TestSuite suite = new TestSuite();
/*    */ 
/* 45 */     suite.addTest(new TestQueryDLG("testCreateClause"));
/* 46 */     return suite;
/*    */   }
/*    */ 
/*    */   public void testCreateClause()
/*    */   {
/* 55 */     String[] ss = { "c b d", "a b c;e f g", "a b c;k l m" };
/*    */ 
/* 58 */     String result = QueryDLG.createTaleJoinClause(ss);
/* 59 */     String expect = "c b d a b c e f g k l m";
/* 60 */     assertEquals(expect, result);
/*    */   }
/*    */ 
/*    */   public void testSplitString()
/*    */   {
/* 69 */     String s = "left outer join A a on A.f1 = b.f1 ;left outer join C c on C.f2 = a.f2";
/* 70 */     String[] ss = QueryDLG.splitString(s);
/* 71 */     assertNotNull(ss);
/* 72 */     assertEquals(2, ss.length);
/* 73 */     assertEquals("left outer join A a on A.f1 = b.f1", ss[0]);
/* 74 */     assertEquals("left outer join C c on C.f2 = a.f2", ss[1]);
/*    */   }
/*    */ }