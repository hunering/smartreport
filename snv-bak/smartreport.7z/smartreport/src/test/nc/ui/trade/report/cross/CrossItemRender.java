/*    */ package nc.ui.trade.report.cross;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.ListCellRenderer;
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.ui.pub.beans.UILabel;
/*    */ 
/*    */ public class CrossItemRender
/*    */   implements ListCellRenderer
/*    */ {
/*    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*    */   {
/* 18 */     UILabel label = new UILabel();
/* 19 */     label.setText(value.toString());
/* 20 */     label.setOpaque(true);
/* 21 */     label.setILabelType(0);
/*    */ 
/* 23 */     Color color = Color.black;
/* 24 */     if (((value instanceof ListItemWrapperObject)) && (((ListItemWrapperObject)value).getTrueName().equals("&type")))
/*    */     {
/* 26 */       color = Color.red;
/* 27 */       label.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000086"));
/*    */     }
/*    */ 
/* 30 */     label.setBackground(isSelected ? list.getSelectionBackground() : Color.white);
/* 31 */     label.setForeground(color);
/* 32 */     return label;
/*    */   }
/*    */ }