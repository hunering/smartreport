/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIComboBox;
/*     */ import nc.ui.pub.beans.UILabel;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.UIScrollPane;
/*     */ import nc.ui.pub.beans.UITable;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class SumTablePanel extends UIPanel
/*     */ {
/*  29 */   private UITable sumTable = null;
/*     */ 
/*  31 */   private UIScrollPane scrollPane = null;
/*     */ 
/*  35 */   private TableField[] dataCols = null;
/*     */ 
/*     */   public SumTablePanel(TableField[] dataCols, TableField[] sumCols)
/*     */   {
/*  45 */     this.dataCols = dataCols;
/*     */ 
/*  47 */     initLayout();
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/*  55 */     setLayout(new BorderLayout());
/*  56 */     add(getTitleLabel(), "North");
/*  57 */     add(getScrollPane());
/*     */   }
/*     */ 
/*     */   private UILabel getTitleLabel()
/*     */   {
/*  63 */     UILabel label = new UILabel();
/*  64 */     label.setHorizontalAlignment(0);
/*  65 */     label.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000147"));
/*  66 */     return label;
/*     */   }
/*     */ 
/*     */   private UITable getSumTable()
/*     */   {
/*  71 */     if (this.sumTable == null)
/*     */     {
/*  73 */       this.sumTable = new UITable();
/*  74 */       ArrayList list = new ArrayList();
/*  75 */       if (this.dataCols != null)
/*     */       {
/*  77 */         for (int i = 0; i < this.dataCols.length; i++)
/*     */         {
/*  79 */           SumTableRow row = new SumTableRow();
/*  80 */           row.setField(this.dataCols[i]);
/*  81 */           row.setSubTotal(new Boolean(false));
/*     */         }
/*     */       }
/*  84 */       SumTableModel model = new SumTableModel((SumTableRow[])list.toArray(new SumTableRow[0]));
/*     */ 
/*  86 */       this.sumTable.setModel(model);
/*  87 */       String[] str = { "d", "e", "f" };
/*  88 */       DefaultCellEditor ce1 = new DefaultCellEditor(new UIComboBox(str));
/*  89 */       this.sumTable.getColumnModel().getColumn(2).setCellEditor(ce1);
/*     */     }
/*     */ 
/*  94 */     return this.sumTable;
/*     */   }
/*     */ 
/*     */   protected UIScrollPane getScrollPane()
/*     */   {
/* 102 */     if (this.scrollPane == null)
/*     */     {
/* 104 */       this.scrollPane = new UIScrollPane();
/* 105 */       this.scrollPane.setViewportView(getSumTable());
/*     */     }
/* 107 */     return this.scrollPane;
/*     */   }
/*     */ }