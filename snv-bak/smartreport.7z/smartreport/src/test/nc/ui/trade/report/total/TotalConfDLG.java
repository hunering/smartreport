/*     */ package nc.ui.trade.report.total;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JPanel;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UIDialog;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.trade.component.ItemChooserPanel;
/*     */ import nc.vo.trade.report.TableField;
/*     */ import nc.vo.trade.report.TotalField;
/*     */ 
/*     */ public class TotalConfDLG extends UIDialog
/*     */   implements IReportQueryInfo
/*     */ {
/*  12 */   private UIButton ivjCancel = null;
/*     */ 
/*  14 */   private UIButton ivjOK = null;
/*     */ 
/*  16 */   private JPanel ivjUIDialogContentPane = null;
/*     */ 
/*  18 */   private ItemChooserPanel groupFieldChooser = null;
/*     */ 
/*  20 */   private ItemChooserPanel totalFieldChooser = null;
/*     */ 
/*  22 */   private UIPanel ivjUIPanel1 = null;
/*     */ 
/*  24 */   private UIPanel ivjUIPanel2 = null;
/*     */ 
/*  26 */   IvjEventHandler ivjEventHandler = new IvjEventHandler();
/*     */ 
/*     */   public TotalConfDLG()
/*     */   {
/*  47 */     initialize();
/*     */   }
/*     */ 
/*     */   public TotalConfDLG(Container parent)
/*     */   {
/*  58 */     super(parent);
/*     */   }
/*     */ 
/*     */   public TotalConfDLG(Container parent, String title)
/*     */   {
/*  71 */     super(parent, title);
/*     */   }
/*     */ 
/*     */   public TotalConfDLG(Container parent, IReportModelInfo irmi)
/*     */   {
/*  82 */     super(parent);
/*     */ 
/*  84 */     initGroupChooser(irmi);
/*  85 */     initTotalChooser(irmi);
/*  86 */     initialize();
/*     */   }
/*     */ 
/*     */   public TotalConfDLG(Frame owner)
/*     */   {
/*  97 */     super(owner);
/*     */   }
/*     */ 
/*     */   public TotalConfDLG(Frame owner, String title)
/*     */   {
/* 110 */     super(owner, title);
/*     */   }
/*     */ 
/*     */   public void cancel_ActionPerformed(ActionEvent actionEvent)
/*     */   {
/* 118 */     closeCancel();
/*     */   }
/*     */ 
/*     */   private void connEtoC1(ActionEvent arg1)
/*     */   {
/*     */     try
/*     */     {
/* 136 */       oK_ActionPerformed(arg1);
/*     */     }
/*     */     catch (Throwable ivjExc)
/*     */     {
/* 144 */       handleException(ivjExc);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void connEtoC2(ActionEvent arg1)
/*     */   {
/*     */     try
/*     */     {
/* 162 */       cancel_ActionPerformed(arg1);
/*     */     }
/*     */     catch (Throwable ivjExc)
/*     */     {
/* 170 */       handleException(ivjExc);
/*     */     }
/*     */   }
/*     */ 
/*     */   private UIButton getCancel()
/*     */   {
/* 182 */     if (this.ivjCancel == null)
/*     */     {
/*     */       try
/*     */       {
/* 186 */         this.ivjCancel = new UIButton();
/* 187 */         this.ivjCancel.setName("Cancel");
/* 188 */         this.ivjCancel.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000008"));
/*     */       }
/*     */       catch (Throwable ivjExc)
/*     */       {
/* 196 */         handleException(ivjExc);
/*     */       }
/*     */     }
/* 199 */     return this.ivjCancel;
/*     */   }
/*     */ 
/*     */   public TableField[] getGroupByFields()
/*     */   {
/* 207 */     TableField[] fs = new TableField[this.groupFieldChooser.getRightData().length];
/* 208 */     for (int i = 0; i < fs.length; i++)
/*     */     {
/* 210 */       fs[i] = ((TableField)this.groupFieldChooser.getRightData()[i]);
/*     */     }
/*     */ 
/* 213 */     return fs;
/*     */   }
/*     */ 
/*     */   private ItemChooserPanel getGroupFieldChooser()
/*     */   {
/* 223 */     if (this.groupFieldChooser == null)
/*     */     {
/* 225 */       this.groupFieldChooser = new ItemChooserPanel();
/*     */     }
/* 227 */     return this.groupFieldChooser;
/*     */   }
/*     */ 
/*     */   private UIButton getOK()
/*     */   {
/* 238 */     if (this.ivjOK == null)
/*     */     {
/*     */       try
/*     */       {
/* 242 */         this.ivjOK = new UIButton();
/* 243 */         this.ivjOK.setName("OK");
/* 244 */         this.ivjOK.setText(NCLangRes.getInstance().getStrByID("common", "UC001-0000044"));
/*     */       }
/*     */       catch (Throwable ivjExc)
/*     */       {
/* 252 */         handleException(ivjExc);
/*     */       }
/*     */     }
/* 255 */     return this.ivjOK;
/*     */   }
/*     */ 
/*     */   private ItemChooserPanel getTotalFieldChooser()
/*     */   {
/* 265 */     if (this.totalFieldChooser == null)
/*     */     {
/* 267 */       this.totalFieldChooser = new ItemChooserPanel();
/*     */     }
/* 269 */     return this.totalFieldChooser;
/*     */   }
/*     */ 
/*     */   public TotalField[] getTotalFields()
/*     */   {
/* 280 */     TotalField[] fs = new TotalField[this.totalFieldChooser.getRightData().length];
/* 281 */     for (int i = 0; i < fs.length; i++)
/*     */     {
/* 283 */       fs[i] = ((TotalField)this.totalFieldChooser.getRightData()[i]);
/*     */     }
/* 285 */     return fs;
/*     */   }
/*     */ 
/*     */   private JPanel getUIDialogContentPane()
/*     */   {
/* 296 */     if (this.ivjUIDialogContentPane == null)
/*     */     {
/*     */       try
/*     */       {
/* 300 */         this.ivjUIDialogContentPane = new JPanel();
/* 301 */         this.ivjUIDialogContentPane.setName("UIDialogContentPane");
/* 302 */         this.ivjUIDialogContentPane.setLayout(new BorderLayout());
/* 303 */         getUIDialogContentPane().add(getUIPanel1(), "South");
/* 304 */         getUIDialogContentPane().add(getUIPanel2(), "Center");
/*     */       }
/*     */       catch (Throwable ivjExc)
/*     */       {
/* 312 */         handleException(ivjExc);
/*     */       }
/*     */     }
/* 315 */     return this.ivjUIDialogContentPane;
/*     */   }
/*     */ 
/*     */   private UIPanel getUIPanel1()
/*     */   {
/* 326 */     if (this.ivjUIPanel1 == null)
/*     */     {
/*     */       try
/*     */       {
/* 330 */         this.ivjUIPanel1 = new UIPanel();
/* 331 */         this.ivjUIPanel1.setName("UIPanel1");
/* 332 */         getUIPanel1().add(getOK(), getOK().getName());
/* 333 */         getUIPanel1().add(getCancel(), getCancel().getName());
/*     */       }
/*     */       catch (Throwable ivjExc)
/*     */       {
/* 341 */         handleException(ivjExc);
/*     */       }
/*     */     }
/* 344 */     return this.ivjUIPanel1;
/*     */   }
/*     */ 
/*     */   private UIPanel getUIPanel2()
/*     */   {
/* 355 */     if (this.ivjUIPanel2 == null)
/*     */     {
/*     */       try
/*     */       {
/* 359 */         this.ivjUIPanel2 = new UIPanel();
/* 360 */         this.ivjUIPanel2.setName("UIPanel2");
/* 361 */         this.ivjUIPanel2.setLayout(getUIPanel2BoxLayout());
/*     */ 
/* 363 */         this.ivjUIPanel2.add(getGroupFieldChooser());
/* 364 */         this.ivjUIPanel2.add(getTotalFieldChooser());
/*     */       }
/*     */       catch (Throwable ivjExc)
/*     */       {
/* 371 */         handleException(ivjExc);
/*     */       }
/*     */     }
/* 374 */     return this.ivjUIPanel2;
/*     */   }
/*     */ 
/*     */   private BoxLayout getUIPanel2BoxLayout()
/*     */   {
/* 385 */     BoxLayout ivjUIPanel2BoxLayout = null;
/*     */     try
/*     */     {
/* 389 */       ivjUIPanel2BoxLayout = new BoxLayout(getUIPanel2(), 1);
/*     */     }
/*     */     catch (Throwable ivjExc)
/*     */     {
/* 394 */       handleException(ivjExc);
/*     */     }
/*     */ 
/* 397 */     return ivjUIPanel2BoxLayout;
/*     */   }
/*     */ 
/*     */   private void handleException(Throwable exception)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void initConnections()
/*     */     throws Exception
/*     */   {
/* 425 */     getOK().addActionListener(this.ivjEventHandler);
/* 426 */     getCancel().addActionListener(this.ivjEventHandler);
/*     */   }
/*     */ 
/*     */   protected void initGroupChooser(IReportModelInfo irmi)
/*     */   {
/* 438 */     TableField[] all = irmi.getCandidateGroupFields();
/* 439 */     TableField[] using = irmi.getCurrentUsingGroupFields();
/* 440 */     ArrayList al = new ArrayList();
/* 441 */     for (int i = 0; i < all.length; i++)
/*     */     {
/* 443 */       if (!Arrays.asList(using).contains(all[i]))
/* 444 */         al.add(all[i]);
/*     */     }
/* 446 */     TableField[] nousing = (TableField[])al.toArray(new TableField[0]);
/* 447 */     this.groupFieldChooser = new ItemChooserPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000158"), nousing, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000159"), using);
/*     */   }
/*     */ 
/*     */   private void initialize()
/*     */   {
/*     */     try
/*     */     {
/* 462 */       setName("TotalConfDLG");
/* 463 */       setDefaultCloseOperation(2);
/* 464 */       setSize(401, 421);
/* 465 */       setContentPane(getUIDialogContentPane());
/* 466 */       initConnections();
/*     */     }
/*     */     catch (Throwable ivjExc)
/*     */     {
/* 470 */       handleException(ivjExc);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initTotalChooser(IReportModelInfo irmi)
/*     */   {
/* 481 */     TotalField[] all = irmi.getCandidateTotalFields();
/* 482 */     TotalField[] using = irmi.getCurrentUsingTotalFields();
/* 483 */     ArrayList al = new ArrayList();
/* 484 */     for (int i = 0; i < all.length; i++)
/*     */     {
/* 486 */       if (!Arrays.asList(using).contains(all[i]))
/* 487 */         al.add(all[i]);
/*     */     }
/* 489 */     TotalField[] nousing = (TotalField[])al.toArray(new TotalField[0]);
/* 490 */     this.totalFieldChooser = new ItemChooserPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000160"), nousing, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000161"), using);
/*     */   }
/*     */ 
/*     */   public void oK_ActionPerformed(ActionEvent actionEvent)
/*     */   {
/* 500 */     closeOK();
/*     */   }
/*     */ 
/*     */   class IvjEventHandler
/*     */     implements ActionListener
/*     */   {
/*     */     IvjEventHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  32 */       if (e.getSource() == TotalConfDLG.this.getOK())
/*  33 */         TotalConfDLG.this.connEtoC1(e);
/*  34 */       if (e.getSource() == TotalConfDLG.this.getCancel())
/*  35 */         TotalConfDLG.this.connEtoC2(e);
/*     */     }
/*     */   }
/*     */ }