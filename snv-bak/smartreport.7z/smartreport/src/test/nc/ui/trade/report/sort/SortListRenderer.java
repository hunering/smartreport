/*    */ package nc.ui.trade.report.sort;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.ListCellRenderer;
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.vo.trade.report.TableField;
/*    */ 
/*    */ public class SortListRenderer extends JLabel
/*    */   implements ListCellRenderer
/*    */ {
/*    */   public SortListRenderer()
/*    */   {
/* 28 */     setOpaque(true);
/*    */   }
/*    */ 
/*    */   public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*    */   {
/* 40 */     SortListItem item = (SortListItem)value;
/* 41 */     if (isSelected)
/*    */     {
/* 43 */       setBackground(list.getSelectionBackground());
/* 44 */       setForeground(list.getSelectionForeground());
/*    */     }
/*    */     else
/*    */     {
/* 48 */       setBackground(list.getBackground());
/* 49 */       setForeground(list.getForeground());
/*    */     }
/* 51 */     String text = item.getTableField().getFieldShowName();
/* 52 */     if (item.isAsc())
/* 53 */       text = text + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000154");
/*    */     else
/* 55 */       text = text + NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000155");
/* 56 */     setText(text);
/* 57 */     return this;
/*    */   }
/*    */ }