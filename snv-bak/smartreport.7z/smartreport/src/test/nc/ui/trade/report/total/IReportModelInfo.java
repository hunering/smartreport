package nc.ui.trade.report.total;

import nc.vo.trade.report.TableField;
import nc.vo.trade.report.TotalField;

public abstract interface IReportModelInfo
{
  public abstract TableField[] getCandidateGroupFields();

  public abstract TotalField[] getCandidateTotalFields();

  public abstract TableField[] getCurrentUsingGroupFields();

  public abstract TotalField[] getCurrentUsingTotalFields();
}