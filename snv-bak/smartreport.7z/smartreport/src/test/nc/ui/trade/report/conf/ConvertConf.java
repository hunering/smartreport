/*    */ package nc.ui.trade.report.conf;
/*    */ 
/*    */ import nc.vo.trade.report.IReportVOInfo;
/*    */ import nc.vo.trade.report.conf.PubRptconfVO;
/*    */ 
/*    */ public class ConvertConf
/*    */ {
/*    */   public static PubRptconfVO convert(PubRptconfVO vo)
/*    */     throws Exception
/*    */   {
/* 31 */     String className = vo.getVconfitems();
/* 32 */     Class c = Class.forName(className);
/* 33 */     IReportVOInfo iri = (IReportVOInfo)c.newInstance();
/* 34 */     String[] ss = iri.getAllTableAlias();
/* 35 */     String s = "";
/* 36 */     for (int i = 0; i < ss.length; i++)
/*    */     {
/* 38 */       s = s + ss[i].trim();
/* 39 */       if (i != ss.length - 1)
/* 40 */         s = s + ",";
/*    */     }
/* 42 */     vo.setVdef4(s);
/* 43 */     vo.setVdef5(iri.getTableJoinClause());
/* 44 */     return vo;
/*    */   }
/*    */ 
/*    */   public static PubRptconfVO[] getAllConfVO()
/*    */     throws Exception
/*    */   {
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }