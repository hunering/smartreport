/*     */ package nc.ui.trade.report.cross;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class ListItemWrapperObject
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private String showName;
/*     */   private String trueName;
/*  20 */   private boolean fuHe = false;
/*     */ 
/*     */   public ListItemWrapperObject()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ListItemWrapperObject(String showName, String trueName)
/*     */   {
/*  31 */     setShowName(showName);
/*  32 */     setTrueName(trueName);
/*  33 */     setFuHe(false);
/*     */   }
/*     */ 
/*     */   public String getShowName()
/*     */   {
/*  41 */     return this.showName;
/*     */   }
/*     */ 
/*     */   public void setShowName(String showName)
/*     */   {
/*  50 */     this.showName = showName;
/*     */   }
/*     */ 
/*     */   public String getTrueName()
/*     */   {
/*  58 */     return this.trueName;
/*     */   }
/*     */ 
/*     */   public void setTrueName(String trueName)
/*     */   {
/*  67 */     this.trueName = trueName;
/*     */   }
/*     */ 
/*     */   public void setDataType(int dataType)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  85 */     return this.showName;
/*     */   }
/*     */ 
/*     */   public boolean isFuHe()
/*     */   {
/*  93 */     return this.fuHe;
/*     */   }
/*     */ 
/*     */   public void setFuHe(boolean fuHe)
/*     */   {
/* 102 */     this.fuHe = fuHe;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 107 */     if ((obj != null) && ((obj instanceof ListItemWrapperObject)) && 
/* 108 */       (((ListItemWrapperObject)obj).getShowName().equals(this.showName)) && (((ListItemWrapperObject)obj).getTrueName().equals(this.trueName)))
/*     */     {
/* 110 */       return true;
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */ }