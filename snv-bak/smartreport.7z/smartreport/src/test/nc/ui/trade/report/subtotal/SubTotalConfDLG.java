/*     */ package nc.ui.trade.report.subtotal;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UICheckBox;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.dialog.DialogThemePanel;
/*     */ import nc.ui.pub.beans.dialog.StandardUIDialog;
/*     */ import nc.ui.report.base.ISubTotalConf;
/*     */ import nc.ui.trade.component.ListToListPanel;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class SubTotalConfDLG extends StandardUIDialog
/*     */ {
/*  30 */   private ISubTotalConf istc = null;
/*  31 */   private ListToListPanel groupPanel = null;
/*  32 */   private ListToListPanel totalPanel = null;
/*  33 */   private UIPanel settingPane = null;
/*  34 */   private UICheckBox sumChooser = null;
/*  35 */   private UICheckBox subChooser = null;
/*  36 */   private UICheckBox levelChooser = null;
/*     */ 
/*     */   public SubTotalConfDLG(Container parent, ISubTotalConf istc)
/*     */   {
/*  41 */     super(parent);
/*  42 */     this.istc = istc;
/*  43 */     initLayout();
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/*  52 */     setSize(650, 650);
/*     */ 
/*  54 */     setErrorMsgSize(new Dimension(680, 500));
/*     */ 
/*  56 */     setResizable(true);
/*     */ 
/*  58 */     this.themePanel.setTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000156"));
/*  59 */     this.themePanel.setDetailTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000157"));
/*     */ 
/*  61 */     Container contentPane = this.editorPanel;
/*     */ 
/*  63 */     contentPane.setLayout(new BoxLayout(contentPane, 1));
/*  64 */     contentPane.add(getGroupPanel());
/*  65 */     contentPane.add(getSettingPane());
/*  66 */     contentPane.add(getTotalPanel());
/*     */ 
/*  68 */     setTitle(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000007"));
/*     */   }
/*     */ 
/*     */   private ListToListPanel getGroupPanel()
/*     */   {
/*  77 */     if (this.groupPanel == null)
/*     */     {
/*  79 */       TableField[] all = this.istc.getSubTotalCandidateGroupFields();
/*  80 */       TableField[] using = this.istc.getSubTotalCurrentUsingGroupFields();
/*  81 */       ArrayList al = new ArrayList();
/*  82 */       for (int i = 0; i < all.length; i++)
/*     */       {
/*  84 */         if (!Arrays.asList(using).contains(all[i]))
/*  85 */           al.add(all[i]);
/*     */       }
/*  87 */       TableField[] nousing = (TableField[])al.toArray(new TableField[0]);
/*  88 */       this.groupPanel = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000158"), nousing, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000159"), using);
/*     */     }
/*     */ 
/*  92 */     return this.groupPanel;
/*     */   }
/*     */ 
/*     */   private ListToListPanel getTotalPanel()
/*     */   {
/*  99 */     if (this.totalPanel == null)
/*     */     {
/* 101 */       TableField[] all = this.istc.getSubTotalCandidateTotalFields();
/* 102 */       TableField[] using = this.istc.getSubTotalCurrentUsingTotalFields();
/* 103 */       ArrayList al = new ArrayList();
/* 104 */       for (int i = 0; i < all.length; i++)
/*     */       {
/* 106 */         if (!Arrays.asList(using).contains(all[i]))
/* 107 */           al.add(all[i]);
/*     */       }
/* 109 */       TableField[] nousing = (TableField[])al.toArray(new TableField[0]);
/* 110 */       this.totalPanel = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000160"), nousing, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000161"), using, null, true);
/*     */     }
/*     */ 
/* 113 */     return this.totalPanel;
/*     */   }
/*     */ 
/*     */   private UIPanel getSettingPane()
/*     */   {
/* 120 */     if (this.settingPane == null)
/*     */     {
/* 122 */       this.settingPane = new UIPanel();
/* 123 */       this.settingPane.setBorder(BorderFactory.createTitledBorder(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000162")));
/* 124 */       this.settingPane.add(getSubChooser());
/* 125 */       this.settingPane.add(getSumChooser());
/* 126 */       this.settingPane.add(getLevelChooser());
/*     */     }
/* 128 */     return this.settingPane;
/*     */   }
/*     */ 
/*     */   protected UICheckBox getSubChooser()
/*     */   {
/* 135 */     if (this.subChooser == null)
/*     */     {
/* 137 */       this.subChooser = new UICheckBox();
/* 138 */       this.subChooser.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000142"));
/* 139 */       this.subChooser.setSelected(true);
/*     */     }
/* 141 */     return this.subChooser;
/*     */   }
/*     */ 
/*     */   private UICheckBox getSumChooser()
/*     */   {
/* 148 */     if (this.sumChooser == null)
/*     */     {
/* 150 */       this.sumChooser = new UICheckBox();
/* 151 */       this.sumChooser.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000145"));
/* 152 */       this.sumChooser.setSelected(true);
/*     */     }
/* 154 */     return this.sumChooser;
/*     */   }
/*     */ 
/*     */   private UICheckBox getLevelChooser()
/*     */   {
/* 161 */     if (this.levelChooser == null)
/*     */     {
/* 163 */       this.levelChooser = new UICheckBox();
/* 164 */       this.levelChooser.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000163"));
/* 165 */       this.levelChooser.setSelected(false);
/*     */     }
/* 167 */     return this.levelChooser;
/*     */   }
/*     */ 
/*     */   public TableField[] getGroupFields()
/*     */   {
/* 175 */     TableField[] fs = new TableField[getGroupPanel().getRightData().length];
/* 176 */     for (int i = 0; i < fs.length; i++)
/*     */     {
/* 178 */       fs[i] = ((TableField)getGroupPanel().getRightData()[i]);
/*     */     }
/* 180 */     return fs;
/*     */   }
/*     */ 
/*     */   public TableField[] getTotalFields()
/*     */   {
/* 190 */     TableField[] fs = new TableField[getTotalPanel().getRightData().length];
/* 191 */     for (int i = 0; i < fs.length; i++)
/*     */     {
/* 193 */       fs[i] = ((TableField)getTotalPanel().getRightData()[i]);
/*     */     }
/* 195 */     return fs;
/*     */   }
/*     */ 
/*     */   public boolean isSum()
/*     */   {
/* 201 */     return getSumChooser().isSelected();
/*     */   }
/*     */ 
/*     */   public boolean isSub()
/*     */   {
/* 206 */     return getSubChooser().isSelected();
/*     */   }
/*     */ 
/*     */   public boolean isLevelCompute()
/*     */   {
/* 211 */     return getLevelChooser().isSelected();
/*     */   }
/*     */ 
/*     */   protected void complete()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }