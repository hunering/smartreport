/*    */ package nc.ui.trade.report.detail;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class FillInfoVO
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -5552411622852491095L;
/* 18 */   private String[] fillKey = null;
/* 19 */   private int fillType = 0;
/*    */ 
/* 21 */   public String[] getFillKey() { return this.fillKey; }
/*    */ 
/*    */   public void setFillKey(String[] fillKey) {
/* 24 */     this.fillKey = fillKey;
/*    */   }
/*    */   public int getFillType() {
/* 27 */     return this.fillType;
/*    */   }
/*    */   public void setFillType(int fillType) {
/* 30 */     this.fillType = fillType;
/*    */   }
/*    */ }