/*    */ package nc.ui.trade.report.cross;
/*    */ 
/*    */ import java.awt.dnd.DragGestureEvent;
/*    */ import java.awt.dnd.DragGestureListener;
/*    */ import java.awt.dnd.DragSource;
/*    */ import java.awt.dnd.DragSourceDragEvent;
/*    */ import java.awt.dnd.DragSourceDropEvent;
/*    */ import java.awt.dnd.DragSourceEvent;
/*    */ import java.awt.dnd.DragSourceListener;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.DefaultListModel;
/*    */ import nc.ui.pub.beans.UIList;
/*    */ import nc.ui.pub.print.util.ObjTransferable;
/*    */ 
/*    */ public class DroppableList extends UIList
/*    */   implements DragSourceListener, DragGestureListener
/*    */ {
/* 24 */   private DragSource dragSource = DragSource.getDefaultDragSource();
/*    */ 
/*    */   public DroppableList()
/*    */   {
/* 28 */     setModel(new DefaultListModel());
/* 29 */     this.dragSource.createDefaultDragGestureRecognizer(this, 3, this);
/*    */   }
/*    */ 
/*    */   public void dragEnter(DragSourceDragEvent dsde)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void dragOver(DragSourceDragEvent dsde) {
/*    */   }
/*    */ 
/*    */   public void dropActionChanged(DragSourceDragEvent dsde) {
/*    */   }
/*    */ 
/*    */   public void dragDropEnd(DragSourceDropEvent dsde) {
/*    */   }
/*    */ 
/*    */   public void dragExit(DragSourceEvent dse) {
/*    */   }
/*    */ 
/*    */   public void dragGestureRecognized(DragGestureEvent dge) {
/* 49 */     if (getSelectedValues() == null)
/* 50 */       return;
/* 51 */     Object obj = getSelectedValue();
/* 52 */     if (obj == null)
/* 53 */       System.out.println("Nothing selected - beep");
/*    */     else
/*    */       try {
/* 56 */         dge.startDrag(DragSource.DefaultCopyDrop, new ObjTransferable(obj), this);
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/*    */       }
/*    */   }
/*    */ }