/*     */ package nc.ui.trade.report.group;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.dialog.DialogThemePanel;
/*     */ import nc.ui.pub.beans.dialog.StandardUIDialog;
/*     */ import nc.ui.trade.component.ListToListPanel;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class GroupConfDLG extends StandardUIDialog
/*     */ {
/*  22 */   private TableField[] allCols = null;
/*     */ 
/*  24 */   private TableField[] groupCols = null;
/*     */ 
/*  26 */   private ListToListPanel settingPane = null;
/*     */ 
/*  28 */   private String[] groupKeys = null;
/*     */ 
/*     */   public GroupConfDLG(Container parent, TableField[] allCols, TableField[] groupCols)
/*     */   {
/*  32 */     super(parent);
/*  33 */     this.allCols = allCols;
/*  34 */     this.groupCols = groupCols;
/*  35 */     initLayout();
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/*  43 */     setSize(600, 450);
/*     */ 
/*  45 */     setErrorMsgSize(new Dimension(500, 250));
/*     */ 
/*  47 */     this.themePanel.setTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000096"));
/*  48 */     this.themePanel.setDetailTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000097"));
/*     */ 
/*  50 */     Container contentPane = this.editorPanel;
/*  51 */     contentPane.setLayout(new BorderLayout());
/*  52 */     contentPane.add(getSettingPane(), "Center");
/*     */   }
/*     */ 
/*     */   private ListToListPanel getSettingPane()
/*     */   {
/*  60 */     if (this.settingPane == null)
/*     */     {
/*  62 */       this.settingPane = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000098"), this.allCols, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000099"), this.groupCols);
/*  63 */       this.settingPane.setPreferredSize(new Dimension(500, 300));
/*     */     }
/*  65 */     return this.settingPane;
/*     */   }
/*     */ 
/*     */   public String[] getGroupKeys()
/*     */   {
/*  73 */     return this.groupKeys;
/*     */   }
/*     */ 
/*     */   private void setGroupKeys()
/*     */   {
/*  83 */     Object[] objs = getSettingPane().getRightData();
/*  84 */     if ((objs != null) && (objs.length > 0))
/*     */     {
/*  86 */       this.groupKeys = new String[objs.length];
/*  87 */       for (int i = 0; i < objs.length; i++)
/*     */       {
/*  89 */         this.groupKeys[i] = ((TableField)objs[i]).getFieldName();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String verify()
/*     */   {
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   protected void complete() throws Exception {
/* 103 */     setGroupKeys();
/*     */   }
/*     */ }