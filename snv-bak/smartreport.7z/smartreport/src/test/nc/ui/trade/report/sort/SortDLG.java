/*     */ package nc.ui.trade.report.sort;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JList;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UIList;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.dialog.DialogThemePanel;
/*     */ import nc.ui.pub.beans.dialog.StandardUIDialog;
/*     */ import nc.ui.trade.component.IListDataViewer;
/*     */ import nc.ui.trade.component.ListToListPanel;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class SortDLG extends StandardUIDialog
/*     */ {
/*  32 */   private ListToListPanel centerPane = null;
/*     */ 
/*  34 */   private SortListItem[] leftItems = null;
/*     */ 
/*  36 */   private SortListItem[] rightItems = null;
/*     */ 
/*  38 */   private AllEventHandler eventHandler = new AllEventHandler();
/*     */ 
/*  40 */   private UIButton ascBt = null;
/*     */ 
/*  42 */   private UIButton descBt = null;
/*     */ 
/*     */   public SortDLG(Container parent, String title, TableField[] leftField, TableField[] rightField)
/*     */   {
/*  87 */     super(parent, title);
/*  88 */     initData(leftField, rightField);
/*  89 */     initLayout();
/*  90 */     initListeners();
/*     */   }
/*     */ 
/*     */   private void initListeners()
/*     */   {
/*  98 */     getDescBt().addActionListener(this.eventHandler);
/*  99 */     getAscBt().addActionListener(this.eventHandler);
/*     */   }
/*     */ 
/*     */   private void initData(TableField[] leftField, TableField[] rightField)
/*     */   {
/* 107 */     if (leftField != null)
/*     */     {
/* 109 */       this.leftItems = new SortListItem[leftField.length];
/* 110 */       for (int i = 0; i < this.leftItems.length; i++)
/*     */       {
/* 112 */         this.leftItems[i] = new SortListItem();
/* 113 */         this.leftItems[i].setTableField(leftField[i]);
/* 114 */         this.leftItems[i].setAsc(true);
/*     */       }
/*     */     }
/* 117 */     if (rightField != null)
/*     */     {
/* 119 */       this.rightItems = new SortListItem[rightField.length];
/* 120 */       for (int i = 0; i < this.rightItems.length; i++)
/*     */       {
/* 122 */         this.rightItems[i] = new SortListItem();
/* 123 */         this.rightItems[i].setTableField(rightField[i]);
/* 124 */         this.rightItems[i].setAsc(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/* 134 */     setSize(620, 475);
/*     */ 
/* 136 */     this.themePanel.setTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000006"));
/* 137 */     this.themePanel.setDetailTheme(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000151"));
/*     */ 
/* 140 */     Container contentPane = this.editorPanel;
/* 141 */     contentPane.setLayout(new BorderLayout());
/* 142 */     contentPane.add(getCenterPane(), "Center");
/* 143 */     ((JList)getCenterPane().getRightList().getViewComponent()).setCellRenderer(new SortListRenderer());
/*     */   }
/*     */ 
/*     */   public ListToListPanel getCenterPane()
/*     */   {
/* 152 */     if (this.centerPane == null)
/*     */     {
/* 154 */       this.centerPane = new ListToListPanel(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000152"), this.leftItems, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000153"), this.rightItems);
/* 155 */       UIPanel panel = new UIPanel();
/* 156 */       panel.setLayout(new BoxLayout(panel, 1));
/* 157 */       panel.add(getAscBt());
/* 158 */       panel.add(Box.createVerticalStrut(ListToListPanel.VERTI_HEIGHT));
/* 159 */       panel.add(getDescBt());
/* 160 */       this.centerPane.setExtensionPanel(panel);
/*     */     }
/* 162 */     return this.centerPane;
/*     */   }
/*     */ 
/*     */   public int[] getAscOrDesc()
/*     */   {
/* 170 */     Object[] items = getCenterPane().getRightData();
/* 171 */     if (items.length == 0)
/* 172 */       return null;
/* 173 */     int[] asc = new int[items.length];
/* 174 */     for (int i = 0; i < items.length; i++)
/*     */     {
/* 176 */       asc[i] = (((SortListItem)items[i]).isAsc() ? 1 : -1);
/*     */     }
/* 178 */     return asc;
/*     */   }
/*     */ 
/*     */   public String[] getSortFields()
/*     */   {
/* 186 */     Object[] items = getCenterPane().getRightData();
/* 187 */     if (items.length == 0)
/* 188 */       return null;
/* 189 */     String[] fields = new String[items.length];
/* 190 */     for (int i = 0; i < items.length; i++)
/*     */     {
/* 192 */       fields[i] = ((SortListItem)items[i]).getTableField().getFieldName();
/*     */     }
/*     */ 
/* 195 */     return fields;
/*     */   }
/*     */ 
/*     */   public UIButton getAscBt()
/*     */   {
/* 202 */     if (this.ascBt == null)
/*     */     {
/* 204 */       this.ascBt = new UIButton();
/* 205 */       this.ascBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000100"));
/*     */     }
/* 207 */     return this.ascBt;
/*     */   }
/*     */ 
/*     */   public UIButton getDescBt()
/*     */   {
/* 215 */     if (this.descBt == null)
/*     */     {
/* 217 */       this.descBt = new UIButton();
/* 218 */       this.descBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000101"));
/*     */     }
/* 220 */     return this.descBt;
/*     */   }
/*     */ 
/*     */   protected void complete()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   class AllEventHandler
/*     */     implements ActionListener
/*     */   {
/*     */     AllEventHandler()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  49 */       if (e.getSource() == SortDLG.this.ascBt)
/*     */       {
/*  51 */         UIList list = (UIList)SortDLG.this.getCenterPane().getRightList().getViewComponent();
/*  52 */         if (list.getSelectedValues() != null)
/*     */         {
/*  54 */           for (int i = 0; i < list.getSelectedValues().length; i++)
/*     */           {
/*  56 */             ((SortListItem)list.getSelectedValues()[i]).setAsc(true);
/*     */           }
/*     */ 
/*  59 */           list.repaint();
/*     */         }
/*     */       }
/*  62 */       else if (e.getSource() == SortDLG.this.descBt)
/*     */       {
/*  64 */         UIList list = (UIList)SortDLG.this.getCenterPane().getRightList().getViewComponent();
/*  65 */         if (list.getSelectedValues() != null)
/*     */         {
/*  67 */           for (int i = 0; i < list.getSelectedValues().length; i++)
/*     */           {
/*  69 */             ((SortListItem)list.getSelectedValues()[i]).setAsc(false);
/*     */           }
/*     */ 
/*  72 */           list.repaint();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }