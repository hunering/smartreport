/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ class SumTableRow
/*     */   implements Serializable
/*     */ {
/* 231 */   private TableField field = null;
/*     */ 
/* 233 */   private Boolean subTotal = new Boolean(false);
/*     */ 
/* 235 */   private String type = null;
/*     */ 
/* 237 */   private String supplyDef = null;
/*     */ 
/*     */   protected TableField getField()
/*     */   {
/* 244 */     return this.field;
/*     */   }
/*     */ 
/*     */   protected void setField(TableField field)
/*     */   {
/* 253 */     this.field = field;
/*     */   }
/*     */ 
/*     */   protected Boolean isSubTotal()
/*     */   {
/* 261 */     return this.subTotal;
/*     */   }
/*     */ 
/*     */   protected void setSubTotal(Boolean subTotal)
/*     */   {
/* 270 */     this.subTotal = subTotal;
/*     */   }
/*     */ 
/*     */   protected String getSupplyDef()
/*     */   {
/* 278 */     return this.supplyDef;
/*     */   }
/*     */ 
/*     */   protected void setSupplyDef(String supplyDef)
/*     */   {
/* 287 */     this.supplyDef = supplyDef;
/*     */   }
/*     */ 
/*     */   protected String getType()
/*     */   {
/* 295 */     return this.type;
/*     */   }
/*     */ 
/*     */   protected void setType(String type)
/*     */   {
/* 304 */     this.type = type;
/*     */   }
/*     */ }