/*     */ package nc.ui.trade.report.detail;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import nc.jdbc.framework.SQLParameter;
/*     */ import nc.ui.pub.FramePanel;
/*     */ import nc.ui.pub.bill.BillItem;
/*     */ import nc.ui.pub.bill.BillModel;
/*     */ import nc.ui.pub.report.ReportBaseClass;
/*     */ import nc.ui.report.base.ButtonAssets;
/*     */ import nc.vo.pub.CircularlyAccessibleValueObject;
/*     */ import nc.vo.pub.formulaset.FormulaParseFather;
/*     */ import nc.vo.pub.report.ReportModelVO;
/*     */ import nc.vo.trade.report.DetailParamQryContext;
/*     */ import nc.vo.trade.report.IReportModelColumnType;
/*     */ import nc.vo.trade.report.IReportModelSelectType;
/*     */ import nc.vo.trade.report.IReportQuerySevice;
/*     */ import nc.vo.trade.report.QueryContext;
/*     */ import nc.vo.trade.report.ReportDataType2UFDateType;
/*     */ import nc.vo.trade.report.ReportQuerySeviceFacotry;
/*     */ import nc.vo.trade.report.ReportVO;
/*     */ import nc.vo.trade.report.ReportVOMetaClass;
/*     */ import nc.vo.trade.report.TableField;
/*     */ import nc.vo.trade.report.TotalParamQryContext;
/*     */ import nc.vo.trade.report.vofill.AbstractReportFactory;
/*     */ import nc.vo.trade.report.vofill.DefaultBillFill;
/*     */ import nc.vo.trade.summarize.Hashlize;
/*     */ import nc.vo.trade.summarize.VOHashKeyAdapter;
/*     */ 
/*     */ public abstract class DetailReportBaseEx2 extends DetailReportBaseEx
/*     */ {
/*     */   private static final long serialVersionUID = -1877400378295670342L;
/*  45 */   protected AbstractReportFactory reportFactory = null;
/*     */ 
/* 130 */   protected List formulaList = new ArrayList();
/*     */ 
/*     */   public DetailReportBaseEx2()
/*     */   {
/*  52 */     initialize();
/*     */   }
/*     */ 
/*     */   public DetailReportBaseEx2(FramePanel fp)
/*     */   {
/*  59 */     super(fp);
/*  60 */     initialize();
/*     */   }
/*     */ 
/*     */   protected abstract HeadEditItemVO[] getReportHeadEditVOs();
/*     */ 
/*     */   private void initialize()
/*     */   {
/*  71 */     unRegisterButton(ButtonAssets.m_boRefresh);
/*  72 */     unRegisterButton(ButtonAssets.m_boColumnFilter);
/*  73 */     unRegisterButton(ButtonAssets.m_boFilter);
/*  74 */     unRegisterButton(ButtonAssets.m_boGroup);
/*  75 */     unRegisterButton(ButtonAssets.m_boCross);
/*  76 */     unRegisterButton(ButtonAssets.m_boSort);
/*  77 */     unRegisterButton(ButtonAssets.m_boCodeLevelSubTotal);
/*  78 */     updateAllButtons();
/*  79 */     HeadEditItemVO[] items = getReportHeadEditVOs();
/*  80 */     if (items == null)
/*  81 */       return;
/*  82 */     for (int i = 0; i < items.length; i++) {
/*  83 */       HeadEditItemVO itemVO = items[i];
/*  84 */       BillItem item = getReportBase().getHeadItem(itemVO.getItemKey());
/*  85 */       if (item != null)
/*     */       {
/*  87 */         item.setEnabled(true);
/*  88 */         item.setDataType(5);
/*  89 */         item.setRefType(itemVO.getRefNodeName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void onQuery()
/*     */     throws Exception
/*     */   {
/* 100 */     updateTitle();
/*     */ 
/* 103 */     SQLParameter params = null;
/* 104 */     HeadEditItemVO[] items = getReportHeadEditVOs();
/* 105 */     if (items != null) {
/* 106 */       params = new SQLParameter();
/* 107 */       StringBuffer sb = new StringBuffer();
/* 108 */       for (int i = 0; i < items.length; i++) {
/* 109 */         HeadEditItemVO itemVO = items[i];
/* 110 */         String itemKey = itemVO.getItemKey();
/* 111 */         Object value = getReportBase().getHeadItem(itemKey).getValue();
/* 112 */         if (value == null) {
/* 113 */           throw new Exception("单据项目" + itemVO.getShowName() + "不能为空");
/*     */         }
/* 115 */         if (i == items.length - 1)
/* 116 */           sb.append(itemKey).append("=?");
/*     */         else {
/* 118 */           sb.append(itemKey).append("=?").append(" and ");
/*     */         }
/* 120 */         params.addParam(value);
/*     */       }
/*     */ 
/* 123 */       queryByCustomWhereClause(sb.toString(), params);
/*     */     }
/*     */     else {
/* 126 */       queryByCustomWhereClause(null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void getQueryFieldsAndDataType(ArrayList fields, ArrayList dataTypes)
/*     */     throws Exception
/*     */   {
/* 135 */     this.formulaList.clear();
/* 136 */     if ((fields == null) || (dataTypes == null)) {
/* 137 */       throw new IllegalArgumentException("getQueryFieldsAndDataType param is null");
/*     */     }
/*     */ 
/* 140 */     ReportModelVO[] vos = getModelVOs();
/*     */ 
/* 142 */     TableField[] vfs = getVisibleFields();
/* 143 */     List vfl = Arrays.asList(vfs);
/* 144 */     for (int i = 0; i < vos.length; i++) {
/* 145 */       TableField f = createTableFieldFromReportModelVO(vos[i]);
/*     */ 
/* 147 */       if ((vos[i].getSelectType().equals(IReportModelSelectType.AWAYSHIDE)) && (vos[i].getColumnType().intValue() == IReportModelColumnType.ORIGIN.byteValue()))
/*     */       {
/* 150 */         if (!fields.contains(f.getFieldName())) {
/* 151 */           fields.add(f.getFieldName());
/* 152 */           dataTypes.add(new Integer(ReportDataType2UFDateType.convert(vos[i].getDataType())));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 158 */       if ((vos[i].getColumnType().equals(IReportModelColumnType.ORIGIN)) && (vfl.contains(f)))
/*     */       {
/* 160 */         if (!fields.contains(f.getFieldName())) {
/* 161 */           fields.add(f.getFieldName());
/* 162 */           dataTypes.add(new Integer(ReportDataType2UFDateType.convert(vos[i].getDataType())));
/*     */         }
/*     */ 
/*     */       }
/* 167 */       else if (vos[i].getColumnType().equals(IReportModelColumnType.ORIGINFOMULA))
/*     */       {
/* 169 */         fields.add(f.getFieldName());
/* 170 */         dataTypes.add(new Integer(ReportDataType2UFDateType.convert(vos[i].getDataType())));
/*     */ 
/* 172 */         if ((vos[i].getColExpressions() != null) && (vos[i].getColExpressions().length() > 0))
/*     */         {
/* 174 */           this.formulaList.add(vos[i].getColExpressions());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void queryByCustomWhereClause(String strWhere, SQLParameter params)
/*     */     throws Exception
/*     */   {
/* 189 */     TotalParamQryContext[] totalParamQryContexts = getTotalParamQryContexts(params);
/* 190 */     CircularlyAccessibleValueObject[] oResults = null;
/* 191 */     ReportVOMetaClass voClass = getReportVOMetaClass();
/* 192 */     if (totalParamQryContexts == null) {
/* 193 */       QueryContext context = new DetailParamQryContext(voClass, null, getTableJoinClauseForQuery(), strWhere, params, null, new Integer(-1));
/*     */ 
/* 196 */       ArrayList al = getBackQryData(new QueryContext[] { context });
/* 197 */       oResults = (CircularlyAccessibleValueObject[])al.get(0);
/*     */     } else {
/* 199 */       ArrayList al = getBackQryData(totalParamQryContexts);
/*     */ 
/* 201 */       oResults = FillData(voClass, al);
/*     */     }
/*     */ 
/* 205 */     String[] formulas = (String[])this.formulaList.toArray(new String[this.formulaList.size()]);
/*     */ 
/* 208 */     processFormula(oResults, formulas, getReportBase().getBillModel().getFormulaParse());
/*     */ 
/* 211 */     setBodyDataVO(processVOs(oResults), false);
/*     */   }
/*     */ 
/*     */   protected void processFormula(CircularlyAccessibleValueObject[] results, String[] formulas, FormulaParseFather formulaParse)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected ArrayList getBackQryData(QueryContext[] ctxs)
/*     */     throws Exception
/*     */   {
/* 227 */     IReportQuerySevice service = ReportQuerySeviceFacotry.create();
/* 228 */     ArrayList al = service.query(ctxs);
/* 229 */     return al;
/*     */   }
/*     */ 
/*     */   protected ReportVO[] FillData(ReportVOMetaClass voClass, ArrayList al)
/*     */   {
/* 234 */     FillInfoVO[] fillInfoVOs = getFillInfoVO();
/*     */ 
/* 236 */     ArrayList al_map = HashlizeVO(al, fillInfoVOs);
/*     */ 
/* 239 */     HashMap resultMap = FillVOs(al_map, voClass, fillInfoVOs);
/*     */ 
/* 243 */     return extractVOs(resultMap);
/*     */   }
/*     */ 
/*     */   public abstract FillInfoVO[] getFillInfoVO();
/*     */ 
/*     */   protected abstract AbstractReportFactory getReportFactory(ReportVOMetaClass paramReportVOMetaClass);
/*     */ 
/*     */   private ReportVO[] extractVOs(HashMap<String, ArrayList<ReportVO>> resultMap)
/*     */   {
/* 268 */     ArrayList ret_al = new ArrayList();
/* 269 */     for (String key : resultMap.keySet()) {
/* 270 */       ArrayList al = (ArrayList)resultMap.get(key);
/* 271 */       ret_al.addAll(al);
/*     */     }
/* 273 */     return (ReportVO[])ret_al.toArray(new ReportVO[ret_al.size()]);
/*     */   }
/*     */ 
/*     */   private HashMap<String, ArrayList<ReportVO>> FillVOs(ArrayList<HashMap> al_map, ReportVOMetaClass voMeta, FillInfoVO[] fillInfoVOs)
/*     */   {
/* 288 */     HashMap result_map = new HashMap();
/* 289 */     DefaultBillFill bFill = new DefaultBillFill(getReportFactory(voMeta));
/* 290 */     for (int i = 0; i < al_map.size(); i++) {
/* 291 */       HashMap src_map = (HashMap)al_map.get(i);
/* 292 */       if (src_map != null) {
/* 293 */         bFill.fillBill(result_map, src_map, fillInfoVOs[i].getFillType());
/*     */       }
/*     */     }
/*     */ 
/* 297 */     return result_map;
/*     */   }
/*     */ 
/*     */   private ArrayList<HashMap> HashlizeVO(ArrayList al, FillInfoVO[] fillInfos)
/*     */   {
/* 303 */     ArrayList al_map = new ArrayList();
/* 304 */     for (int i = 0; i < al.size(); i++) {
/* 305 */       CircularlyAccessibleValueObject[] cvos = (CircularlyAccessibleValueObject[])al.get(i);
/*     */ 
/* 307 */       if ((cvos == null) || (cvos.length == 0))
/* 308 */         al_map.add(null);
/*     */       else {
/* 310 */         al_map.add(Hashlize.hashlizeObjects((Object[])al.get(i), new VOHashKeyAdapter(fillInfos[i].getFillKey())));
/*     */       }
/*     */     }
/* 313 */     return al_map;
/*     */   }
/*     */ 
/*     */   public abstract TotalParamQryContext[] getTotalParamQryContexts(SQLParameter paramSQLParameter);
/*     */ }