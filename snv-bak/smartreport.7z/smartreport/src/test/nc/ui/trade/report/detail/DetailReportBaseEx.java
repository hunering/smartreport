/*     */ package nc.ui.trade.report.detail;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.FramePanel;
/*     */ import nc.ui.report.base.ReportUIBase;
/*     */ import nc.ui.trade.report.controller.IReportCtl;
/*     */ import nc.ui.trade.report.query.QueryDLG;
/*     */ import nc.ui.trade.report.total.IQueryLink;
/*     */ import nc.vo.pub.BusinessException;
/*     */ import nc.vo.pub.CircularlyAccessibleValueObject;
/*     */ import nc.vo.pub.report.ReportModelVO;
/*     */ import nc.vo.trade.report.ConvertTool;
/*     */ import nc.vo.trade.report.DetailQueryContext;
/*     */ import nc.vo.trade.report.IReportModelColumnType;
/*     */ import nc.vo.trade.report.IReportModelSelectType;
/*     */ import nc.vo.trade.report.IReportQuerySevice;
/*     */ import nc.vo.trade.report.QueryContext;
/*     */ import nc.vo.trade.report.ReportDataType2UFDateType;
/*     */ import nc.vo.trade.report.ReportQuerySeviceFacotry;
/*     */ import nc.vo.trade.report.ReportVOMetaClass;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class DetailReportBaseEx extends ReportUIBase
/*     */   implements IQueryLink
/*     */ {
/*     */   private static final long serialVersionUID = 8486913213079165835L;
/*  36 */   private String tableJoinClauseForQuery = null;
/*     */ 
/*  38 */   private String lastCustomQueryCondition = null;
/*     */ 
/*     */   public DetailReportBaseEx()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DetailReportBaseEx(FramePanel fp)
/*     */   {
/*  52 */     super(fp);
/*     */   }
/*     */ 
/*     */   public String[] getQueryFields()
/*     */     throws Exception
/*     */   {
/*  64 */     ReportModelVO[] vos = getModelVOs();
/*     */ 
/*  66 */     TableField[] vfs = getVisibleFields();
/*  67 */     List vfl = Arrays.asList(vfs);
/*     */ 
/*  69 */     HashSet set = new HashSet();
/*  70 */     for (int i = 0; i < vos.length; i++)
/*     */     {
/*  72 */       TableField f = createTableFieldFromReportModelVO(vos[i]);
/*  73 */       if (vos[i].getColumnType().equals(IReportModelColumnType.ORIGIN))
/*     */       {
/*  76 */         if (vos[i].getSelectType().equals(IReportModelSelectType.AWAYSHIDE))
/*     */         {
/*  78 */           set.add(f.getFieldName());
/*     */         }
/*  80 */         if (vfl.contains(f)) {
/*  81 */           set.add(f.getFieldName());
/*     */         }
/*     */       }
/*     */     }
/*  85 */     return (String[])set.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   protected void getQueryFieldsAndDataType(ArrayList fields, ArrayList dataTypes)
/*     */     throws Exception
/*     */   {
/*  98 */     if ((fields == null) || (dataTypes == null)) {
/*  99 */       throw new IllegalArgumentException("getQueryFieldsAndDataType param is null");
/*     */     }
/*     */ 
/* 102 */     ReportModelVO[] vos = getModelVOs();
/*     */ 
/* 104 */     TableField[] vfs = getVisibleFields();
/* 105 */     List vfl = Arrays.asList(vfs);
/* 106 */     for (int i = 0; i < vos.length; i++)
/*     */     {
/* 108 */       TableField f = createTableFieldFromReportModelVO(vos[i]);
/*     */ 
/* 110 */       if ((vos[i].getSelectType().equals(IReportModelSelectType.AWAYSHIDE)) && (vos[i].getColumnType().intValue() == IReportModelColumnType.ORIGIN.byteValue()))
/*     */       {
/* 114 */         if (!fields.contains(f.getFieldName()))
/*     */         {
/* 116 */           fields.add(f.getFieldName());
/* 117 */           dataTypes.add(new Integer(ReportDataType2UFDateType.convert(vos[i].getDataType())));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 123 */       if ((vos[i].getColumnType().equals(IReportModelColumnType.ORIGIN)) && (vfl.contains(f)))
/*     */       {
/* 126 */         if (!fields.contains(f.getFieldName()))
/*     */         {
/* 128 */           fields.add(f.getFieldName());
/* 129 */           dataTypes.add(new Integer(ReportDataType2UFDateType.convert(vos[i].getDataType())));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ReportVOMetaClass getReportVOMetaClass()
/*     */     throws Exception
/*     */   {
/* 144 */     ArrayList fs = new ArrayList();
/* 145 */     ArrayList ds = new ArrayList();
/* 146 */     getQueryFieldsAndDataType(fs, ds);
/* 147 */     String[] fieldsname = (String[])fs.toArray(new String[0]);
/* 148 */     Integer[] datatypes = (Integer[])ds.toArray(new Integer[0]);
/* 149 */     String[] fieldAlias = (String[])ConvertTool.createFieldAlias(fieldsname);
/*     */ 
/* 152 */     return new ReportVOMetaClass(fieldsname, fieldAlias, datatypes, getUIControl().getAllTableAlias(), getUIControl().getTableJoinClause());
/*     */   }
/*     */ 
/*     */   protected String getTableJoinClauseForQuery()
/*     */   {
/* 165 */     return this.tableJoinClauseForQuery == null ? "" : this.tableJoinClauseForQuery;
/*     */   }
/*     */ 
/*     */   public void linkedQuery(String sqlWhere)
/*     */   {
/*     */     try
/*     */     {
/* 178 */       queryByCustomWhereClause(sqlWhere);
/*     */     }
/*     */     catch (BusinessException ex)
/*     */     {
/* 183 */       showErrorMessage(ex.getMessage());
/* 184 */       ex.printStackTrace();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 188 */       showErrorMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000087") + e.getMessage());
/* 189 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void onQuery()
/*     */     throws Exception
/*     */   {
/* 197 */     getQryDlg().showModal();
/* 198 */     if (getQryDlg().getResult() == 1)
/*     */     {
/* 201 */       updateReportBase();
/*     */ 
/* 203 */       updateTitle();
/* 204 */       setTableJoinClauseForQuery(getQryDlg().getTableJoinClauseForQuery());
/* 205 */       this.lastCustomQueryCondition = getQryDlg().getWhereSQL();
/* 206 */       queryByCustomWhereClause(this.lastCustomQueryCondition);
/* 207 */       if (getUIControl().isShowCondition())
/*     */       {
/* 209 */         String[] str = createConditionsFromConditionVO(getQryDlg().getConditionVO());
/*     */ 
/* 211 */         showCondition(str);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void queryByCustomWhereClause(String CustomWhereClause)
/*     */     throws Exception
/*     */   {
/* 226 */     String sqlWhere = combineDefaultSqlWhere(CustomWhereClause);
/* 227 */     ReportVOMetaClass voClass = getReportVOMetaClass();
/* 228 */     QueryContext context = new DetailQueryContext(voClass, null, getTableJoinClauseForQuery(), sqlWhere, null, new Integer(-1));
/* 229 */     IReportQuerySevice service = ReportQuerySeviceFacotry.create();
/*     */ 
/* 231 */     ArrayList al = service.query(new QueryContext[] { context });
/* 232 */     CircularlyAccessibleValueObject[] oResults = (CircularlyAccessibleValueObject[])al.get(0);
/*     */ 
/* 236 */     setBodyDataVO(processVOs(oResults), true);
/*     */   }
/*     */ 
/*     */   public void setTableJoinClauseForQuery(String newTableJoinClauseForQuery)
/*     */   {
/* 248 */     this.tableJoinClauseForQuery = newTableJoinClauseForQuery;
/*     */   }
/*     */ 
/*     */   protected void onRefresh()
/*     */     throws Exception
/*     */   {
/* 257 */     updateReportBase();
/*     */ 
/* 259 */     updateTitle();
/*     */ 
/* 261 */     queryByCustomWhereClause(this.lastCustomQueryCondition);
/* 262 */     onGroup(null);
/*     */   }
/*     */ }