/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ public class CodeLevelSubtotalDescription
/*     */ {
/*  15 */   private String[] sumCols = null;
/*  16 */   private String filterFormula = null;
/*  17 */   private String levelMode = null;
/*  18 */   private int beginLevel = 0;
/*  19 */   private int endLevel = 0;
/*  20 */   private String groupCol = null;
/*  21 */   private boolean sumColUp = true;
/*  22 */   private boolean containsOriginData = true;
/*  23 */   private String levelCol = null;
/*     */ 
/*     */   public int getBeginLevel()
/*     */   {
/*  29 */     return this.beginLevel;
/*     */   }
/*     */ 
/*     */   public void setBeginLevel(int beginLevel)
/*     */   {
/*  36 */     this.beginLevel = beginLevel;
/*     */   }
/*     */ 
/*     */   public boolean isContainsOriginData()
/*     */   {
/*  43 */     return this.containsOriginData;
/*     */   }
/*     */ 
/*     */   public void setContainsOriginData(boolean containsOriginData)
/*     */   {
/*  50 */     this.containsOriginData = containsOriginData;
/*     */   }
/*     */ 
/*     */   public int getEndLevel()
/*     */   {
/*  57 */     return this.endLevel;
/*     */   }
/*     */ 
/*     */   public void setEndLevel(int endLevel)
/*     */   {
/*  64 */     this.endLevel = endLevel;
/*     */   }
/*     */ 
/*     */   public String getFilterFormula()
/*     */   {
/*  71 */     return this.filterFormula;
/*     */   }
/*     */ 
/*     */   public void setFilterFormula(String filterFormula)
/*     */   {
/*  78 */     this.filterFormula = filterFormula;
/*     */   }
/*     */ 
/*     */   public String getGroupCol()
/*     */   {
/*  85 */     return this.groupCol;
/*     */   }
/*     */ 
/*     */   public void setGroupCol(String groupCol)
/*     */   {
/*  92 */     this.groupCol = groupCol;
/*     */   }
/*     */ 
/*     */   public String getLevelMode()
/*     */   {
/*  99 */     return this.levelMode;
/*     */   }
/*     */ 
/*     */   public void setLevelMode(String levelMode)
/*     */   {
/* 106 */     this.levelMode = levelMode;
/*     */   }
/*     */ 
/*     */   public String[] getSumCols()
/*     */   {
/* 113 */     return this.sumCols;
/*     */   }
/*     */ 
/*     */   public void setSumCols(String[] sumCols)
/*     */   {
/* 120 */     this.sumCols = sumCols;
/*     */   }
/*     */ 
/*     */   public boolean isSumColUp()
/*     */   {
/* 127 */     return this.sumColUp;
/*     */   }
/*     */ 
/*     */   public void setSumColUp(boolean sumColUp)
/*     */   {
/* 134 */     this.sumColUp = sumColUp;
/*     */   }
/*     */ 
/*     */   public String getLevelCol()
/*     */   {
/* 141 */     return this.levelCol;
/*     */   }
/*     */ 
/*     */   public void setLevelCol(String levelCol)
/*     */   {
/* 148 */     this.levelCol = levelCol;
/*     */   }
/*     */ }