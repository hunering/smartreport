/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ class SumTableModel extends AbstractTableModel
/*     */ {
/* 119 */   private String[] colNames = { NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000148"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000149"), NCLangRes.getInstance().getStrByID("common", "UC000-0003135"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000150") };
/*     */ 
/* 121 */   private SumTableRow[] bodyDatas = null;
/*     */ 
/*     */   public SumTableModel(SumTableRow[] objs)
/*     */   {
/* 125 */     this.bodyDatas = objs;
/*     */   }
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 133 */     return this.colNames.length;
/*     */   }
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 141 */     return this.bodyDatas.length;
/*     */   }
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 149 */     switch (columnIndex)
/*     */     {
/*     */     case 0:
/* 152 */       return this.bodyDatas[rowIndex].getField();
/*     */     case 1:
/* 154 */       return this.bodyDatas[rowIndex].isSubTotal();
/*     */     case 2:
/* 156 */       return this.bodyDatas[rowIndex].getType();
/*     */     case 3:
/* 158 */       return this.bodyDatas[rowIndex].getSupplyDef();
/*     */     }
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   public Class getColumnClass(int columnIndex)
/*     */   {
/* 169 */     switch (columnIndex)
/*     */     {
/*     */     case 1:
/* 172 */       return Boolean.class;
/*     */     }
/* 174 */     return String.class;
/*     */   }
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/* 183 */     return this.colNames[column];
/*     */   }
/*     */ 
/*     */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */   {
/* 191 */     if (columnIndex != 0) {
/* 192 */       return true;
/*     */     }
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */   {
/* 202 */     switch (columnIndex)
/*     */     {
/*     */     case 0:
/* 205 */       this.bodyDatas[rowIndex].setField((TableField)aValue);
/* 206 */       break;
/*     */     case 1:
/* 208 */       this.bodyDatas[rowIndex].setSubTotal((Boolean)aValue);
/* 209 */       break;
/*     */     case 2:
/* 211 */       this.bodyDatas[rowIndex].setType((String)aValue);
/* 212 */       break;
/*     */     case 3:
/* 214 */       this.bodyDatas[rowIndex].setSupplyDef((String)aValue);
/* 215 */       break;
/*     */     }
/*     */ 
/* 219 */     fireTableCellUpdated(rowIndex, columnIndex);
/*     */   }
/*     */ }