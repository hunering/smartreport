/*     */ package nc.ui.trade.report.controller;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import nc.ui.trade.report.cross.ListItemWrapperObject;
/*     */ 
/*     */ public class CrossInfo
/*     */ {
/*     */   public static final int ROWS = 1;
/*     */   public static final int COLS = 2;
/*     */   public static final int VALUES = 3;
/*     */   private ListItemWrapperObject[] crossRows;
/*     */   private ListItemWrapperObject[] crossCols;
/*     */   private ListItemWrapperObject[] crossValues;
/*     */ 
/*     */   public ListItemWrapperObject[] getCrossRows()
/*     */   {
/*  39 */     return this.crossRows;
/*     */   }
/*     */ 
/*     */   public ListItemWrapperObject[] getCrossCols()
/*     */   {
/*  44 */     return this.crossCols;
/*     */   }
/*     */ 
/*     */   public ListItemWrapperObject[] getCrossValues()
/*     */   {
/*  49 */     return this.crossValues;
/*     */   }
/*     */ 
/*     */   public void setCrossCols(ListItemWrapperObject[] crossCols)
/*     */   {
/*  58 */     this.crossCols = crossCols;
/*     */   }
/*     */ 
/*     */   public void setCrossRows(ListItemWrapperObject[] crossRows)
/*     */   {
/*  67 */     this.crossRows = crossRows;
/*     */   }
/*     */ 
/*     */   public void setCrossValues(ListItemWrapperObject[] crossValues)
/*     */   {
/*  76 */     this.crossValues = crossValues;
/*     */   }
/*     */ 
/*     */   public String[] getShowNames(int type)
/*     */   {
/*  86 */     ListItemWrapperObject[] tmp = null;
/*  87 */     switch (type)
/*     */     {
/*     */     case 1:
/*  90 */       tmp = this.crossRows;
/*  91 */       break;
/*     */     case 2:
/*  93 */       tmp = this.crossCols;
/*  94 */       break;
/*     */     case 3:
/*  96 */       tmp = this.crossValues;
/*  97 */       break;
/*     */     }
/*     */ 
/* 101 */     if (tmp != null)
/*     */     {
/* 103 */       ArrayList list = new ArrayList();
/* 104 */       for (int i = 0; i < tmp.length; i++)
/*     */       {
/* 106 */         list.add(tmp[i].getShowName());
/*     */       }
/* 108 */       return (String[])list.toArray(new String[0]);
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] getTrueNames(int type)
/*     */   {
/* 120 */     ListItemWrapperObject[] tmp = null;
/* 121 */     switch (type)
/*     */     {
/*     */     case 1:
/* 124 */       tmp = this.crossRows;
/* 125 */       break;
/*     */     case 2:
/* 127 */       tmp = this.crossCols;
/* 128 */       break;
/*     */     case 3:
/* 130 */       tmp = this.crossValues;
/* 131 */       break;
/*     */     }
/*     */ 
/* 135 */     if (tmp != null)
/*     */     {
/* 137 */       ArrayList list = new ArrayList();
/* 138 */       for (int i = 0; i < tmp.length; i++)
/*     */       {
/* 140 */         list.add(tmp[i].getTrueName());
/*     */       }
/* 142 */       return (String[])list.toArray(new String[0]);
/*     */     }
/* 144 */     return null;
/*     */   }
/*     */ }