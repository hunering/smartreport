package nc.ui.trade.report.total;

public abstract interface IQueryLink
{
  public abstract void linkedQuery(String paramString);
}