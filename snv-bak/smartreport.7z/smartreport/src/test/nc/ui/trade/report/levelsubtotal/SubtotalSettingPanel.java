/*     */ package nc.ui.trade.report.levelsubtotal;
/*     */ 
/*     */ import javax.swing.SpringLayout;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.beans.UIButton;
/*     */ import nc.ui.pub.beans.UICheckBox;
/*     */ import nc.ui.pub.beans.UILabel;
/*     */ import nc.ui.pub.beans.UIPanel;
/*     */ import nc.ui.pub.beans.UITextField;
/*     */ import nc.ui.pub.beans.layout.SpringUtilities;
/*     */ 
/*     */ public class SubtotalSettingPanel extends UIPanel
/*     */ {
/*  24 */   private UICheckBox subCheckBox = null;
/*     */ 
/*  26 */   private UICheckBox sumCheckBox = null;
/*     */ 
/*  28 */   private UITextField subSign = null;
/*     */ 
/*  30 */   private UIPanel subSignPane = null;
/*     */ 
/*  32 */   private UIPanel sumSignPane = null;
/*     */ 
/*  34 */   private UITextField sumSign = null;
/*     */ 
/*  36 */   private UIButton valueBt = null;
/*     */ 
/*  38 */   private UIButton levelBt = null;
/*     */ 
/*  40 */   private UIPanel buttonPane = null;
/*     */ 
/*     */   public SubtotalSettingPanel()
/*     */   {
/*  48 */     initLayout();
/*  49 */     initListeners();
/*     */   }
/*     */ 
/*     */   private void initListeners()
/*     */   {
/*     */   }
/*     */ 
/*     */   private void initLayout()
/*     */   {
/*  65 */     setLayout(new SpringLayout());
/*  66 */     add(getSubCheckBox());
/*  67 */     add(getSubSignPane());
/*  68 */     add(getButtonPane());
/*  69 */     add(getSumCheckBox());
/*  70 */     add(getSumSignPane());
/*  71 */     add(new UILabel());
/*  72 */     SpringUtilities.makeCompactGrid(this, 2, 3, 2, 2, 2, 2);
/*     */   }
/*     */ 
/*     */   private UIButton getLevelBt()
/*     */   {
/*  80 */     if (this.levelBt == null)
/*     */     {
/*  82 */       this.levelBt = new UIButton();
/*  83 */       this.levelBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000141"));
/*     */     }
/*  85 */     return this.levelBt;
/*     */   }
/*     */ 
/*     */   private UICheckBox getSubCheckBox()
/*     */   {
/*  93 */     if (this.subCheckBox == null)
/*     */     {
/*  95 */       this.subCheckBox = new UICheckBox();
/*  96 */       this.subCheckBox.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000142"));
/*  97 */       this.subCheckBox.setSelected(true);
/*     */     }
/*  99 */     return this.subCheckBox;
/*     */   }
/*     */ 
/*     */   private UITextField getSubSign()
/*     */   {
/* 107 */     if (this.subSign == null)
/*     */     {
/* 109 */       this.subSign = new UITextField(26);
/* 110 */       this.subSign.setMaxLength(100);
/* 111 */       this.subSign.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000143"));
/*     */     }
/* 113 */     return this.subSign;
/*     */   }
/*     */ 
/*     */   private UIPanel getSubSignPane()
/*     */   {
/* 121 */     if (this.subSignPane == null)
/*     */     {
/* 123 */       this.subSignPane = new UIPanel();
/* 124 */       UILabel label = new UILabel();
/* 125 */       label.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000144"));
/* 126 */       this.subSignPane.add(label);
/* 127 */       this.subSignPane.add(getSubSign());
/*     */     }
/* 129 */     return this.subSignPane;
/*     */   }
/*     */ 
/*     */   private UICheckBox getSumCheckBox()
/*     */   {
/* 137 */     if (this.sumCheckBox == null)
/*     */     {
/* 139 */       this.sumCheckBox = new UICheckBox();
/* 140 */       this.sumCheckBox.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000145"));
/* 141 */       this.sumCheckBox.setSelected(true);
/*     */     }
/* 143 */     return this.sumCheckBox;
/*     */   }
/*     */ 
/*     */   private UITextField getSumSign()
/*     */   {
/* 151 */     if (this.sumSign == null)
/*     */     {
/* 153 */       this.sumSign = new UITextField(26);
/* 154 */       this.sumSign.setText(NCLangRes.getInstance().getStrByID("common", "UC000-0001146"));
/*     */     }
/* 156 */     return this.sumSign;
/*     */   }
/*     */ 
/*     */   private UIPanel getSumSignPane()
/*     */   {
/* 164 */     if (this.sumSignPane == null)
/*     */     {
/* 166 */       this.sumSignPane = new UIPanel();
/* 167 */       UILabel label = new UILabel();
/* 168 */       label.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000146"));
/* 169 */       this.sumSignPane.add(label);
/* 170 */       this.sumSignPane.add(getSumSign());
/*     */     }
/* 172 */     return this.sumSignPane;
/*     */   }
/*     */ 
/*     */   private UIButton getValueBt()
/*     */   {
/* 180 */     if (this.valueBt == null)
/*     */     {
/* 182 */       this.valueBt = new UIButton();
/* 183 */       this.valueBt.setText(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000080"));
/*     */     }
/* 185 */     return this.valueBt;
/*     */   }
/*     */ 
/*     */   protected UIPanel getButtonPane()
/*     */   {
/* 193 */     if (this.buttonPane == null)
/*     */     {
/* 195 */       this.buttonPane = new UIPanel();
/* 196 */       this.buttonPane.add(getLevelBt());
/* 197 */       this.buttonPane.add(getValueBt());
/*     */     }
/* 199 */     return this.buttonPane;
/*     */   }
/*     */ }