/*    */ package nc.ui.trade.report.group;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.StringTokenizer;
/*    */ import javax.swing.table.DefaultTableModel;
/*    */ 
/*    */ public class GroupTableModel extends DefaultTableModel
/*    */ {
/*    */   public void addRows(Set set)
/*    */   {
/* 23 */     if ((set == null) || (set.size() == 0))
/* 24 */       return;
/* 25 */     Iterator it = set.iterator();
/* 26 */     while (it.hasNext())
/*    */     {
/* 28 */       StringTokenizer token = new StringTokenizer(it.next().toString(), ":");
/*    */ 
/* 30 */       String[] str = new String[token.countTokens()];
/* 31 */       int index = 0;
/* 32 */       while (token.hasMoreTokens())
/*    */       {
/* 34 */         str[(index++)] = token.nextToken();
/*    */       }
/* 36 */       addRow(str);
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isCellEditable(int row, int column)
/*    */   {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */   public void addColumns(String[] columns)
/*    */   {
/* 50 */     if ((columns == null) || (columns.length == 0))
/* 51 */       return;
/* 52 */     for (int i = 0; i < columns.length; i++)
/*    */     {
/* 54 */       addColumn(columns[i]);
/*    */     }
/*    */   }
/*    */ }