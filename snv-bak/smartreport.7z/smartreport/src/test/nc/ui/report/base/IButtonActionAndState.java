package nc.ui.report.base;

public abstract interface IButtonActionAndState
{
  public static final int ENABLE_ALWAYS = 2;
  public static final int ENABLE_WHEN_HAS_DATA = 3;

  public abstract void execute()
    throws Exception;

  public abstract int isButtonAvailable();
}