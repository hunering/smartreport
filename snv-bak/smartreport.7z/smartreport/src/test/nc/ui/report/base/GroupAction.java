/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.ui.trade.report.group.GroupConfDLG;
/*    */ import nc.vo.trade.report.TableField;
/*    */ 
/*    */ public class GroupAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public GroupAction(ReportUIBase reportUIBase)
/*    */   {
/* 26 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 34 */     ArrayList keyList = getReportUIBase().getGroupKeys();
/* 35 */     ArrayList visibleList = new ArrayList();
/* 36 */     ArrayList groupList = new ArrayList();
/* 37 */     visibleList.addAll(Arrays.asList(getReportUIBase().getVisibleFields()));
/*    */ 
/* 39 */     for (int i = 0; i < visibleList.size(); i++)
/*    */     {
/* 41 */       for (int j = 0; j < keyList.size(); j++)
/*    */       {
/* 43 */         if (((TableField)visibleList.get(i)).getFieldName().equals(keyList.get(j)))
/*    */         {
/* 46 */           groupList.add(visibleList.get(i));
/* 47 */           visibleList.remove(i);
/* 48 */           keyList.remove(j);
/* 49 */           break;
/*    */         }
/*    */       }
/*    */     }
/* 53 */     if (keyList.size() > 0)
/*    */     {
/* 55 */       TableField[] fields = new TableField[keyList.size()];
/* 56 */       for (int i = 0; i < fields.length; i++)
/*    */       {
/* 58 */         fields[i] = new TableField(keyList.get(i).toString(), getReportUIBase().getColumnNameByKey(getReportUIBase().convertVOFieldNameToReportModelFieldName(keyList.get(i).toString())));
/*    */       }
/*    */ 
/* 67 */       groupList.addAll(Arrays.asList(fields));
/*    */     }
/* 69 */     TableField[] visibleFields = visibleList.size() > 0 ? (TableField[])visibleList.toArray(new TableField[0]) : null;
/*    */ 
/* 72 */     TableField[] groupFields = groupList.size() > 0 ? (TableField[])groupList.toArray(new TableField[0]) : null;
/*    */ 
/* 76 */     GroupConfDLG dlg = new GroupConfDLG(getReportUIBase(), visibleFields, groupFields);
/* 77 */     if (dlg.showModal() == 1)
/*    */     {
/* 79 */       getReportUIBase().onGroup(dlg.getGroupKeys());
/*    */ 
/* 81 */       getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000018"));
/*    */     }
/*    */   }
/*    */ }