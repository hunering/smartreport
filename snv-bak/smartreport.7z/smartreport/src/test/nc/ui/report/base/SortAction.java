/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.ui.trade.report.sort.SortDLG;
/*    */ 
/*    */ public class SortAction extends AbstractActionHasDataAvailable
/*    */ {
/* 20 */   SortDLG sortDlg = null;
/*    */ 
/*    */   public SortAction(ReportUIBase reportUIBase)
/*    */   {
/* 27 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public SortAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 45 */     if (getSortDlg().showModal() == 1)
/*    */     {
/* 47 */       if (getSortDlg().getSortFields() != null)
/*    */       {
/* 49 */         String[] fields = getSortDlg().getSortFields();
/* 50 */         int[] asc = getSortDlg().getAscOrDesc();
/* 51 */         getReportUIBase().onSort(fields, asc);
/*    */ 
/* 53 */         getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000034"));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   private SortDLG getSortDlg()
/*    */   {
/* 60 */     if (this.sortDlg == null) {
/* 61 */       this.sortDlg = new SortDLG(getReportUIBase(), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000006"), getReportUIBase().getVisibleFields(), null);
/*    */     }
/* 63 */     return this.sortDlg;
/*    */   }
/*    */ }