/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import nc.ui.ml.NCLangRes;
/*    */ 
/*    */ public class QueryAction extends AbstractActionAlwaysAvailable
/*    */ {
/*    */   public QueryAction(ReportUIBase reportUIBase)
/*    */   {
/* 22 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public QueryAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 40 */     getReportUIBase().onQuery();
/*    */ 
/* 42 */     getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000031"));
/*    */   }
/*    */ }