/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public abstract class AbstractActionJudgeBySelf
/*    */   implements IButtonActionAndState
/*    */ {
/* 17 */   ReportUIBase reportUIBase = null;
/*    */ 
/*    */   public AbstractActionJudgeBySelf()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AbstractActionJudgeBySelf(ReportUIBase reportUIBase)
/*    */   {
/* 26 */     this.reportUIBase = reportUIBase;
/*    */   }
/*    */ 
/*    */   public ReportUIBase getReportUIBase()
/*    */   {
/* 34 */     return this.reportUIBase;
/*    */   }
/*    */ 
/*    */   public void setReportUIBase(ReportUIBase reportUIBase)
/*    */   {
/* 43 */     this.reportUIBase = reportUIBase;
/*    */   }
/*    */ }