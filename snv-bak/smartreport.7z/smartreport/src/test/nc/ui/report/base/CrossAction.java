/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import nc.bs.logging.Logger;
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.ui.pub.beans.MessageDialog;
/*    */ import nc.ui.trade.report.controller.CrossInfo;
/*    */ import nc.ui.trade.report.cross.CrossDLG;
/*    */ import nc.vo.pub.BusinessException;
/*    */ 
/*    */ public class CrossAction extends AbstractActionHasDataAvailable
/*    */ {
/* 24 */   private CrossDLG m_crossDlg = null;
/*    */ 
/*    */   public CrossAction(ReportUIBase reportUIBase)
/*    */   {
/* 28 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 38 */     if (getCrossDLG().showModal() == 1)
/*    */     {
/* 40 */       CrossInfo result = getCrossDLG().getCrossInfoResult();
/*    */       try {
/* 42 */         getReportUIBase().onCross(result.getTrueNames(1), result.getTrueNames(2), result.getTrueNames(3));
/*    */       }
/*    */       catch (BusinessException e)
/*    */       {
/* 47 */         throw e;
/*    */       }
/*    */       catch (Exception e) {
/* 50 */         MessageDialog.showErrorDlg(getReportUIBase(), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000015"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000016"));
/* 51 */         Logger.error(e.getMessage(), e);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   private CrossDLG getCrossDLG()
/*    */   {
/* 61 */     if (this.m_crossDlg == null)
/*    */     {
/* 63 */       this.m_crossDlg = new CrossDLG(getReportUIBase(), getReportUIBase().getModelVOs());
/*    */     }
/*    */ 
/* 66 */     return this.m_crossDlg;
/*    */   }
/*    */ }