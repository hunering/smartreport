/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import junit.framework.Test;
/*    */ import junit.framework.TestCase;
/*    */ import junit.framework.TestSuite;
/*    */ import junit.textui.TestRunner;
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.vo.trade.report.TableField;
/*    */ import nc.vo.trade.report.TotalField;
/*    */ import nc.vo.trade.report.TotalOperator;
/*    */ 
/*    */ public class TestTotalfieldAndOperator extends TestCase
/*    */ {
/*    */   public TestTotalfieldAndOperator()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TestTotalfieldAndOperator(String name)
/*    */   {
/* 29 */     super(name);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 40 */     TestRunner.run(suite());
/*    */   }
/*    */ 
/*    */   public static Test suite()
/*    */   {
/* 50 */     TestSuite suite = new TestSuite();
/* 51 */     suite.addTest(new TestTotalfieldAndOperator("testCtorAndMember"));
/* 52 */     return suite;
/*    */   }
/*    */ 
/*    */   public void testCtorAndMember()
/*    */   {
/* 60 */     TotalField f1 = new TotalField(new TableField("fmny", NCLangRes.getInstance().getStrByID("common", "UC000-0004112")), TotalOperator.SUM);
/*    */ 
/* 62 */     TotalField f2 = new TotalField(new TableField("fprice", NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000035")), TotalOperator.AVG);
/*    */ 
/* 64 */     assertEquals("fmny", f1.getField().getFieldName());
/* 65 */     assertEquals(NCLangRes.getInstance().getStrByID("common", "UC000-0004112"), "" + f1.getField());
/* 66 */     assertEquals(TotalOperator.SUM, f1.getOperator());
/* 67 */     assertEquals(TotalOperator.AVG, f2.getOperator());
/* 68 */     assertNotSame(TotalOperator.SUM, TotalOperator.AVG);
/* 69 */     assertEquals("avg", TotalOperator.AVG.getOperator());
/* 70 */     assertEquals("sum", TotalOperator.SUM.getOperator());
/*    */   }
/*    */ }