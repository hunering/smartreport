/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import nc.ui.ml.NCLangRes;
/*    */ 
/*    */ public class RefreshAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public RefreshAction(ReportUIBase reportUIBase)
/*    */   {
/* 20 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public RefreshAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 36 */     getReportUIBase().onRefresh();
/*    */ 
/* 38 */     getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("common", "UCH007"));
/*    */   }
/*    */ }