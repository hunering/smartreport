/*      */ package nc.ui.report.base;
/*      */ 
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FlowLayout;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import javax.swing.ListSelectionModel;
/*      */ import javax.swing.event.ListSelectionEvent;
/*      */ import javax.swing.event.ListSelectionListener;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ import javax.swing.table.TableModel;
/*      */ import nc.bs.logging.Logger;
/*      */ import nc.ui.ml.NCLangRes;
/*      */ import nc.ui.pub.ButtonObject;
/*      */ import nc.ui.pub.FramePanel;
/*      */ import nc.ui.pub.ToftPanel;
/*      */ import nc.ui.pub.beans.MessageDialog;
/*      */ import nc.ui.pub.beans.UILabel;
/*      */ import nc.ui.pub.beans.UIPanel;
/*      */ import nc.ui.pub.beans.UIScrollPane;
/*      */ import nc.ui.pub.beans.UISplitPane;
/*      */ import nc.ui.pub.beans.UITable;
/*      */ import nc.ui.pub.bill.BillModel;
/*      */ import nc.ui.pub.print.PrintDirectEntry;
/*      */ import nc.ui.pub.report.ReportBaseClass;
/*      */ import nc.ui.pub.report.ReportItem;
/*      */ import nc.ui.pub.report.ReportSortUtil;
/*      */ import nc.ui.trade.report.controller.IReportCtl;
/*      */ import nc.ui.trade.report.controller.ReportCtl;
/*      */ import nc.ui.trade.report.group.GroupTableModel;
/*      */ import nc.ui.trade.report.query.QueryDLG;
/*      */ import nc.vo.pub.BusinessException;
/*      */ import nc.vo.pub.CircularlyAccessibleValueObject;
/*      */ import nc.vo.pub.query.ConditionVO;
/*      */ import nc.vo.pub.query.RefResultVO;
/*      */ import nc.vo.pub.report.ReportModelVO;
/*      */ import nc.vo.pub.report.SubtotalContext;
/*      */ import nc.vo.trade.report.ConvertTool;
/*      */ import nc.vo.trade.report.IReportModelSelectType;
/*      */ import nc.vo.trade.report.ReportDataType2UFDateType;
/*      */ import nc.vo.trade.report.ReportVO;
/*      */ import nc.vo.trade.report.ReportVOMetaClass;
/*      */ import nc.vo.trade.report.TableField;
/*      */ 
/*      */ public abstract class ReportUIBase extends ToftPanel
/*      */ {
/*   48 */   private UIPanel conditionPanel = null;
/*      */ 
/*   51 */   private UISplitPane veriSplitPane = null;
/*      */ 
/*   54 */   private ReportBaseClass m_report = null;
/*      */ 
/*   57 */   private ReportBaseClass m_reportForPrint = null;
/*      */   protected static final char columnSystemDelimiter = '_';
/*   68 */   private ArrayList reportModelColumnGroups = new ArrayList();
/*      */   private IReportCtl m_uiCtl;
/*   73 */   private ReportModelVO[] copyOfReportModelVOs = null;
/*      */ 
/*   76 */   private QueryDLG m_qryDlg = null;
/*      */ 
/*   79 */   private ButtonAssets button_action_map = new ButtonAssets(this);
/*      */ 
/*   82 */   private UITable groupTable = null;
/*      */ 
/*   85 */   private HashMap groupMap = new HashMap();
/*      */ 
/*   88 */   private ArrayList groupKeys = new ArrayList();
/*      */ 
/*   90 */   private CircularlyAccessibleValueObject[] allBodyDataVO = null;
/*      */ 
/*   92 */   private boolean needGroup = false;
/*      */ 
/*   94 */   private UIScrollPane groupSPane = null;
/*      */ 
/*      */   public ReportUIBase()
/*      */   {
/*  101 */     initialize();
/*      */   }
/*      */ 
/*      */   public ReportUIBase(FramePanel fp)
/*      */   {
/*  109 */     setFrame(fp);
/*  110 */     initialize();
/*      */   }
/*      */ 
/*      */   protected void backupReportModelVOs()
/*      */   {
/*  117 */     ArrayList al = new ArrayList();
/*  118 */     for (int i = 0; i < getReportBase().getAllBodyVOs().length; i++)
/*      */     {
/*  120 */       if (!getReportBase().getAllBodyVOs()[i].getSelectType().equals(IReportModelSelectType.UNSELECTED))
/*      */       {
/*  122 */         al.add(getReportBase().getAllBodyVOs()[i].clone());
/*      */       }
/*      */     }
/*  125 */     this.copyOfReportModelVOs = ((ReportModelVO[])al.toArray(new ReportModelVO[0]));
/*      */   }
/*      */ 
/*      */   protected String combineDefaultSqlWhere(String customSqlWhere)
/*      */   {
/*  139 */     String result = null;
/*  140 */     boolean isCustomSqlWhereEmpty = (customSqlWhere == null) || (customSqlWhere.length() == 0);
/*      */ 
/*  142 */     boolean isDefaultSqlWhereEmpty = (getUIControl().getDefaultSqlWhere() == null) || (getUIControl().getDefaultSqlWhere().trim().length() == 0);
/*      */ 
/*  145 */     if (isCustomSqlWhereEmpty)
/*  146 */       result = getUIControl().getDefaultSqlWhere();
/*  147 */     if (isDefaultSqlWhereEmpty)
/*  148 */       result = customSqlWhere;
/*  149 */     if ((!isCustomSqlWhereEmpty) && (!isDefaultSqlWhereEmpty)) {
/*  150 */       result = customSqlWhere + " and " + getUIControl().getDefaultSqlWhere();
/*      */     }
/*  152 */     if ((result != null) && (result.trim().length() == 0))
/*  153 */       result = null;
/*  154 */     return result;
/*      */   }
/*      */ 
/*      */   protected String convertReportModelFieldNameToVOFieldName(String reportFieldName)
/*      */   {
/*  167 */     if (reportFieldName.indexOf('_') == -1) {
/*  168 */       return reportFieldName;
/*      */     }
/*  170 */     return reportFieldName.substring(0, reportFieldName.indexOf('_')) + "." + reportFieldName.substring(reportFieldName.indexOf('_') + 1, reportFieldName.length());
/*      */   }
/*      */ 
/*      */   protected String convertVOFieldNameToReportModelFieldName(String voFieldName)
/*      */   {
/*  185 */     if (voFieldName.indexOf('.') == -1) {
/*  186 */       return voFieldName;
/*      */     }
/*  188 */     return voFieldName.substring(0, voFieldName.indexOf('.')) + "_" + voFieldName.substring(voFieldName.indexOf('.') + 1, voFieldName.length());
/*      */   }
/*      */ 
/*      */   protected String[] createConditionsFromConditionVO(ConditionVO[] vos)
/*      */   {
/*  201 */     String[] conditions = new String[vos.length];
/*  202 */     for (int i = 0; i < vos.length; i++) {
/*  203 */       conditions[i] = (vos[i].getFieldName() + vos[i].getOperaCode());
/*  204 */       if (vos[i].getRefResult() != null)
/*      */       {
/*      */         int tmp63_62 = i;
/*      */         String[] tmp63_61 = conditions; tmp63_61[tmp63_62] = (tmp63_61[tmp63_62] + vos[i].getRefResult().getRefName());
/*      */       }
/*      */       else
/*      */       {
/*      */         int tmp96_95 = i;
/*      */         String[] tmp96_94 = conditions; tmp96_94[tmp96_95] = (tmp96_94[tmp96_95] + vos[i].getValue());
/*      */       }
/*      */     }
/*  209 */     return conditions;
/*      */   }
/*      */ 
/*      */   protected IReportCtl createIReportCtl()
/*      */   {
/*  218 */     return new ReportCtl();
/*      */   }
/*      */ 
/*      */   protected QueryDLG createQueryDLG()
/*      */   {
/*  227 */     QueryDLG dlg = new QueryDLG();
/*      */ 
/*  229 */     dlg.setTempletID(getUIControl()._getPk_corp(), getModuleCode(), getUIControl()._getOperator(), null);
/*      */ 
/*  231 */     dlg.setNormalShow(false);
/*  232 */     return dlg;
/*      */   }
/*      */ 
/*      */   protected TableField createTableFieldFromReportModelVO(ReportModelVO vo)
/*      */   {
/*  243 */     return new TableField(convertReportModelFieldNameToVOFieldName(vo.getColumnCode()), vo.getColumnUser(), (vo.getDataType().intValue() == 1) || (vo.getDataType().intValue() == 2));
/*      */   }
/*      */ 
/*      */   protected String[] getAllColumnCodes()
/*      */   {
/*  255 */     ReportModelVO[] vos = getReportBase().getAllBodyVOs();
/*  256 */     String[] names = new String[vos.length];
/*  257 */     for (int i = 0; i < vos.length; i++) {
/*  258 */       names[i] = vos[i].getColumnCode();
/*      */     }
/*  260 */     return names;
/*      */   }
/*      */ 
/*      */   protected void getAllFieldsAndDataType(ArrayList fields, ArrayList dataTypes)
/*      */   {
/*  272 */     if ((fields == null) || (dataTypes == null)) {
/*  273 */       throw new IllegalArgumentException("getQueryFieldsAndDataType param is null");
/*      */     }
/*      */ 
/*  276 */     ReportModelVO[] vos = getModelVOs();
/*      */ 
/*  280 */     for (int i = 0; i < vos.length; i++) {
/*  281 */       TableField f = createTableFieldFromReportModelVO(vos[i]);
/*  282 */       fields.add(f.getFieldName());
/*  283 */       dataTypes.add(new Integer(ReportDataType2UFDateType.convert(vos[i].getDataType())));
/*      */     }
/*      */   }
/*      */ 
/*      */   private ButtonObject[] getAllBtnAry()
/*      */   {
/*  295 */     if (this.button_action_map.getVisibleButtonsByOrder().size() == 0)
/*  296 */       return null;
/*  297 */     return (ButtonObject[])this.button_action_map.getVisibleButtonsByOrder().toArray(new ButtonObject[0]);
/*      */   }
/*      */ 
/*      */   protected String[] getColumnGroupsByColumnCode(String column_code)
/*      */   {
/*  308 */     for (int i = 0; i < this.reportModelColumnGroups.size(); i++) {
/*  309 */       ArrayList al = (ArrayList)this.reportModelColumnGroups.get(i);
/*  310 */       if (al.contains(column_code)) {
/*  311 */         return (String[])al.toArray(new String[0]);
/*      */       }
/*      */     }
/*  314 */     return new String[0];
/*      */   }
/*      */ 
/*      */   protected UIPanel getConditionPanel()
/*      */   {
/*  322 */     if (this.conditionPanel == null) {
/*  323 */       this.conditionPanel = new UIPanel();
/*  324 */       this.conditionPanel.setName("ConditionPanel");
/*  325 */       FlowLayout l = new FlowLayout();
/*  326 */       l.setAlignment(0);
/*  327 */       l.setHgap(10);
/*      */ 
/*  329 */       this.conditionPanel.setLayout(l);
/*      */     }
/*  331 */     return this.conditionPanel;
/*      */   }
/*      */ 
/*      */   protected TableField[] getInvisibleFields()
/*      */   {
/*  341 */     ReportModelVO[] vos = getModelVOs();
/*  342 */     ArrayList invisible = new ArrayList();
/*  343 */     for (int i = 0; i < vos.length; i++) {
/*  344 */       if (vos[i].getSelectType().intValue() == IReportModelSelectType.VISIBLE.intValue()) {
/*      */         try
/*      */         {
/*  347 */           getReportBase().getBillTable().getColumn(vos[i].getColumnUser());
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  353 */           invisible.add(createTableFieldFromReportModelVO(vos[i]));
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  359 */     TableField[] invisibleFields = (TableField[])invisible.toArray(new TableField[0]);
/*      */ 
/*  362 */     return invisibleFields;
/*      */   }
/*      */ 
/*      */   protected TableField[] getVisibleFields()
/*      */   {
/*  371 */     ReportModelVO[] vos = getModelVOs();
/*  372 */     ArrayList visible = new ArrayList();
/*  373 */     for (int i = 0; i < vos.length; i++) {
/*  374 */       if (vos[i].getSelectType().intValue() == IReportModelSelectType.VISIBLE.intValue()) {
/*      */         try
/*      */         {
/*  377 */           getReportBase().getBillTable().getColumn(vos[i].getColumnUser());
/*      */ 
/*  379 */           visible.add(createTableFieldFromReportModelVO(vos[i]));
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*  386 */     TableField[] visibleFields = (TableField[])visible.toArray(new TableField[0]);
/*      */ 
/*  389 */     return visibleFields;
/*      */   }
/*      */ 
/*      */   public QueryDLG getQryDlg() {
/*  393 */     if (this.m_qryDlg == null) {
/*  394 */       this.m_qryDlg = createQueryDLG();
/*      */     }
/*  396 */     return this.m_qryDlg;
/*      */   }
/*      */ 
/*      */   public ReportBaseClass getReportBase()
/*      */   {
/*  404 */     if (this.m_report == null) {
/*      */       try {
/*  406 */         this.m_report = new ReportBaseClass();
/*  407 */         this.m_report.setName("ReportBase");
/*  408 */         this.m_report.setTempletID(getUIControl()._getPk_corp(), getModuleCode(), getUIControl()._getOperator(), null);
/*      */ 
/*  411 */         this.m_report.getBillTable().getSelectionModel().addListSelectionListener(new ListSelectionListener()
/*      */         {
/*      */           public void valueChanged(ListSelectionEvent e)
/*      */           {
/*  415 */             ReportUIBase.this.updateAllButtons();
/*      */           }
/*      */         });
/*      */       }
/*      */       catch (Exception ex) {
/*  420 */         MessageDialog.showErrorDlg(this, NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000032"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000033"));
/*      */ 
/*  429 */         Logger.error(ex.getMessage(), ex);
/*      */       }
/*      */     }
/*  432 */     return this.m_report;
/*      */   }
/*      */ 
/*      */   protected UITable getGroupTable() {
/*  436 */     if (this.groupTable == null) {
/*  437 */       this.groupTable = new UITable(new DefaultTableModel());
/*  438 */       this.groupTable.addMouseListener(new MouseAdapter() {
/*      */         public void mouseReleased(MouseEvent e) {
/*  440 */           int row = ReportUIBase.this.groupTable.getSelectedRow();
/*  441 */           if (row == -1)
/*  442 */             return;
/*  443 */           int count = ReportUIBase.this.groupTable.getModel().getColumnCount();
/*  444 */           StringBuffer key = new StringBuffer();
/*  445 */           for (int i = 0; i < count; i++) {
/*  446 */             key.append(ReportUIBase.this.groupTable.getModel().getValueAt(row, i) == null ? "" : ReportUIBase.this.groupTable.getModel().getValueAt(row, i).toString());
/*      */ 
/*  451 */             if (i != count - 1)
/*  452 */               key.append(":");
/*      */           }
/*  454 */           ArrayList tmpVO = (ArrayList)ReportUIBase.this.groupMap.get(key.toString());
/*  455 */           if ((tmpVO != null) && (tmpVO.size() > 0)) {
/*  456 */             ReportUIBase.this.setBodyDataVO((CircularlyAccessibleValueObject[])tmpVO.toArray(new CircularlyAccessibleValueObject[0]), false);
/*      */           }
/*      */ 
///*  461 */           ReportUIBase.this.setHeadItems(
//							ReportUIBase.this.convertVOKeysToModelKeys(
//									(String[])ReportUIBase.this.groupKeys.toArray(new String[0])), 
//									ReportUIBase.access$300(ReportUIBase.this, row));
/*      */         }
/*      */ 
/*      */       });
/*      */     }
/*      */ 
/*  468 */     return this.groupTable;
/*      */   }
/*      */ 
/*      */   protected void updateTitle()
/*      */   {
/*  476 */     updateTitle(getReportBase().getReportTitle());
/*      */   }
/*      */ 
/*      */   protected void updateTitle(String strTitle)
/*      */   {
/*  485 */     setTitleText(strTitle);
/*      */   }
/*      */ 
/*      */   protected void updateReportBase() {
/*  489 */     if (this.m_report == null)
/*  490 */       return;
/*      */     try {
/*  492 */       this.m_report.setTempletID(getUIControl()._getPk_corp(), getModuleCode(), getUIControl()._getOperator(), null);
/*      */     }
/*      */     catch (Exception e) {
/*  495 */       Logger.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public ReportBaseClass getReportBaseForPrint()
/*      */   {
/*  505 */     if (this.m_reportForPrint == null) {
/*      */       try {
/*  507 */         this.m_reportForPrint = new ReportBaseClass();
/*  508 */         this.m_reportForPrint.setName("ReportBaseForPrint");
/*  509 */         this.m_reportForPrint.setTempletID(getUIControl()._getPk_corp(), getModuleCode(), getUIControl()._getOperator(), null);
/*      */       }
/*      */       catch (Exception ex) {
/*  512 */         System.out.println("鍩虹被:鏈壘鍒版姤琛ㄦā鏉�......");
/*      */       }
/*      */     }
/*  515 */     return this.m_reportForPrint;
/*      */   }
/*      */ 
/*      */   protected ReportVOMetaClass getReportVOMetaClassOfAllFields()
/*      */   {
/*  526 */     ArrayList fs = new ArrayList();
/*  527 */     ArrayList ds = new ArrayList();
/*  528 */     getAllFieldsAndDataType(fs, ds);
/*  529 */     String[] fieldsname = (String[])fs.toArray(new String[0]);
/*  530 */     Integer[] datatypes = (Integer[])ds.toArray(new Integer[0]);
/*  531 */     String[] fieldAlias = (String[])ConvertTool.createFieldAlias(fieldsname);
/*      */ 
/*  534 */     return new ReportVOMetaClass(fieldsname, fieldAlias, datatypes, getUIControl().getAllTableAlias(), getUIControl().getTableJoinClause());
/*      */   }
/*      */ 
/*      */   public String getTitle()
/*      */   {
/*  546 */     return getReportBase().getReportTitle();
/*      */   }
/*      */ 
/*      */   public IReportCtl getUIControl()
/*      */   {
/*  555 */     if (this.m_uiCtl == null)
/*  556 */       this.m_uiCtl = createIReportCtl();
/*  557 */     return this.m_uiCtl;
/*      */   }
/*      */ 
/*      */   public CircularlyAccessibleValueObject[] getVOFromUI()
/*      */   {
/*  566 */     ReportVOMetaClass voClass = getReportVOMetaClassOfAllFields();
/*  567 */     ReportItem[] items = getReportBase().getBody_Items();
/*  568 */     int rows = getReportBase().getRowCount();
/*  569 */     ReportVO[] result = new ReportVO[rows];
/*  570 */     for (int row = 0; row < rows; row++) {
/*  571 */       result[row] = voClass.createReportVO();
/*  572 */       for (int i = 0; i < items.length; i++)
/*      */       {
/*  574 */         result[row].setAttributeValue(items[i].getKey(), getReportBase().getBodyValueAt(row, items[i].getKey()));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  580 */     return result;
/*      */   }
/*      */ 
/*      */   public CircularlyAccessibleValueObject[] getCurrentVO()
/*      */   {
/*  590 */     CircularlyAccessibleValueObject[] cvos = null;
/*  591 */     if ((cvos = getCurrentVOFromGroupMap()) == null) {
/*  592 */       cvos = getVOFromUI();
/*      */     }
/*  594 */     return cvos;
/*      */   }
/*      */ 
/*      */   public CircularlyAccessibleValueObject[] getAllBodyDataVO()
/*      */   {
/*  604 */     if (this.allBodyDataVO == null) {
/*      */       try {
/*  606 */         this.allBodyDataVO = getVOFromUI();
/*      */       } catch (Exception e) {
/*  608 */         Logger.error(e.getMessage(), e);
/*      */       }
/*      */     }
/*  611 */     return this.allBodyDataVO;
/*      */   }
/*      */ 
/*      */   protected void initColumnGroups()
/*      */   {
/*  618 */     ReportModelVO[] vos = getModelVOs();
/*  619 */     HashMap tmpHash = new HashMap();
/*      */ 
/*  621 */     for (int i = 0; i < vos.length; i++) {
/*  622 */       int index = vos[i].getColumnSystem().indexOf('_');
/*      */       String key;
/*  625 */       if (index != -1)
/*  626 */         key = vos[i].getColumnSystem().substring(0, index);
/*      */       else
/*  628 */         key = vos[i].getColumnSystem();
/*      */       ArrayList al;
/*  630 */       if (tmpHash.get(key) == null) {
/*  631 */         al = new ArrayList();
/*  632 */         tmpHash.put(key, al);
/*      */       } else {
/*  634 */         al = (ArrayList)tmpHash.get(key);
/*      */       }
/*  636 */       al.add(vos[i].getColumnCode());
/*      */     }
/*      */ 
/*  639 */     this.reportModelColumnGroups.addAll(tmpHash.values());
/*      */   }
/*      */ 
/*      */   private void initialize() {
/*  643 */     setName("GeneralPane");
/*  644 */     setSize(774, 419);
/*      */ 
/*  646 */     UISplitPane horiSplitPane = new UISplitPane(0, null, getVeriSplitPane());
/*      */ 
/*  649 */     if (!getUIControl().isShowCondition()) {
/*  650 */       horiSplitPane.setLeftComponent(null);
/*  651 */       horiSplitPane.setDividerLocation(0);
/*  652 */       horiSplitPane.setEnabled(false);
/*  653 */       horiSplitPane.setDividerSize(0);
/*      */     } else {
/*  655 */       horiSplitPane.setLeftComponent(getConditionPanel());
/*  656 */       horiSplitPane.setDividerLocation(80);
/*  657 */       horiSplitPane.setOneTouchExpandable(true);
/*  658 */       horiSplitPane.setDividerSize(6);
/*      */     }
/*      */ 
/*  661 */     add(horiSplitPane);
/*      */ 
/*  664 */     setPrivateButtons();
/*      */ 
/*  666 */     getReportBase();
/*      */ 
/*  668 */     setButtons(getAllBtnAry());
/*      */ 
/*  670 */     updateAllButtons();
/*      */ 
/*  672 */     backupReportModelVOs();
/*      */ 
/*  674 */     if (getUIControl().getGroupKeys() != null) {
/*  675 */       this.needGroup = true;
/*      */     }
/*  677 */     initColumnGroups();
/*      */ 
/*  679 */     setDigitFormat();
/*      */ 
/*  681 */     getReportBase().setShowNO(true);
/*      */   }
/*      */ 
/*      */   private void setVeriSplitEnabled(boolean enabled)
/*      */   {
/*  689 */     if (enabled) {
/*  690 */       this.veriSplitPane.setLeftComponent(getGroupPanel());
/*  691 */       this.veriSplitPane.setDividerLocation(200);
/*  692 */       this.veriSplitPane.setEnabled(true);
/*  693 */       this.veriSplitPane.setDividerSize(15);
/*  694 */       this.veriSplitPane.setOneTouchExpandable(true);
/*  695 */       getReportBase().setShowNO(true);
/*      */     } else {
/*  697 */       this.veriSplitPane.setLeftComponent(null);
/*  698 */       this.veriSplitPane.setDividerLocation(0);
/*  699 */       this.veriSplitPane.setEnabled(false);
/*  700 */       this.veriSplitPane.setDividerSize(0);
/*  701 */       this.veriSplitPane.setOneTouchExpandable(false);
/*  702 */       getReportBase().setShowNO(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void onButtonClicked(ButtonObject bo)
/*      */   {
/*      */     try
/*      */     {
/*  713 */       if (this.button_action_map.get(bo) != null) {
/*  714 */         IButtonActionAndState action = (IButtonActionAndState)this.button_action_map.get(bo);
/*      */ 
/*  716 */         action.execute();
/*      */       }
/*      */     } catch (BusinessException ex) {
/*  719 */       showErrorMessage(ex.getMessage());
/*  720 */       Logger.error(ex.getMessage(), ex);
/*      */     } catch (Exception e) {
/*  722 */       Logger.error(e.getMessage(), e);
/*      */     }
/*      */ 
/*  725 */     updateAllButtons();
/*      */   }
/*      */ 
/*      */   protected void onSort(String[] fields, int[] asc)
/*      */   {
/*  732 */     CircularlyAccessibleValueObject[] vos = null;
/*  733 */     if ((vos = getCurrentVO()) == null)
/*  734 */       return;
/*  735 */     getReportBase().getReportSortUtil().multiSort(vos, fields, asc);
/*  736 */     setBodyDataVO(vos, false);
/*      */   }
/*      */ 
/*      */   private CircularlyAccessibleValueObject[] getCurrentVOFromGroupMap() {
/*  740 */     if (this.groupKeys.size() == 0)
/*  741 */       return null;
/*  742 */     int selectedRow = 0;
/*  743 */     if (getGroupTable().getSelectedRow() != -1)
/*  744 */       selectedRow = getGroupTable().getSelectedRow();
/*  745 */     String[] keys = getValuesFromGroupTable(selectedRow);
/*  746 */     String key = "";
/*  747 */     for (int i = 0; i < keys.length; i++) {
/*  748 */       key = key + keys[i];
/*  749 */       if (i != keys.length - 1)
/*  750 */         key = key + ":";
/*      */     }
/*  752 */     return this.groupMap.get(key) == null ? null : (CircularlyAccessibleValueObject[])((ArrayList)this.groupMap.get(key)).toArray(new CircularlyAccessibleValueObject[0]);
/*      */   }
/*      */ 
/*      */   protected void onPrintTemplet()
/*      */   {
/*  762 */     getReportBase().printData();
/*      */   }
/*      */ 
/*      */   protected void updateAllButtons()
/*      */   {
/*  769 */     boolean hasData = false;
/*  770 */     BillModel bm = this.m_report.getBillModel();
/*  771 */     if ((bm != null) && ((bm.getDataVector() == null) || (bm.getDataVector().size() == 0)))
/*      */     {
/*  773 */       hasData = false;
/*      */     }
/*  775 */     else hasData = true;
/*      */ 
/*  777 */     setButtons(getAllBtnAry());
/*  778 */     setAllButtonState(hasData);
/*  779 */     updateButtons();
/*      */   }
/*      */ 
/*      */   protected ReportModelVO[] getModelVOs()
/*      */   {
/*  789 */     return this.copyOfReportModelVOs;
/*      */   }
/*      */ 
/*      */   private void setAllButtonState(boolean hasData)
/*      */   {
/*  798 */     Iterator it = this.button_action_map.keySet().iterator();
/*  799 */     while (it.hasNext()) {
/*  800 */       ButtonObject obj = (ButtonObject)it.next();
/*  801 */       IButtonActionAndState state = (IButtonActionAndState)this.button_action_map.get(obj);
/*      */ 
/*  803 */       int result = state.isButtonAvailable();
/*  804 */       if (result == 0)
/*  805 */         obj.setEnabled(false);
/*  806 */       else if (result == 1)
/*  807 */         obj.setEnabled(true);
/*  808 */       else if (result == 2)
/*  809 */         obj.setEnabled(true);
/*  810 */       else if (result == 3)
/*  811 */         if (hasData)
/*  812 */           obj.setEnabled(true);
/*      */         else
/*  814 */           obj.setEnabled(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void onFilter(String strFomula)
/*      */     throws Exception
/*      */   {
/*  824 */     getReportBase().filter(strFomula);
/*      */   }
/*      */ 
/*      */   protected void onCross(String[] rows, String[] cols, String[] values)
/*      */     throws Exception
/*      */   {
/*  840 */     getReportBase().drawCrossTable(rows, cols, values);
/*      */   }
/*      */ 
/*      */   protected void onColumnFilter(String title, String[] fieldNames, String[] showNames, boolean isAdjustOrder)
/*      */     throws Exception
/*      */   {
/*  856 */     CircularlyAccessibleValueObject[] vos = getBodyDataVO();
/*  857 */     getReportBase().hideColumn(getAllColumnCodes());
/*      */ 
/*  860 */     getReportBase().setReportTitle(title);
/*      */ 
/*  862 */     setTitleText(title);
/*  863 */     getReportBase().showHiddenColumn(fieldNames);
/*  864 */     if (isAdjustOrder)
/*  865 */       setColumnOrder(fieldNames);
/*  866 */     if ((showNames != null) && (showNames.length == fieldNames.length))
/*  867 */       setColumnName(fieldNames, showNames);
/*  868 */     setBodyDataVO(vos, true);
/*      */   }
/*      */ 
/*      */   private void setColumnName(String[] fieldNames, String[] showNames)
/*      */   {
/*  878 */     ReportItem[] items = getReportBase().getBody_Items();
/*  879 */     HashMap tmpHas = new HashMap();
/*  880 */     for (int i = 0; i < items.length; i++) {
/*  881 */       tmpHas.put(items[i].getKey(), items[i]);
/*      */     }
/*      */ 
/*  884 */     for (int i = 0; i < fieldNames.length; i++) {
/*  885 */       if (tmpHas.containsKey(fieldNames[i])) {
/*  886 */         ReportItem tmpItem = (ReportItem)tmpHas.get(fieldNames[i]);
/*  887 */         if (!tmpItem.getName().equals(showNames[i])) {
/*  888 */           tmpItem.setName(showNames[i]);
/*      */         }
/*      */       }
/*      */     }
/*  892 */     getReportBase().setBody_Items(items);
/*      */   }
/*      */ 
/*      */   public void onPrintDirect()
/*      */     throws Exception
/*      */   {
/*  901 */     PrintDirectEntry print = PrintManager.getDirectPrinter(getReportBase().getBillTable(), getReportBase().getHead_Items());
/*      */ 
/*  903 */     print.setTitle(getTitle());
/*  904 */     print.preview();
/*      */   }
/*      */ 
/*      */   public void onPrintPreview()
/*      */     throws Exception
/*      */   {
/*  913 */     getReportBase().previewData();
/*      */   }
/*      */ 
/*      */   protected abstract void onQuery()
/*      */     throws Exception;
/*      */ 
/*      */   protected void onRefresh()
/*      */     throws Exception
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void onSubTotal(SubtotalContext context)
/*      */     throws Exception
/*      */   {
/*  931 */     getReportBase().setSubtotalContext(context);
/*  932 */     getReportBase().subtotal();
/*      */   }
/*      */ 
/*      */   protected void onGroup(String[] keys)
/*      */   {
/*  943 */     String[] colNames = getColumnNamesByKeys(convertVOKeysToModelKeys(keys));
/*  944 */     onGroup(keys, colNames);
/*      */   }
/*      */ 
/*      */   protected void onGroup(String[] keys, String[] names)
/*      */   {
/*  954 */     String[] convertGroupKeys = convertVOKeysToModelKeys((String[])this.groupKeys.toArray(new String[0]));
/*      */ 
/*  957 */     getReportBase().showHiddenColumn(convertGroupKeys);
/*      */ 
/*  959 */     removeHeadItems(convertGroupKeys);
/*      */ 
/*  961 */     this.groupKeys.clear();
/*      */ 
/*  963 */     if ((keys == null) || (names == null) || (keys.length == 0) || (names.length == 0) || (keys.length != names.length))
/*      */     {
/*  965 */       setVeriSplitEnabled(false);
/*      */ 
/*  967 */       setBodyDataVO(this.allBodyDataVO, false);
/*  968 */       return;
/*      */     }
/*      */ 
/*  971 */     this.groupKeys.addAll(Arrays.asList(keys));
/*      */ 
/*  973 */     setVeriSplitEnabled(true);
/*      */ 
/*  975 */     if ((this.allBodyDataVO == null) || (this.allBodyDataVO.length == 0)) {
/*  976 */       this.allBodyDataVO = getVOFromUI();
/*      */     }
/*  978 */     this.groupMap.clear();
/*      */ 
/*  980 */     for (int i = 0; i < this.allBodyDataVO.length; i++) {
/*  981 */       StringBuffer key = new StringBuffer();
/*  982 */       for (int j = 0; j < keys.length; j++) {
/*  983 */         key.append(this.allBodyDataVO[i].getAttributeValue(keys[j]) == null ? " " : this.allBodyDataVO[i].getAttributeValue(keys[j]).toString());
/*      */ 
/*  987 */         if (j != keys.length - 1)
/*  988 */           key.append(":");
/*      */       }
/*  990 */       addVoToHashmap(key.toString(), this.allBodyDataVO[i]);
/*      */     }
/*  992 */     String[] convertedKeys = convertVOKeysToModelKeys(keys);
/*  993 */     extractItemsToHead(convertedKeys, names);
/*  994 */     getReportBase().hideColumn(convertedKeys);
/*      */ 
/*  996 */     GroupTableModel model = new GroupTableModel();
/*  997 */     model.addColumns(names);
/*  998 */     model.addRows(this.groupMap.keySet());
/*  999 */     getGroupTable().setModel(model);
/*      */ 
/* 1001 */     ArrayList tmpVO = (ArrayList)this.groupMap.get(this.groupMap.keySet().iterator().next());
/*      */ 
/* 1003 */     if ((tmpVO != null) && (tmpVO.size() > 0)) {
/* 1004 */       setBodyDataVO((CircularlyAccessibleValueObject[])tmpVO.toArray(new CircularlyAccessibleValueObject[0]), false);
/*      */ 
/* 1006 */       setHeadItems(convertedKeys, getValuesFromGroupTable(0));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void removeHeadItems(String[] strs)
/*      */   {
/* 1014 */     ReportItem[] headItems = getReportBase().getHead_Items();
/* 1015 */     ArrayList list = new ArrayList();
/* 1016 */     if ((headItems != null) && (headItems.length > 0)) {
/* 1017 */       for (int i = 0; i < headItems.length; i++)
/* 1018 */         if (!contains(strs, headItems[i].getKey()))
/*      */         {
/* 1020 */           list.add(headItems[i]);
/*      */         }
/*      */     }
/* 1023 */     getReportBase().setHead_Items((ReportItem[])list.toArray(new ReportItem[0]));
/*      */   }
/*      */ 
/*      */   private String[] getValuesFromGroupTable(int row)
/*      */   {
/* 1034 */     UITable table = getGroupTable();
/* 1035 */     int count = table.getColumnCount();
/* 1036 */     String[] str = new String[count];
/* 1037 */     for (int i = 0; i < str.length; i++) {
/* 1038 */       str[i] = ((String)table.getModel().getValueAt(row, i));
/*      */     }
/* 1040 */     return str;
/*      */   }
/*      */ 
/*      */   private void extractItemsToHead(String[] keys, String[] colNames)
/*      */   {
/* 1052 */     String[] convertKeys = convertVOKeysToModelKeys(keys);
/* 1053 */     ReportItem[] items = new ReportItem[keys.length];
/* 1054 */     for (int i = 0; i < convertKeys.length; i++) {
/* 1055 */       items[i] = new ReportItem();
/* 1056 */       items[i].setKey(convertKeys[i]);
/* 1057 */       items[i].setShow(true);
/* 1058 */       items[i].setName(colNames[i]);
/*      */     }
/* 1060 */     getReportBase().addHeadItem(items);
/*      */   }
/*      */ 
/*      */   public String[] convertVOKeysToModelKeys(String[] keys)
/*      */   {
/* 1068 */     if ((keys == null) || (keys.length == 0))
/* 1069 */       return null;
/* 1070 */     String[] convertedKeys = new String[keys.length];
/* 1071 */     for (int i = 0; i < keys.length; i++) {
/* 1072 */       convertedKeys[i] = convertVOFieldNameToReportModelFieldName(keys[i]);
/*      */     }
/* 1074 */     return convertedKeys;
/*      */   }
/*      */ 
/*      */   private void setHeadItems(String[] keys, Object[] values)
/*      */   {
/* 1084 */     if ((keys == null) || (values == null) || (keys.length == 0) || (values.length == 0))
/*      */     {
/* 1086 */       return;
/* 1087 */     }if (keys.length != values.length) {
/* 1088 */       System.out.println("閿拰鍊肩殑鏁扮洰涓嶅尮閰�");
/* 1089 */       return;
/*      */     }
/* 1091 */     for (int i = 0; i < keys.length; i++)
/* 1092 */       getReportBase().setHeadItem(keys[i], values[i]);
/*      */   }
/*      */ 
/*      */   protected String[] getColumnNamesByKeys(String[] keys)
/*      */   {
/* 1104 */     if ((keys == null) || (keys.length == 0))
/* 1105 */       return null;
/* 1106 */     ReportModelVO[] fields = getModelVOs();
/*      */ 
/* 1108 */     ArrayList list = new ArrayList();
/* 1109 */     if ((fields != null) && (fields.length != 0)) {
/* 1110 */       for (int i = 0; i < keys.length; i++) {
/* 1111 */         for (int j = 0; j < fields.length; j++) {
/* 1112 */           if (fields[j].getColumnCode().equals(keys[i]))
/* 1113 */             list.add(fields[j].getColumnUser());
/*      */         }
/*      */       }
/*      */     }
/* 1117 */     return (String[])list.toArray(new String[0]);
/*      */   }
/*      */ 
/*      */   protected String getColumnNameByKey(String key)
/*      */   {
/* 1127 */     if (key == null)
/* 1128 */       return null;
/* 1129 */     ReportModelVO[] fields = getModelVOs();
/* 1130 */     if ((fields != null) && (fields.length != 0)) {
/* 1131 */       for (int j = 0; j < fields.length; j++) {
/* 1132 */         if (fields[j].getColumnCode().equals(key))
/* 1133 */           return fields[j].getColumnUser();
/*      */       }
/*      */     }
/* 1136 */     return null;
/*      */   }
/*      */ 
/*      */   private void addVoToHashmap(String key, CircularlyAccessibleValueObject vo)
/*      */   {
/* 1146 */     ArrayList list = null;
/* 1147 */     if ((list = (ArrayList)this.groupMap.get(key)) == null) {
/* 1148 */       list = new ArrayList();
/* 1149 */       list.add(vo);
/* 1150 */       this.groupMap.put(key, list);
/*      */     } else {
/* 1152 */       list.add(vo);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected CircularlyAccessibleValueObject[] processVOs(CircularlyAccessibleValueObject[] vos)
/*      */   {
/* 1165 */     return vos;
/*      */   }
/*      */ 
/*      */   protected void setColumnOrder(String[] column_codes)
/*      */   {
/* 1173 */     ReportItem[] items = getReportBase().getBody_Items();
/*      */ 
/* 1175 */     ArrayList al = new ArrayList();
/* 1176 */     HashMap tmpHas = new HashMap();
/* 1177 */     for (int i = 0; i < items.length; i++) {
/* 1178 */       tmpHas.put(items[i].getKey(), items[i]);
/*      */     }
/*      */ 
/* 1181 */     for (int i = 0; i < column_codes.length; i++) {
/* 1182 */       if (tmpHas.containsKey(column_codes[i])) {
/* 1183 */         al.add(tmpHas.get(column_codes[i]));
/* 1184 */         tmpHas.remove(column_codes[i]);
/*      */       }
/*      */     }
/*      */ 
/* 1188 */     al.addAll(tmpHas.values());
/*      */ 
/* 1190 */     ReportItem[] newitems = (ReportItem[])al.toArray(new ReportItem[0]);
/* 1191 */     getReportBase().setBody_Items(newitems);
/*      */   }
/*      */ 
/*      */   protected void setDigitFormat()
/*      */   {
/* 1199 */     ReportItem[] items = getReportBase().getBody_Items();
/*      */ 
/* 1201 */     for (int i = 0; i < items.length; i++)
/* 1202 */       if ((items[i].getDataType() == 2) || (items[i].getDataType() == 1))
/* 1203 */         items[i].setDecimalDigits(2);
/*      */   }
/*      */ 
/*      */   protected void setPrivateButtons()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void unRegisterButton(ButtonObject obj)
/*      */   {
/* 1220 */     if (obj != null)
/* 1221 */       this.button_action_map.remove(obj);
/*      */   }
/*      */ 
/*      */   protected void registerButton(ButtonObject obj, IButtonActionAndState action)
/*      */   {
/* 1230 */     registerButton(obj, action, -1);
/*      */   }
/*      */ 
/*      */   protected void registerButton(ButtonObject obj, IButtonActionAndState action, int pos)
/*      */   {
/* 1239 */     if ((obj == null) || (action == null)) {
/* 1240 */       System.out.println("按钮或动作为空，不能加入");
/* 1241 */       return;
/*      */     }
/* 1243 */     if (this.button_action_map.get(obj) != null) {
/* 1244 */       System.out.println("按钮已经添加");
/* 1245 */       return;
/*      */     }
/* 1247 */     this.button_action_map.put(obj, action, pos);
/*      */   }
/*      */ 
/*      */   public void showCondition(String[] conditions)
/*      */   {
/* 1258 */     getConditionPanel().removeAll();
/* 1259 */     if ((conditions == null) || (conditions.length == 0)) {
/* 1260 */       return;
/*      */     }
/* 1262 */     String[] temp = conditions;
/* 1263 */     UILabel tmp = new UILabel(temp[0]);
/* 1264 */     FontMetrics metrics = tmp.getFontMetrics(tmp.getFont());
/* 1265 */     int[] widths = new int[conditions.length];
/* 1266 */     for (int i = 0; i < conditions.length; i++) {
/* 1267 */       widths[i] = metrics.stringWidth(conditions[i]);
/*      */     }
/*      */ 
/* 1270 */     Arrays.sort(widths);
/*      */ 
/* 1272 */     int width = widths[(widths.length - 1)];
/* 1273 */     int heigth = metrics.getHeight();
/* 1274 */     for (int i = 0; i < conditions.length; i++) {
/* 1275 */       UILabel l = new UILabel(conditions[i]);
/*      */ 
/* 1277 */       getConditionPanel().add(l);
/* 1278 */       l.setPreferredSize(new Dimension(width, heigth));
/*      */     }
/*      */ 
/* 1281 */     getConditionPanel().invalidate();
/* 1282 */     getConditionPanel().repaint();
/*      */   }
/*      */ 
/*      */   public CircularlyAccessibleValueObject[] getBodyDataVO()
/*      */   {
/* 1291 */     return getReportBase().getBodyDataVO();
/*      */   }
/*      */ 
/*      */   protected void setBodyDataVO(CircularlyAccessibleValueObject[] dataVO, boolean isLoadFormula)
/*      */   {
/* 1302 */     getReportBase().setBodyDataVO(dataVO, isLoadFormula);
/* 1303 */     if (this.needGroup) {
/* 1304 */       this.needGroup = false;
/* 1305 */       onGroup(getUIControl().getGroupKeys());
/*      */     }
/* 1307 */     updateAllButtons();
/*      */   }
/*      */ 
/*      */   protected TableField[] getVisibleFieldsByDataType(Integer type)
/*      */   {
/* 1317 */     TableField[] visibleFields = getVisibleFields();
/* 1318 */     ArrayList al = new ArrayList();
/* 1319 */     ReportModelVO[] vos = getModelVOs();
/* 1320 */     for (int i = 0; i < vos.length; i++) {
/* 1321 */       if (vos[i].getDataType().equals(type)) {
/* 1322 */         TableField f = createTableFieldFromReportModelVO(vos[i]);
/* 1323 */         if (Arrays.asList(visibleFields).contains(f)) {
/* 1324 */           al.add(f);
/*      */         }
/*      */       }
/*      */     }
/* 1328 */     return (TableField[])al.toArray(new TableField[0]);
/*      */   }
/*      */ 
/*      */   protected ArrayList getGroupKeys()
/*      */   {
/* 1335 */     return this.groupKeys;
/*      */   }
/*      */ 
/*      */   public boolean contains(String[] source, String element) {
/* 1339 */     if (source != null) {
/* 1340 */       for (int i = 0; i < source.length; i++) {
/* 1341 */         if (source[i].equals(element))
/* 1342 */           return true;
/*      */       }
/*      */     }
/* 1345 */     return false;
/*      */   }
/*      */ 
/*      */   private UISplitPane getVeriSplitPane()
/*      */   {
/* 1352 */     if (this.veriSplitPane == null)
/*      */     {
/* 1354 */       this.veriSplitPane = new UISplitPane(1, false, null, getReportBase());
/*      */ 
/* 1357 */       setVeriSplitEnabled(false);
/*      */     }
/* 1359 */     return this.veriSplitPane;
/*      */   }
/*      */ 
/*      */   private UIScrollPane getGroupPanel() {
/* 1363 */     if (this.groupSPane == null) {
/* 1364 */       this.groupSPane = new UIScrollPane();
/* 1365 */       this.groupSPane.setViewportView(getGroupTable());
/*      */     }
/* 1367 */     return this.groupSPane;
/*      */   }
/*      */ }