/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public class EmptyAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public EmptyAction(ReportUIBase reportUIBase)
/*    */   {
/* 18 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public EmptyAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }