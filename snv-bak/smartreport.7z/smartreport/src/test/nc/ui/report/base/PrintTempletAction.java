/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public class PrintTempletAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public PrintTempletAction(ReportUIBase reportUIBase)
/*    */   {
/* 18 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public PrintTempletAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 35 */     getReportUIBase().onPrintTemplet();
/*    */   }
/*    */ }