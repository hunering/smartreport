package nc.ui.report.base;

import nc.vo.trade.report.TableField;

public abstract interface ISubTotalConf
{
  public abstract TableField[] getSubTotalCandidateGroupFields();

  public abstract TableField[] getSubTotalCandidateTotalFields();

  public abstract TableField[] getSubTotalCurrentUsingGroupFields();

  public abstract TableField[] getSubTotalCurrentUsingTotalFields();
}