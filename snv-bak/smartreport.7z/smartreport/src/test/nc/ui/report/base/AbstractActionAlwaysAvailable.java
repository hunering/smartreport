/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public abstract class AbstractActionAlwaysAvailable
/*    */   implements IButtonActionAndState
/*    */ {
/* 17 */   ReportUIBase reportUIBase = null;
/*    */ 
/*    */   public AbstractActionAlwaysAvailable(ReportUIBase reportUIBase)
/*    */   {
/* 21 */     this.reportUIBase = reportUIBase;
/*    */   }
/*    */ 
/*    */   public AbstractActionAlwaysAvailable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public int isButtonAvailable()
/*    */   {
/* 33 */     return 2;
/*    */   }
/*    */ 
/*    */   public ReportUIBase getReportUIBase()
/*    */   {
/* 41 */     return this.reportUIBase;
/*    */   }
/*    */ 
/*    */   public void setReportUIBase(ReportUIBase reportUIBase)
/*    */   {
/* 50 */     this.reportUIBase = reportUIBase;
/*    */   }
/*    */ }