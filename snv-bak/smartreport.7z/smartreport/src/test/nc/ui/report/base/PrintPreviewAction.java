/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public class PrintPreviewAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public PrintPreviewAction(ReportUIBase reportUIBase)
/*    */   {
/* 22 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public PrintPreviewAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 40 */     getReportUIBase().onPrintPreview();
/*    */   }
/*    */ }