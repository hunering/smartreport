/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public abstract class AbstractActionHasDataAvailable
/*    */   implements IButtonActionAndState
/*    */ {
/* 17 */   ReportUIBase reportUIBase = null;
/*    */ 
/*    */   public AbstractActionHasDataAvailable(ReportUIBase reportUIBase)
/*    */   {
/* 21 */     this.reportUIBase = reportUIBase;
/*    */   }
/*    */ 
/*    */   public AbstractActionHasDataAvailable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public int isButtonAvailable()
/*    */   {
/* 33 */     return 3;
/*    */   }
/*    */ 
/*    */   public ReportUIBase getReportUIBase()
/*    */   {
/* 41 */     return this.reportUIBase;
/*    */   }
/*    */ 
/*    */   public void setReportUIBase(ReportUIBase reportUIBase)
/*    */   {
/* 50 */     this.reportUIBase = reportUIBase;
/*    */   }
/*    */ }