/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public class PrintDirectAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public PrintDirectAction(ReportUIBase reportUIBase)
/*    */   {
/* 20 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public PrintDirectAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 38 */     getReportUIBase().onPrintDirect();
/*    */   }
/*    */ }