/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public class TotalQueryInfoAction extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public TotalQueryInfoAction(ReportUIBase reportUIBase)
/*    */   {
/* 22 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public TotalQueryInfoAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }