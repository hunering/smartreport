/*     */ package nc.ui.report.base;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Vector;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.bill.BillModel;
/*     */ import nc.ui.pub.report.CodeLevelSubtotalTool;
/*     */ import nc.ui.pub.report.ReportBaseClass;
/*     */ import nc.ui.pub.report.ReportGeneralUtil;
/*     */ import nc.ui.pub.report.ReportInfoCtrl;
/*     */ import nc.ui.trade.report.levelsubtotal.CodeLevelSubtotalDLG;
/*     */ import nc.ui.trade.report.levelsubtotal.CodeLevelSubtotalDescription;
/*     */ import nc.vo.pub.report.CodeLevelResultSetContext;
/*     */ import nc.vo.pub.rs.MemoryResultSet;
/*     */ import nc.vo.pub.rs.MemoryResultSetMetaData;
/*     */ import nc.vo.trade.report.IReportModelDataTypes;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class CodeLevelSubtotalAction extends AbstractActionHasDataAvailable
/*     */ {
/*  30 */   private static final String TOTAL_SIGN = NCLangRes.getInstance().getStrByID("common", "UC000-0001146");
/*     */ 
/*     */   public CodeLevelSubtotalAction(ReportUIBase reportUIBase)
/*     */   {
/*  36 */     super(reportUIBase);
/*     */   }
/*     */ 
/*     */   public CodeLevelSubtotalAction()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void execute()
/*     */     throws Exception
/*     */   {
/*  54 */     CodeLevelSubtotalDLG dlg = new CodeLevelSubtotalDLG(getReportUIBase(), getAllCols(), getSumCols(), null);
/*     */ 
/*  56 */     if (dlg.showModal() == 1)
/*     */     {
/*  58 */       CodeLevelSubtotalDescription desc = dlg.getResultDesc();
/*  59 */       CodeLevelResultSetContext clc = new CodeLevelResultSetContext();
/*  60 */       clc.setCols(make2Wei(getReportUIBase().convertVOKeysToModelKeys(desc.getSumCols())));
/*  61 */       if (desc.getGroupCol() != null)
/*  62 */         clc.setGrpItem(getReportUIBase().convertVOFieldNameToReportModelFieldName(desc.getGroupCol()));
/*  63 */       if ((desc.getFilterFormula() != null) && (!desc.getFilterFormula().equals("")))
/*  64 */         clc.setFilter(desc.getFilterFormula());
/*  65 */       clc.setLevelCol(getReportUIBase().convertVOFieldNameToReportModelFieldName(desc.getLevelCol()));
/*  66 */       clc.setLevelMode(desc.getLevelMode());
/*  67 */       clc.setTopLevel(desc.getBeginLevel());
/*  68 */       clc.setBottomLevel(desc.getEndLevel());
/*  69 */       clc.setIsLevelDown(desc.isSumColUp());
/*  70 */       System.out.println(clc.getGrpItem());
/*  71 */       System.out.println(clc.getLevelCol());
/*  72 */       for (int i = 0; i < desc.getSumCols().length; i++)
/*  73 */         System.out.println(clc.getCols()[i]);
/*  74 */       codeLevelSubtotal(clc);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void codeLevelSubtotal(CodeLevelResultSetContext clc)
/*     */   {
/*  82 */     MemoryResultSetMetaData mrsmd = getBaseClass().getReportGeneralUtil().createMeteData();
/*     */ 
/*  84 */     Vector dataVec = getBaseClass().getBillModel().getDataVector();
/*  85 */     getBaseClass().getReportInfoCtrl().setMrs(getBaseClass().getReportGeneralUtil().vector2Mrs(dataVec, mrsmd));
/*     */     try
/*     */     {
/*  88 */       CodeLevelSubtotalTool clst = new CodeLevelSubtotalTool();
/*  89 */       MemoryResultSet mrsTemp = clst.calcLevelSubtotal(getBaseClass().getReportInfoCtrl().getMrs(), clc);
/*     */ 
/*  91 */       dataVec = getBaseClass().getReportGeneralUtil().mrs2Vector(mrsTemp);
/*     */ 
/*  93 */       int iLen = ((Vector)dataVec.get(0)).size();
/*  94 */       for (int i = 0; i < dataVec.size(); i++)
/*  95 */         ((Vector)dataVec.get(i)).remove(iLen - 1);
/*  96 */       Vector vecToMod = null;
/*  97 */       if (clc.isLevelDown())
/*  98 */         vecToMod = (Vector)dataVec.get(dataVec.size() - 1);
/*     */       else
/* 100 */         vecToMod = (Vector)dataVec.get(0);
/* 101 */       for (int i = 0; i < iLen - 1; i++)
/*     */       {
/* 104 */         if (vecToMod.get(i).equals("@@"))
/*     */         {
/* 106 */           vecToMod.set(i, TOTAL_SIGN);
/* 107 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 111 */       getBaseClass().getBillModel().setDataVector(dataVec);
/*     */     }
/*     */     catch (Exception e) {
/* 114 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private ReportBaseClass getBaseClass()
/*     */   {
/* 122 */     return getReportUIBase().getReportBase();
/*     */   }
/*     */ 
/*     */   private String[][] make2Wei(String[] cols)
/*     */   {
/* 127 */     String[][] result = new String[cols.length][2];
/* 128 */     for (int i = 0; i < cols.length; i++)
/*     */     {
/* 130 */       result[i][0] = cols[i];
/* 131 */       result[i][1] = cols[i];
/*     */     }
/* 133 */     return result;
/*     */   }
/*     */ 
/*     */   private TableField[] getAllCols()
/*     */   {
/* 138 */     return getReportUIBase().getVisibleFields();
/*     */   }
/*     */ 
/*     */   private TableField[] getSumCols()
/*     */   {
/* 144 */     TableField[] f = getReportUIBase().getVisibleFieldsByDataType(IReportModelDataTypes.FLOAT);
/* 145 */     TableField[] i = getReportUIBase().getVisibleFieldsByDataType(IReportModelDataTypes.INTEGER);
/* 146 */     ArrayList al = new ArrayList();
/* 147 */     al.addAll(Arrays.asList(f));
/* 148 */     al.addAll(Arrays.asList(i));
/* 149 */     return (TableField[])al.toArray(new TableField[0]);
/*     */   }
/*     */ }