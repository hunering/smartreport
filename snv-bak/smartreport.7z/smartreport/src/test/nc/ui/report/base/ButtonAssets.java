/*     */ package nc.ui.report.base;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.ButtonObject;
/*     */ 
/*     */ public class ButtonAssets extends HashMap
/*     */ {
/*  20 */   ReportUIBase reportUIBase = null;
/*     */ 
/*  23 */   ArrayList buttonListByOrder = new ArrayList();
/*     */ 
/*  25 */   public static final ButtonObject m_boQuery = new ButtonObject(NCLangRes.getInstance().getStrByID("common", "UC001-0000006"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000000"), 0, "æŸ¥è¯¢");
/*     */ 
/*  30 */   public static final ButtonObject m_boPrintPreview = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000001"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000001"), 0, "æ‰“å�°é¢„è§ˆ");
/*     */ 
/*  35 */   public static final ButtonObject m_boPrintDirect = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000002"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000003"), 0, "ç›´æŽ¥æ‰“å�°");
/*     */ 
/*  39 */   public static final ButtonObject m_boPrintTemplet = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000004"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000003"), 0, "æ¨¡æ�¿æ‰“å�°");
/*     */ 
/*  43 */   public static final ButtonObject m_boPrint = new ButtonObject(NCLangRes.getInstance().getStrByID("common", "UC001-0000007"), new ButtonObject[] { m_boPrintPreview, m_boPrintDirect, m_boPrintTemplet });
/*     */ 
/*  52 */   public static final ButtonObject m_boSort = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000005"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000006"), 0, "æŽ’åº�");
/*     */ 
/*  54 */   public static final ButtonObject m_boLevelSubTotal = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000007"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000007"), 0, "åˆ†çº§å°�è®¡");
/*     */ 
/*  56 */   public static final ButtonObject m_boCodeLevelSubTotal = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000008"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000008"), 0, "ç¼–ç �çº§æ¬¡å°�è®¡");
/*     */ 
/*  58 */   public static final ButtonObject m_boSubTotal = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000009"), new ButtonObject[] { m_boLevelSubTotal, m_boCodeLevelSubTotal });
/*     */ 
/*  62 */   public static final ButtonObject m_boColumnFilter = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000010"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000010"), 0, "æ �ç›®è®¾ç½®");
/*     */ 
/*  67 */   public static final ButtonObject m_boCross = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000011"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000011"), 0, "äº¤å�‰è®¾ç½®");
/*     */ 
/*  70 */   public static final ButtonObject m_boFilter = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000012"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000012"), 0, "è¿‡æ»¤");
/*     */ 
/*  73 */   public static final ButtonObject m_boRefresh = new ButtonObject(NCLangRes.getInstance().getStrByID("common", "UC001-0000009"), NCLangRes.getInstance().getStrByID("common", "UC001-0000009"), 0, "åˆ·æ–°");
/*     */ 
/*  76 */   public static final ButtonObject m_boGroup = new ButtonObject(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000013"), NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000014"), 0, "åˆ†ç»„æ˜¾ç¤º");
/*     */ 
/*  79 */   protected IButtonActionAndState a_filter = null;
/*     */ 
/*  81 */   protected IButtonActionAndState a_cross = null;
/*     */ 
/*  83 */   protected IButtonActionAndState a_columnFilter = null;
/*     */ 
/*  85 */   protected IButtonActionAndState a_query = null;
/*     */ 
/*  87 */   protected IButtonActionAndState a_printPreview = null;
/*     */ 
/*  89 */   protected IButtonActionAndState a_printDirect = null;
/*     */ 
/*  91 */   protected IButtonActionAndState a_printTemplet = null;
/*     */ 
/*  94 */   protected IButtonActionAndState a_sort = null;
/*     */ 
/*  96 */   protected IButtonActionAndState a_levelSubTotal = null;
/*     */ 
/*  98 */   protected IButtonActionAndState a_nextPage = null;
/*     */ 
/* 100 */   protected IButtonActionAndState a_beforePage = null;
/*     */ 
/* 102 */   protected IButtonActionAndState a_firstPage = null;
/*     */ 
/* 104 */   protected IButtonActionAndState a_lastPage = null;
/*     */ 
/* 106 */   protected IButtonActionAndState a_refresh = null;
/*     */ 
/* 108 */   protected IButtonActionAndState a_codeLevelSubtotal = null;
/*     */ 
/* 110 */   protected IButtonActionAndState a_group = null;
/*     */ 
/*     */   public ButtonAssets(ReportUIBase reportUIBase)
/*     */   {
/* 115 */     this.reportUIBase = reportUIBase;
/* 116 */     initAllActions();
/* 117 */     initButtonActionMap();
/*     */   }
/*     */ 
/*     */   private void initButtonActionMap()
/*     */   {
/* 125 */     put(m_boQuery, this.a_query);
/*     */ 
/* 127 */     put(m_boRefresh, this.a_refresh);
/* 128 */     put(m_boCross, this.a_cross);
/* 129 */     put(m_boColumnFilter, this.a_columnFilter);
/* 130 */     put(m_boLevelSubTotal, this.a_levelSubTotal);
/* 131 */     put(m_boCodeLevelSubTotal, this.a_codeLevelSubtotal);
/* 132 */     put(m_boSubTotal, new EmptyAction());
/* 133 */     put(m_boFilter, this.a_filter);
/* 134 */     put(m_boGroup, this.a_group);
/* 135 */     put(m_boSort, this.a_sort);
/* 136 */     put(m_boPrintPreview, this.a_printPreview);
/* 137 */     put(m_boPrintDirect, this.a_printDirect);
/* 138 */     put(m_boPrintTemplet, this.a_printTemplet);
/* 139 */     put(m_boPrint, new EmptyAction());
/*     */   }
/*     */ 
/*     */   private void initAllActions()
/*     */   {
/* 148 */     this.a_filter = new FilterAction(this.reportUIBase);
/* 149 */     this.a_cross = new CrossAction(this.reportUIBase);
/* 150 */     this.a_columnFilter = new ColumnFilterAction(this.reportUIBase);
/* 151 */     this.a_query = new QueryAction(this.reportUIBase);
/* 152 */     this.a_printPreview = new PrintPreviewAction(this.reportUIBase);
/* 153 */     this.a_printDirect = new PrintDirectAction(this.reportUIBase);
/* 154 */     this.a_printTemplet = new PrintTempletAction(this.reportUIBase);
/*     */ 
/* 156 */     this.a_sort = new SortAction(this.reportUIBase);
/* 157 */     this.a_levelSubTotal = new LevelSubTotalAction(this.reportUIBase);
/* 158 */     this.a_refresh = new RefreshAction(this.reportUIBase);
/* 159 */     this.a_codeLevelSubtotal = new CodeLevelSubtotalAction(this.reportUIBase);
/* 160 */     this.a_group = new GroupAction(this.reportUIBase);
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 170 */     return put(key, value, -1);
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value, int pos)
/*     */   {
/* 186 */     if ((key == null) || (value == null))
/* 187 */       return null;
/* 188 */     if ((pos == -1) && (!isChild((ButtonObject)key)))
/* 189 */       this.buttonListByOrder.add(key);
/* 190 */     else if (!isChild((ButtonObject)key))
/* 191 */       this.buttonListByOrder.add(pos, key);
/* 192 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 202 */     this.buttonListByOrder.clear();
/* 203 */     super.clear();
/*     */   }
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 214 */     if (isChild((ButtonObject)key))
/*     */     {
/* 216 */       ((ButtonObject)key).getParent().removeChildButton((ButtonObject)key);
/*     */     }
/* 219 */     else if (((ButtonObject)key).getChildCount() > 0)
/*     */     {
/* 221 */       this.buttonListByOrder.remove(key);
/* 222 */       ButtonObject[] btnObjs = ((ButtonObject)key).getChildButtonGroup();
/* 223 */       for (int i = 0; i < btnObjs.length; i++)
/*     */       {
/* 225 */         super.remove(btnObjs[i]);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 230 */       this.buttonListByOrder.remove(key);
/*     */     }
/* 232 */     return super.remove(key);
/*     */   }
/*     */ 
/*     */   private boolean isChild(ButtonObject o)
/*     */   {
/* 238 */     return o.getParent() != null;
/*     */   }
/*     */ 
/*     */   public ArrayList getVisibleButtonsByOrder()
/*     */   {
/* 246 */     return this.buttonListByOrder;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  47 */     m_boPrint.setCode("打印");
/*     */   }
/*     */ }