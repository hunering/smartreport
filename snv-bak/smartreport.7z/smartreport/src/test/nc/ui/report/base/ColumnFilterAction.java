/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import nc.ui.trade.report.columnfilter.ColumnFilterDLG;
/*    */ import nc.vo.trade.report.TableField;
/*    */ 
/*    */ public class ColumnFilterAction extends AbstractActionAlwaysAvailable
/*    */ {
/*    */   public ColumnFilterAction(ReportUIBase reportUIBase)
/*    */   {
/* 26 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public ColumnFilterAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 44 */     ColumnFilterDLG columnFilterDlg = new ColumnFilterDLG(getReportUIBase(), getReportUIBase().getInvisibleFields(), getReportUIBase().getVisibleFields(), getReportUIBase().getTitle());
/*    */ 
/* 47 */     if (columnFilterDlg.showModal() == 1)
/*    */     {
/* 49 */       String[] trueNames = new String[columnFilterDlg.getVisibleField().length];
/*    */ 
/* 51 */       String[] showNames = new String[columnFilterDlg.getVisibleField().length];
/*    */ 
/* 53 */       for (int i = 0; i < trueNames.length; i++)
/*    */       {
/* 55 */         trueNames[i] = columnFilterDlg.getVisibleField()[i].getFieldName();
/*    */ 
/* 57 */         trueNames[i] = trueNames[i].replace('.', '_');
/* 58 */         showNames[i] = columnFilterDlg.getVisibleField()[i].getFieldShowName();
/*    */       }
/*    */ 
/* 61 */       getReportUIBase().onColumnFilter(columnFilterDlg.getTitle(), trueNames, showNames, columnFilterDlg.isAdjustOrder());
/*    */     }
/*    */   }
/*    */ }