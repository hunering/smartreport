/*     */ package nc.ui.report.base;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import nc.bs.logging.Logger;
/*     */ import nc.ui.ml.NCLangRes;
/*     */ import nc.ui.pub.report.ReportBaseClass;
/*     */ import nc.ui.trade.report.subtotal.SubTotalConfDLG;
/*     */ import nc.vo.pub.BusinessException;
/*     */ import nc.vo.pub.report.SubtotalContext;
/*     */ import nc.vo.trade.report.IReportModelDataTypes;
/*     */ import nc.vo.trade.report.TableField;
/*     */ 
/*     */ public class LevelSubTotalAction extends AbstractActionHasDataAvailable
/*     */   implements ISubTotalConf
/*     */ {
/*  29 */   private TableField[] subTotalCurrentUsingGroupFields = new TableField[0];
/*     */ 
/*  32 */   private TableField[] SubTotalCurrentUsingTotalFields = new TableField[0];
/*     */ 
/*     */   public LevelSubTotalAction(ReportUIBase reportUIBase)
/*     */   {
/*  39 */     super(reportUIBase);
/*     */   }
/*     */ 
/*     */   public LevelSubTotalAction()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void execute()
/*     */     throws Exception
/*     */   {
/*  57 */     SubTotalConfDLG dlg = new SubTotalConfDLG(getReportUIBase(), this);
/*  58 */     if (dlg.showModal() == 1)
/*     */     {
/*  60 */       setSubTotalCurrentUsingGroupFields(dlg.getGroupFields());
/*  61 */       setSubTotalCurrentUsingTotalFields(dlg.getTotalFields());
/*     */ 
/*  63 */       if ((getReportUIBase().getBodyDataVO() == null) || (getReportUIBase().getBodyDataVO().length == 0))
/*     */       {
/*  66 */         Logger.debug("报表中没有数据，小计合计操作取消");
/*  67 */         return;
/*     */       }
/*  69 */       if ((getSubTotalCurrentUsingGroupFields() == null) || (getSubTotalCurrentUsingGroupFields().length == 0) || (getSubTotalCurrentUsingTotalFields() == null) || (getSubTotalCurrentUsingTotalFields().length == 0))
/*     */       {
/*  73 */         throw new BusinessException(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000019"));
/*     */       }
/*  75 */       if ((getSubTotalCurrentUsingGroupFields() != null) && (getSubTotalCurrentUsingGroupFields().length != 0) && (getSubTotalCurrentUsingTotalFields() != null) && (getSubTotalCurrentUsingTotalFields().length != 0))
/*     */       {
/*  80 */         String[] gfs = new String[getSubTotalCurrentUsingGroupFields().length];
/*  81 */         for (int i = 0; i < gfs.length; i++)
/*     */         {
/*  83 */           gfs[i] = getSubTotalCurrentUsingGroupFields()[i].getFieldName();
/*     */ 
/*  85 */           gfs[i] = gfs[i].replace('.', '_');
/*     */         }
/*  87 */         String[] tfs = new String[getSubTotalCurrentUsingTotalFields().length];
/*  88 */         for (int i = 0; i < tfs.length; i++)
/*     */         {
/*  90 */           tfs[i] = getSubTotalCurrentUsingTotalFields()[i].getFieldName();
/*     */ 
/*  92 */           tfs[i] = tfs[i].replace('.', '_');
/*     */         }
/*     */ 
/*  95 */         if (dlg.isLevelCompute())
/*     */         {
/*  97 */           getReportUIBase().getReportBase().multiSubtotal(gfs, tfs);
/*  98 */           getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000020"));
/*     */         }
/*     */         else
/*     */         {
/* 102 */           SubtotalContext context = new SubtotalContext();
/* 103 */           context.setGrpKeys(gfs);
/* 104 */           context.setSubtotalCols(tfs);
/* 105 */           context.setTotalNameColKeys(gfs[0]);
/* 106 */           context.setIsSubtotal(dlg.isSub());
/* 107 */           context.setIsSumtotal(dlg.isSum());
/* 108 */           context.setSubtotalName(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000021"));
/* 109 */           context.setSumtotalName(NCLangRes.getInstance().getStrByID("common", "UC000-0001146"));
/* 110 */           context.setLevelCompute(false);
/* 111 */           getReportUIBase().onSubTotal(context);
/* 112 */           getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000022"));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setSubTotalCurrentUsingGroupFields(TableField[] newSubTotalCurrentUsingGroupFields)
/*     */   {
/* 126 */     this.subTotalCurrentUsingGroupFields = newSubTotalCurrentUsingGroupFields;
/*     */   }
/*     */ 
/*     */   private void setSubTotalCurrentUsingTotalFields(TableField[] newSubTotalCurrentUsingTotalFields)
/*     */   {
/* 137 */     this.SubTotalCurrentUsingTotalFields = newSubTotalCurrentUsingTotalFields;
/*     */   }
/*     */ 
/*     */   public TableField[] getSubTotalCurrentUsingGroupFields()
/*     */   {
/* 146 */     return this.subTotalCurrentUsingGroupFields;
/*     */   }
/*     */ 
/*     */   public TableField[] getSubTotalCurrentUsingTotalFields()
/*     */   {
/* 155 */     return this.SubTotalCurrentUsingTotalFields;
/*     */   }
/*     */ 
/*     */   public TableField[] getSubTotalCandidateGroupFields()
/*     */   {
/* 165 */     return getReportUIBase().getVisibleFieldsByDataType(IReportModelDataTypes.STRING);
/*     */   }
/*     */ 
/*     */   public TableField[] getSubTotalCandidateTotalFields()
/*     */   {
/* 176 */     TableField[] f = getReportUIBase().getVisibleFieldsByDataType(IReportModelDataTypes.FLOAT);
/* 177 */     TableField[] i = getReportUIBase().getVisibleFieldsByDataType(IReportModelDataTypes.INTEGER);
/* 178 */     ArrayList al = new ArrayList();
/* 179 */     al.addAll(Arrays.asList(f));
/* 180 */     al.addAll(Arrays.asList(i));
/* 181 */     return (TableField[])al.toArray(new TableField[0]);
/*     */   }
/*     */ }