/*    */ package nc.ui.report.base;
/*    */ 
/*    */ public class CodeLevelSubTotal extends AbstractActionHasDataAvailable
/*    */ {
/*    */   public CodeLevelSubTotal(ReportUIBase reportUIBase)
/*    */   {
/* 21 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public CodeLevelSubTotal()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }