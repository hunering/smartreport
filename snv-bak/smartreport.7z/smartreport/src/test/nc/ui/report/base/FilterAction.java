/*    */ package nc.ui.report.base;
/*    */ 
/*    */ import nc.ui.ml.NCLangRes;
/*    */ import nc.ui.trade.report.filter.DataSetFilterDlg;
/*    */ 
/*    */ public class FilterAction extends AbstractActionHasDataAvailable
/*    */ {
/* 18 */   DataSetFilterDlg m_filterDlg = null;
/*    */ 
/*    */   public FilterAction(ReportUIBase reportUIBase)
/*    */   {
/* 25 */     super(reportUIBase);
/*    */   }
/*    */ 
/*    */   public FilterAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void execute()
/*    */     throws Exception
/*    */   {
/* 43 */     if (getFilterDLG().showModal() == 1)
/*    */     {
/* 45 */       String strFomula = getFilterDLG().getFomula();
/* 46 */       getReportUIBase().onFilter(strFomula);
/*    */ 
/* 48 */       getReportUIBase().showHintMessage(NCLangRes.getInstance().getStrByID("uifactory_report", "UPPuifactory_report-000017"));
/*    */     }
/*    */   }
/*    */ 
/*    */   private DataSetFilterDlg getFilterDLG()
/*    */   {
/* 57 */     if (this.m_filterDlg == null)
/*    */     {
/* 59 */       this.m_filterDlg = new DataSetFilterDlg(getReportUIBase(), getReportUIBase().getVisibleFields(), getReportUIBase().getAllBodyDataVO());
/*    */     }
/* 61 */     return this.m_filterDlg;
/*    */   }
/*    */ }