/*
 * �������� 2005-7-26
 *
 * TODO Ҫ���Ĵ����ɵ��ļ���ģ�壬��ת��
 * ���� �� ��ѡ�� �� Java �� ������ʽ �� ����ģ��
 */
package nc.ui.pub.report;

import java.util.Comparator;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableColumn;

import nc.bs.logging.Logger;
import nc.ui.pub.beans.table.GroupableTableHeader;
import nc.ui.pub.bill.BillItem;
import nc.ui.pub.bill.BillModel;
import nc.vo.pub.cquery.FldgroupVO;
import nc.vo.pub.report.ReportModelVO;

/**
 * @author dengjt
 *
 * ��Ա���ģ������Ĵ����ࡣ��װ��ģ���������
 */
public class ReportOperatorUtil extends ReportUtil
{

	/**
	 * @param baseClass
	 */
	public ReportOperatorUtil(ReportBaseClass baseClass)
	{
		super(baseClass);
	}
    /**
     * ��̬�ӱ�����
     * @param newItems nc.ui.pub.report.ReportItem[]
     */
    public void addBodyItem(ReportItem[] newItems) {
        if (newItems != null && newItems.length != 0) {
            //ƴװ�±�����
            ReportItem[] oldItems = getBody_Items();
            int iOldLen = (oldItems == null) ? 0 : oldItems.length;
            int maxShowOrder = getMaxShowOrder(oldItems);
            ReportItem[] items = new ReportItem[iOldLen + newItems.length];
            ReportModelVO[] temps = getReportInfoCtrl().getAllBodyVOs();
            getReportInfoCtrl().setAllBodyVOs(new ReportModelVO[iOldLen + newItems.length]);
            ReportModelVO bodyVO = null;
            for (int i = 0; i < iOldLen; i++) {
                items[i] = oldItems[i];
                getReportInfoCtrl().getAllBodyVOs()[i] = temps[i];
            }
            for (int i = 0; i < newItems.length; i++) {
                items[i + iOldLen] = newItems[i];
                //���ò��ɱ༭̬
                items[i + iOldLen].setEdit(false);
                //LYYUAN +
                items[i + iOldLen].setShowOrder(maxShowOrder + i + 1);
                //��¼�����ֶ�ϵͳ��-��������ϣ��
                getReportInfoCtrl().getHashBody().put(newItems[i].getName(), newItems[i].getKey());
                //��¼ȫ��������
                bodyVO = new ReportModelVO();
                bodyVO.setSelectType(new Integer(1));
                bodyVO.setColumnCode(newItems[i].getKey());
                bodyVO.setItemOrder(new Integer(i + iOldLen + 1));
                getReportInfoCtrl().getAllBodyVOs()[i + iOldLen] = bodyVO;
            }

            //���蹫ʽ��Ϣ
            Vector vecFormulae = new Vector();
            for (int i = 0; i < newItems.length; i++) {
                String[] strs = newItems[i].getLoadFormula();
                if (strs != null)
                    for (int j = 0; j < strs.length; j++)
                        vecFormulae.addElement(strs[j]);
            }
            if (vecFormulae.size() == 0) {
                //�����κδ���,��Ϊ��ʽ�����δ�ı�
                //m_strBodyFormulae = null; //�˾����,������Ϊ�¼ӵ���û�й�ʽ�Ͱ�ԭ���еĹ�ʽ���
            }
            else {
                String[] tempOld = getReportInfoCtrl().getBodyFormulae();
                String[] tempNew = new String[vecFormulae.size()];
                vecFormulae.copyInto(tempNew);
                iOldLen = (tempOld == null) ? 0 : tempOld.length;
                int iNewLen = tempNew.length;
                getReportInfoCtrl().setBodyFormulae(new String[iOldLen + iNewLen]);
                if (tempOld != null)
                    System.arraycopy(tempOld, 0, getReportInfoCtrl().getBodyFormulae(), 0, iOldLen);
                System.arraycopy(tempNew, 0, getReportInfoCtrl().getBodyFormulae(), iOldLen,
                        iNewLen);
            }

            Vector data = getBaseClass().getBillModel().getDataVector();
            if (data != null) {
                for (int i = 0; i < data.size(); i++) {
                    Vector row = (Vector) data.get(i);
                    for (int j = 0; j < newItems.length; j++)
                        row.add(null);
                }
            }

            //�����ģ��
            BillModel model = new BillModel();
            model.setBodyItems(items);
            model.setDataVector(data);
            model.execLoadFormula();
            getBaseClass().getBillData().setBillModel(model); //��������model
            getBaseClass().getBodyPanel().setTableModel(model); //���ý���model
            //zjb+
            getBaseClass().getBillData().setBodyItems(items);
            //��ʾ�з���(��ģ�ͱ������趨,��˶��ͷҲҪ����)
            getBaseClass().makeMultiHeader(getBaseClass().getSuperTable());
            //�ı�ģ�ͺ����������к�
            if (getBaseClass().isShowNO() && getReportInfoCtrl().getFldgroups()!= null)
                getBaseClass().setShowNO(getBaseClass().isShowNO());
        }
    }
    
    /**
     * ��̬�ӱ���ͷԪ��
     * @param newItems nc.ui.pub.report.ReportItem[]
     */
    public void addHeadItem(ReportItem[] newItems) {
        if (newItems != null && newItems.length != 0) {
            //ƴװ�±�ͷ��
            ReportItem[] oldItems = getHead_Items();
            int iOldLen = (oldItems == null) ? 0 : oldItems.length;
            ReportItem[] items = new ReportItem[iOldLen + newItems.length];
            for (int i = 0; i < iOldLen; i++)
                items[i] = oldItems[i];
            for (int i = 0; i < newItems.length; i++) {
                items[i + iOldLen] = newItems[i];
                items[i + iOldLen].setLength(500);
            }

            //���蹫ʽ��Ϣ
            Vector vecFormulae = new Vector();
            for (int i = 0; i < newItems.length; i++) {
                String[] strs = newItems[i].getLoadFormula();
                if (strs != null)
                    for (int j = 0; j < strs.length; j++)
                        vecFormulae.addElement(strs[j]);
            }
            if (vecFormulae.size() == 0) {
                //�����κδ���,��Ϊ��ʽ�����δ�ı�
                //m_strHeadFormulae = null; //�˾����,������Ϊ�¼ӵ���û�й�ʽ�Ͱ�ԭ���еĹ�ʽ���
            }
            else {
                String[] tempOld = getReportInfoCtrl().getHeadFormulae();
                String[] tempNew = new String[vecFormulae.size()];
                vecFormulae.copyInto(tempNew);
                iOldLen = (tempOld == null) ? 0 : tempOld.length;
                int iNewLen = tempNew.length;
                getReportInfoCtrl().setHeadFormulae(new String[iOldLen + iNewLen]);
                if (tempOld != null)
                    System.arraycopy(tempOld, 0, getReportInfoCtrl().getHeadFormulae(), 0, iOldLen);
                System.arraycopy(tempNew, 0, getReportInfoCtrl().getHeadFormulae(), iOldLen,
                        iNewLen);
            }

            //�����ͷ
            getBaseClass().getBillData().setHeadItems(items);
            getBaseClass().setSuperBDData(getBaseClass().getBillData());
            getBaseClass().initHeadPanel();

        }
    }

    /**
     * ��̬�ӱ���βԪ��
     * @param newItems nc.ui.pub.report.ReportItem[]
     */
    public void addTailItem(ReportItem[] newItems) {
        if (newItems != null && newItems.length != 0) {
            //ƴװ�±�β��
            ReportItem[] oldItems = getTail_Items();
            int iOldLen = (oldItems == null) ? 0 : oldItems.length;
            ReportItem[] items = new ReportItem[iOldLen + newItems.length];
            for (int i = 0; i < iOldLen; i++)
                items[i] = oldItems[i];
            for (int i = 0; i < newItems.length; i++) {
                items[i + iOldLen] = newItems[i];
                items[i + iOldLen].setLength(500);
            }
            //�����β
            getBaseClass().getBillData().setTailItems(items);
            getBaseClass().setSuperBDData(getBaseClass().getBillData());
            getBaseClass().initTailPanel();
            //�����к�
            //setShowNO(false);
        }
    }
    
    /**
     * ��̬��ʾ������
     * @param key java.lang.String
     */
    public void showHiddenColumn(String[] keys) {
        if (keys == null)
            return;
        for (int i = 0; i < keys.length; i++)
            getBaseClass().showBodyTableCol(keys[i]);
        //�������ͷ
        if (getReportGeneralUtil().getColumnGroups() == null)
            return;
        for (int i = 0; i < keys.length; i++) {
            if (getBaseClass().getBodyColByKey(keys[i]) == -1) {
            	Logger.debug("���޴��С���" + keys[i] + "�޷���ʾ");
                continue;
            }
            //�ع�m_bodyData
            for (int j = 0; j < getReportInfoCtrl().getAllBodyVOs().length; j++)
                if (getReportInfoCtrl().getAllBodyVOs()[j].getColumnCode().equals(keys[i])) {
                	getReportInfoCtrl().getAllBodyVOs()[j].setSelectType(new Integer(1));
                    break;
                }
        }
        //�����������Ŀ
        int iLockCount = getBaseClass().getBodyPanel().getLockCol();
        if (iLockCount != -1)
        	getBaseClass().getBodyPanel().unlockTableCol();
        //�����з���(clearColumnGroups)
        GroupableTableHeader header = (GroupableTableHeader) getBaseClass().getSuperTable()
                .getTableHeader();
        header.clearColumnGroups();
        getBaseClass().getSuperTable().setTableHeader(header);
        //������ʾ�з���
        getReportGeneralUtil().makeMultiHeader(getBaseClass().getSuperTable());
        if (iLockCount != -1)
            getBaseClass().lockColumn(iLockCount);
    }

    /**
     * ��̬��ʾ������
     * @param key java.lang.String
     */
    public void showHiddenColumn(String key) {
        showHiddenColumn(new String[] { key });
    }
    /**
     * ��̬���������(��ReportItem����˳��������������˳��)
     * ��������:(01-7-25 15:57:30)
     * @param items nc.ui.pub.report.ReportItem[]
     */
    public void setBody_Items(ReportItem[] items) {
        //���蹫ʽ��Ϣ
        if (items != null) {
            Vector vecFormulae = new Vector();
            for (int i = 0; i < items.length; i++) {
                items[i].setShowOrder(i);
                String[] strs = items[i].getLoadFormula();
                if (strs != null)
                    for (int j = 0; j < strs.length; j++)
                        vecFormulae.addElement(strs[j]);
            }
            if (vecFormulae.size() == 0)
                getReportInfoCtrl().setBodyFormulae(null);
            else {
            	getReportInfoCtrl().setBodyFormulae(new String[vecFormulae.size()]);
                vecFormulae.copyInto(getReportInfoCtrl().getBodyFormulae());
            }
            getBaseClass().getBodyUIPanel().setVisible(true);
        }
        
        getBaseClass().getBillData().setBodyItems(items);
        // bq �����model�����еļ���,��������ģ��û�䣬֮ǰ�ļ�����Դ�޷��ͷ�
        TableModelListener[] listeners = getBaseClass().getBodyPanel().getTableModel().getListeners(TableModelListener.class);
        for(TableModelListener listener : listeners){
          getBaseClass().getBodyPanel().getTableModel().removeTableModelListener(listener);
        }
        getBaseClass().getBodyPanel().setTableModel(getBaseClass().getBillData().getBillModel()); //���ý���model

        //�ع�ȫ��������
        Hashtable htBodyData = new Hashtable();
        if (getReportInfoCtrl().getAllBodyVOs() != null)
            for (int i = 0; i < getReportInfoCtrl().getAllBodyVOs().length; i++) {
                htBodyData.put(getReportInfoCtrl().getAllBodyVOs()[i].getColumnCode(), getReportInfoCtrl().getAllBodyVOs()[i]);
            }
        Vector bodyData = new Vector();
        getReportInfoCtrl().setHashBody(new Hashtable());
        ReportModelVO bodyVO = null;
        for (int i = 0; i < items.length; i++) {
            //���ò��ɱ༭̬
            items[i].setEdit(false);
            //��¼�����ֶ�ϵͳ��-��������ϣ��
            getReportInfoCtrl().getHashBody().put(items[i].getName(), items[i].getKey());
            //��¼ȫ��������(���ͷ��Ҫ������)
            bodyVO = (ReportModelVO) htBodyData.get(items[i].getKey());
            if (bodyVO == null) {
                bodyVO = new ReportModelVO();
            }
            //lyyuan+
            if (items[i].isShow())
                bodyVO.setSelectType(new Integer(1));
            else
                bodyVO.setSelectType(new Integer(2));
            //bodyVO.setSelectType(new Integer(1));
            bodyVO.setColumnCode(items[i].getKey());
            bodyVO.setDataType(new Integer(items[i].getDataType()));
            bodyVO.setColumnSystem(items[i].getName());
            bodyVO.setColumnUser(items[i].getName());

            bodyVO.setItemOrder(new Integer(i + 1));
            bodyData.addElement(bodyVO);
        }
        getReportInfoCtrl().setAllBodyVOs(new ReportModelVO[bodyData.size()]);
        bodyData.copyInto(getReportInfoCtrl().getAllBodyVOs());
        //��ʾ�з���(��ģ�ͱ������趨,��˶��ͷҲҪ����)
        getReportGeneralUtil().makeMultiHeader(getBaseClass().getSuperTable());
        //�ı�ģ�ͺ����������к�
        if (getBaseClass().isShowNO() && getReportInfoCtrl().getFldgroups() != null)
            getBaseClass().setShowNO(getBaseClass().isShowNO());
    }

    /**
     * ��̬���������(��ReportItem��showOrder˳��������������˳��)
     * ��������:(01-7-25 15:57:30)
     * @param items nc.ui.pub.report.ReportItem[]
     */
    public void setBody_Items0(ReportItem[] items) {
        //����item����
        sortReportItem(items);
        setBody_Items(items);
    }
    
    /**
     * ��̬�����ͷԪ��
     * @param items nc.ui.pub.report.ReportItem[]
     */
    public void setHead_Items(ReportItem[] items) {
        //�����ͷ��ʽ��Ϣ
        if (items != null) {
            Vector vecFormulae = new Vector();
            for (int i = 0; i < items.length; i++) {
                //ͬ����ͷ��ǩ��ʾ�ı�
                if (items[i].getCaptionLabel() != null)
                    items[i].getCaptionLabel().setText(items[i].getName());
                //��¼��ͷ��ʽ
                String[] strs = items[i].getLoadFormula();
                if (strs != null)
                    for (int j = 0; j < strs.length; j++)
                        vecFormulae.addElement(strs[j]);
                items[i].setLength(500);
            }
            if (vecFormulae.size() == 0)
                getReportInfoCtrl().setHeadFormulae(null);
            else {
            	getReportInfoCtrl().setHeadFormulae(new String[vecFormulae.size()]);
                vecFormulae.copyInto(getReportInfoCtrl().getHeadFormulae());
            }
        }
        //�����ͷ
        getBaseClass().getBillData().setHeadItems(items);
        getBaseClass().setSuperBDData(getBaseClass().getBillData());
        getBaseClass().initHeadPanel();
    }
    /**
     * �˴����뷽��˵��.
     * @return nc.ui.pub.report.ReportItem
     * @param key java.lang.String
     */
    public ReportItem getBody_Item(String key) {
        BillItem[] bis = getBaseClass().getBillModel().getBodyItems();
        if (bis == null)
            return null;
        else {
            ReportItem[] riAlls = new ReportItem[bis.length];
            for (int i = 0; i < bis.length; i++)
                riAlls[i] = (ReportItem) bis[i];
            int index = -1;
            for (int i = 0; i < riAlls.length; i++)
                if (riAlls[i].getKey().equals(key)) {
                    index = i;
                    break;
                }
            if (index == -1)
                return null;
            else
                return riAlls[index];
        }
    }

    /**
     * ��ñ�����
     * @param items nc.ui.pub.report.ReportItem[]
     */
    public ReportItem[] getBody_Items() {
        BillItem[] bis = getBaseClass().getBillModel().getBodyItems();
        if (bis == null)
            return null;
        else {
            ReportItem[] ris = new ReportItem[bis.length];
            for (int i = 0; i < bis.length; i++)
                ris[i] = (ReportItem) bis[i];
            return ris;
        }
    }
    /**
     * ��ñ�ͷԪ��
     * @param items nc.ui.pub.report.ReportItem[]
     */
    public ReportItem[] getHead_Items() {
        //return (ReportItem[]) getBillData().getHeadItems();
        BillItem[] bis = getBaseClass().getBillData().getHeadItems();
        if (bis == null)
            return null;
        else {
            ReportItem[] ris = new ReportItem[bis.length];
            for (int i = 0; i < bis.length; i++)
                ris[i] = (ReportItem) bis[i];
            return ris;
        }
    }
    /**
     * �����з���VO����
     * @param fldGroups nc.vo.pub.cquery.FldgroupVO[]
     */
    public void addFieldGroup(FldgroupVO[] newFldGroups) {
        if (newFldGroups == null || newFldGroups.length == 0)
            return;
        //�ϲ��¾��з���VO����
        FldgroupVO[] fldGroups = null;
        int iOldLen = 0;
        if (getReportInfoCtrl().getFldgroups() == null)
            fldGroups = new FldgroupVO[newFldGroups.length];
        else {
            FldgroupVO[] oldGroups = getReportInfoCtrl().getFldgroups();
            iOldLen = oldGroups.length;
            fldGroups = new FldgroupVO[iOldLen + newFldGroups.length];
            System.arraycopy(oldGroups, 0, fldGroups, 0, iOldLen);
        }
        for (int i = 0; i < newFldGroups.length; i++)
            fldGroups[i + iOldLen] = newFldGroups[i];
        //��̬�Ӷ��ͷ
        getReportInfoCtrl().setFldgroups(fldGroups);
        //���÷�����Ϣ
        try {
            getReportGeneralUtil().procFieldGroup();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }
    /**
     * �ı���ͷ����
     * �÷���ֻ�����ڶ����ж��ͷ�Ĵ����޸�(����з�������),������ɾ���ͷ,Ҳ���ܶ�̬�ı���
     * ����,�޸���ת��ͷ�����������,��Ϊ����������һ������Ķ��ͷ(����:0+1��A,A+2��A,�����޸ĵ�һ��Ԫ�ص��з���������Ч��,���޸ĵڶ���Ԫ�ص��з���������Ч��)
     * ��������:(01-7-25 15:51:30)
     * @param fldGroups nc.vo.pub.cquery.FldgroupVO[]
     */
    public void alterFieldGroup(FldgroupVO[] fldGroups) {
        getReportInfoCtrl().setFldgroups(fldGroups);
        //���÷�����Ϣ
        try {
            getReportGeneralUtil().procFieldGroup();
            //�����ģ��
            BillModel model = getBaseClass().getBillModel();
            getBaseClass().getBillData().setBillModel(model); //��������model(������Ч)
            getBaseClass().getBodyPanel().setTableModel(model); //���ý���model
            //��ʾ�з���(��ģ�ͱ������趨,��˶��ͷҲҪ����)
            getReportGeneralUtil().makeMultiHeader(getBaseClass().getSuperTable());
            //�ı�ģ�ͺ����������к�
            if (getBaseClass().isShowNO() && getReportInfoCtrl().getFldgroups() != null)
            	getBaseClass().setShowNO(getBaseClass().isShowNO());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * ��̬����������
     * @param key java.lang.String
     */
    public void hideColumn(String[] keys) {
        if (keys == null)
            return;
        for (int i = 0; i < keys.length; i++)
        	getBaseClass().hideBodyTableCol(keys[i]);
        //�������ͷ
        if (getReportGeneralUtil().getColumnGroups() == null)
            return;
        for (int i = 0; i < keys.length; i++) {
            if (getBaseClass().getBodyColByKey(keys[i]) == -1) {
            	Logger.debug("���޴��С���" + keys[i] + "�޷�����");
                continue;
             }
            //�ع�m_bodyData
            for (int j = 0; j < getReportInfoCtrl().getAllBodyVOs().length; j++)
                if (getReportInfoCtrl().getAllBodyVOs()[j].getColumnCode().equals(keys[i])) {
                	getReportInfoCtrl().getAllBodyVOs()[j].setSelectType(new Integer(2));
                    break;
                }
        }
        //�����������Ŀ
        int iLockCount = getBaseClass().getBodyPanel().getLockCol();
        if (iLockCount != -1)
        	getBaseClass().getBodyPanel().unlockTableCol();
        GroupableTableHeader header = (GroupableTableHeader) getBaseClass().getSuperTable()
                .getTableHeader();
        header.clearColumnGroups();
        getBaseClass().getSuperTable().setTableHeader(header);

        //������ʾ�з���
        getReportGeneralUtil().makeMultiHeader(getBaseClass().getSuperTable());
        if (iLockCount != -1)
        	getBaseClass().lockColumn(iLockCount);
        return;
    }

    /**
     * ��̬����������
     * @param key java.lang.String
     */
    public void hideColumn(String key) {
        hideColumn(new String[] { key });
        return;
    }
    
    /**
     * ��̬�޸�����ʾ��
     * ��������:(01-8-20 11:47:55)
     * @param key java.lang.String
     * @param newName java.lang.String
     */
    public void renameCol(String key, String newName) {
        TableColumn tc = getBaseClass().getBodyPanel().getShowCol(key);
        if (tc == null)
            Logger.debug("���޴��С���" + key);
        else
            tc.setHeaderValue(newName);
        return;
    }
    /**
     * �˴����뷽��˵��.
     * @return int
     * @param items nc.ui.pub.report.ReportItem[]
     */
    private int getMaxShowOrder(ReportItem[] items) {
        int max = 0;
        if (items == null)
            return 0;
        for (int i = 0; i < items.length; i++)
            if (max < items[i].getShowOrder())
                max = items[i].getShowOrder();
        return max;
    }
    /**
     * ��ñ�βԪ��
     * @param items nc.ui.pub.report.ReportItem[]
     */
    public ReportItem[] getTail_Items() {
        BillItem[] bis = getBaseClass().getBillData().getTailItems();
        if (bis == null)
            return null;
        else {
            ReportItem[] ris = new ReportItem[bis.length];
            for (int i = 0; i < bis.length; i++)
                ris[i] = (ReportItem) bis[i];
            return ris;
        }
    }
    /**
     * �˴����뷽��˵��.
     * @param risOrg nc.ui.pub.report.ReportItem[]
     */
    private ReportItem[] sortReportItem(ReportItem[] risOrg) {
        Comparator comp = getComparator();
        java.util.Arrays.sort(risOrg, comp);
        return risOrg;

    }
    /**
     * �˴����뷽��˵��.
     * @return java.util.Comparator
     */
    private Comparator getComparator() {
        Comparator comp = new java.util.Comparator() {
            public int compare(Object o1, Object o2) {
                ReportItem ri1 = (ReportItem) o1;
                ReportItem ri2 = (ReportItem) o2;
                if (ri1.getShowOrder() < ri2.getShowOrder())
                    return -1;
                else if (ri1.getShowOrder() == ri2.getShowOrder())
                    return 0;
                else
                    return 1;
            }
        };
        return comp;
    }
}
