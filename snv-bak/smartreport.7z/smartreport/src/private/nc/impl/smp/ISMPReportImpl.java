package nc.impl.smp;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import nc.bs.dao.BaseDAO;
import nc.bs.smp.SMPBaseDAO;
import nc.itf.smp.ISMPConstant;
import nc.itf.smp.ISMPReport;
import nc.jdbc.framework.JdbcSession;
import nc.jdbc.framework.PersistenceManager;
import nc.jdbc.framework.SQLParameter;
import nc.jdbc.framework.exception.DbException;
import nc.jdbc.framework.processor.MapListProcessor;
import nc.pub.smp.util.SMPUtil;
import nc.vo.pub.BusinessException;
import nc.vo.pub.lang.UFDate;
import nc.vo.pub.lang.UFDouble;
import nc.vo.smp.clsexe.ClsexeVO;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.detail.DetailQueryVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.income.AgentIncomeReportVO;
import nc.vo.smp.report.expensedetail.ExpenseDetailReportVO;
import nc.vo.smp.report.expensedetail.ExpenseReportResultSetProcessor;
import nc.vo.smp.report.expensedetail.QueryDateVO;
import nc.vo.smp.report.income.IncomeQueryVO;
import nc.vo.smp.report.income.IncomeReportVO;
import nc.vo.smp.report.income.ClsexeIncomePerBranch;
import nc.vo.smp.report.wperformance.WPerformanceReportResultSetProcessor;
import nc.vo.smp.report.wperformance.WPerformanceReportVO;

/**
 * ����ʵ����
 * @author LINQI
 *
 */
public class ISMPReportImpl implements ISMPReport{

	/**
	 * ȡ��ϸͳ�Ʊ�����
	 */
	public DetailReportVO[] getDetailData(DetailQueryVO queryVO) throws BusinessException {
		
		List<DetailReportVO> rtList = new ArrayList<DetailReportVO>();
		
		String month = queryVO.getMonth();
		UFDate date = new UFDate(month+"-"+"01");
		int weeks = SMPUtil.getWeeksOfMonth(date.toDate());
		
		SMPBaseDAO dao = null;
		try {
			dao = new SMPBaseDAO();
		} catch (NamingException e) {
			e.printStackTrace();
			throw new BusinessException("��ʼSMPBaseDAO�����쳣��"+e.getMessage());
		}
		String SQL = getAchievementSQL();
		SQLParameter param = new SQLParameter();
		for(int i=1;i<=weeks;i++){
			Date date1 = SMPUtil.getFirsDayOfWeek(date.toDate(), i);
			Date date2 = SMPUtil.getLastDayOfWeek(date.toDate(), i);
			UFDate dateFrom = new UFDate(date1);
			UFDate dateEnd = new UFDate(date2);
			
			param.clearParams();
			param.addParam(dateFrom.toString());
			param.addParam(dateEnd.toString());
			param.addParam(ISMPConstant.SMP_ACHIEVETYPE_ID_ZY);			//����ҵ��
			List list0 = (List) dao.executeQuery(SQL, param, new MapListProcessor());
			DetailReportVO vo0 = this.transResultSet(ISMPConstant.SMP_ACHIEVETYPE_NAME_ZY, list0);		//����ת��
			rtList.add(vo0);
			
			param.clearParams();
			param.addParam(dateFrom.toString());
			param.addParam(dateEnd.toString());
			param.addParam(ISMPConstant.SMP_ACHIEVETYPE_ID_DLS);			//������ҵ��
			List list1 = (List) dao.executeQuery(SQL, param, new MapListProcessor());
			DetailReportVO vo1 = this.transResultSet(ISMPConstant.SMP_ACHIEVETYPE_NAME_DLS, list1);		//����ת��
			rtList.add(vo1);
			
			DetailReportVO totalvo = this.getSubtotalRow("��"+i+"��ҵ���ϼ�("+dateFrom.getDay()+"-"+dateEnd.getDay()+"��)", vo0, vo1);	//����С��
			rtList.add(totalvo);
			
		}
		List totalList =  this.getTotalRow(rtList);		//���ɺϼ�
		rtList.addAll(totalList);
		if(!rtList.isEmpty()){
			return rtList.toArray(new DetailReportVO[0]);
		}
		return null;
	}
	
	/**
	 * �������ת���и�ʽ
	 * @param achievetype	ҵ������
	 * @param list
	 * @return
	 */
	private DetailReportVO transResultSet(String achievetype, List<Map> list){
		DetailReportVO vo = new DetailReportVO();
		vo.setAchievetype(achievetype);		//ҵ������
		UFDouble total = UFDouble.ZERO_DBL; 
		if(list!=null && list.size()>0){
			for(int i=0;i<list.size();i++){
				Map map = list.get(i);
				UFDouble remit_amount = map.get("remit_amount")!=null ? new UFDouble(map.get("remit_amount").toString()) : UFDouble.ZERO_DBL;
				total = total.add(remit_amount);
				vo.setAttributeValue((String)map.get("course_code"), remit_amount);
			}
		}
		vo.setRealitynum(total);	//����ʵ�ʶ�
		return vo;
	}
	
	/**
	 * ����С����
	 * @param rowHeading
	 * @param vo0	����ҵ��
	 * @param vo1	������ҵ��
	 * @return
	 */
	private DetailReportVO getSubtotalRow(String rowHeading,DetailReportVO vo0,DetailReportVO vo1){
		
		DetailReportVO totalvo = (DetailReportVO) vo0.clone();
		String[] fields = totalvo.getAttributeNames();
		
		UFDouble realTotal = UFDouble.ZERO_DBL; 	//����ʵ��
		for(int i=0;i<fields.length;i++){
			if(!fields[i].equals("achievetype") && !fields[i].startsWith("vfree")){
				Object obj_t = totalvo.getAttributeValue(fields[i]);
				Object obj_1 = vo1.getAttributeValue(fields[i]);
				UFDouble totalValue = (obj_t!=null ? new UFDouble(obj_t.toString()) : UFDouble.ZERO_DBL).add(obj_1 != null ? new UFDouble(obj_1.toString()): UFDouble.ZERO_DBL);
				totalvo.setAttributeValue(fields[i], totalValue);
				realTotal = realTotal.add(totalValue);
			}
		}
		totalvo.setRealitynum(realTotal);	//����ʵ�ʶ�
		totalvo.setAchievetype(rowHeading);	//������ͷ����
		return totalvo;
	}
	
	/**
	 * �������ĺϼ���
	 * @param list
	 * @return
	 */
	private List<DetailReportVO> getTotalRow(List<DetailReportVO> list){
		
		
		List<DetailReportVO> rtList = new ArrayList<DetailReportVO>();
		
		DetailReportVO totalvo0 = new DetailReportVO();	//����ҵ���ϼ�
		totalvo0.setAchievetype(ISMPConstant.SMP_ACHIEVETYPE_NAME_SUTOTAL_ZY);
		
		DetailReportVO totalvo1 = new DetailReportVO();	//����ҵ���ϼ�
		totalvo1.setAchievetype(ISMPConstant.SMP_ACHIEVETYPE_NAME_SUBTOTAL_DLS);
		
		DetailReportVO totalvo = new DetailReportVO();	//���ºϼ�
		totalvo.setAchievetype(ISMPConstant.SMP_ACHIEVETYPE_NAME_TOTAL);
		
		UFDouble realitynum_0 = UFDouble.ZERO_DBL;		//��������ҵ������ʵ��ͳ��
		UFDouble realitynum_1 = UFDouble.ZERO_DBL;		//���´�����ҵ������ʵ��ͳ��
		UFDouble realitynum_t = UFDouble.ZERO_DBL;		//���ºϼ�
		
		if(list!=null && list.size()>0){
			String[] fields = list.get(0).getAttributeNames();
			for(DetailReportVO vo:list){
//				if(vo.getAchievetype().equals(ISMPConstant.SMP_ACHIEVETYPE_NAME_ZY)){	//����ҵ���ϼ�
//					for(int i=0;i<fields.length;i++){
//						if(!fields[i].equals("achievetype")){
//							Object obj1 = totalvo0.getAttributeValue(fields[i]);
//							Object obj2 = vo.getAttributeValue(fields[i]);
//							UFDouble totalValue = (obj1!=null?new UFDouble(obj1.toString()):UFDouble.ZERO_DBL).add(obj2!=null?new UFDouble(obj2.toString()):UFDouble.ZERO_DBL);
//							totalvo0.setAttributeValue(fields[i], totalValue);
//							realitynum_0 = realitynum_0.add(totalValue);
//						}
//					}
//				}else if(vo.getAchievetype().equals(ISMPConstant.SMP_ACHIEVETYPE_NAME_DLS)){	//������ҵ��
//					for(int i=0;i<fields.length;i++){
//						if(!fields[i].equals("achievetype")){
//							Object obj1 = totalvo1.getAttributeValue(fields[i]);
//							Object obj2 = vo.getAttributeValue(fields[i]);
//							UFDouble totalValue = (obj1!=null?new UFDouble(obj1.toString()):UFDouble.ZERO_DBL).add(obj2!=null?new UFDouble(obj2.toString()):UFDouble.ZERO_DBL);
//							totalvo1.setAttributeValue(fields[i], totalValue);
//							realitynum_1 = realitynum_1.add(totalValue);
//						}
//					}
//				}else{
//					System.out.println("MMMMMMMMMMMMM"+vo.getAchievetype());
//					for(int i=0;i<fields.length;i++){
//						if(!fields[i].equals("achievetype")){
//							Object obj1 = totalvo.getAttributeValue(fields[i]);
//							Object obj2 = vo.getAttributeValue(fields[i]);
//							UFDouble totalValue = (obj1!=null?new UFDouble(obj1.toString()):UFDouble.ZERO_DBL).add(obj2!=null?new UFDouble(obj2.toString()):UFDouble.ZERO_DBL);
//							totalvo.setAttributeValue(fields[i], totalValue);
//							realitynum_t = realitynum_t.add(totalValue);
//						}
//					}
//				}
				
				for(int i=0;i<fields.length;i++){
					
					if(!fields[i].equals("achievetype")){
						if(vo.getAchievetype().equals(ISMPConstant.SMP_ACHIEVETYPE_NAME_ZY)){	//����ҵ���ϼ�
							Object obj1 = totalvo0.getAttributeValue(fields[i]);
							Object obj2 = vo.getAttributeValue(fields[i]);
							UFDouble totalValue = (obj1!=null?new UFDouble(obj1.toString()):UFDouble.ZERO_DBL).add(obj2!=null?new UFDouble(obj2.toString()):UFDouble.ZERO_DBL);
							totalvo0.setAttributeValue(fields[i], totalValue);
							realitynum_0 = realitynum_0.add(totalValue);
							
						}else if(vo.getAchievetype().equals(ISMPConstant.SMP_ACHIEVETYPE_NAME_DLS)){	//������ҵ��
							Object obj1 = totalvo1.getAttributeValue(fields[i]);
							Object obj2 = vo.getAttributeValue(fields[i]);
							UFDouble totalValue = (obj1!=null?new UFDouble(obj1.toString()):UFDouble.ZERO_DBL).add(obj2!=null?new UFDouble(obj2.toString()):UFDouble.ZERO_DBL);
							totalvo1.setAttributeValue(fields[i], totalValue);
							realitynum_1 = realitynum_1.add(totalValue);
							
						}else{		//���ºϼ�
							Object obj1 = totalvo.getAttributeValue(fields[i]);
							Object obj2 = vo.getAttributeValue(fields[i]);
							UFDouble totalValue = (obj1!=null?new UFDouble(obj1.toString()):UFDouble.ZERO_DBL).add(obj2!=null?new UFDouble(obj2.toString()):UFDouble.ZERO_DBL);
							totalvo.setAttributeValue(fields[i], totalValue);
							realitynum_t = realitynum_t.add(totalValue);
						}
					}
				}
			}
			totalvo0.setRealitynum(realitynum_0);
			totalvo1.setRealitynum(realitynum_1);
			totalvo.setRealitynum(realitynum_t);
			rtList.add(totalvo0);
			rtList.add(totalvo1);
			rtList.add(totalvo);
		}
		
		
		return rtList;
	}
	
	private String getAchievementSQL(){
		StringBuffer str = new StringBuffer();
		str.append("select b.pk_course,b.course_code,b.course_name,sum(nvl(a.remit_amount,0.00)) remit_amount ")
		   .append("from smp_course b left join  smp_performance a  on ( ")
		   .append("b.pk_course=a.pk_course ")
		   .append("and a.performance_date>=? ")
		   .append("and a.performance_date<=? ")
		   .append("and achievetype=? ")
		   .append(") ")
		   .append("where nvl(a.dr,0)=0 ")
		   .append("group by a.achievetype,b.pk_course,b.course_code,b.course_name ")
		   .append("order by b.course_code ")
		   .append(" ");
		return str.toString();
	}

	/**
	 * ȡ�γ̱�����
	 */
	public CourseVO[] getCourseVO(String str) throws BusinessException {
		List list = (List) new BaseDAO().retrieveByClause(CourseVO.class, str, new String[]{"course_code","course_name"});
		if(list!=null&&list.size()>0){
			return (CourseVO[]) list.toArray(new CourseVO[0]);
		}
		return null;
	}

	private String getIncomeSQL(){
		StringBuffer str = new StringBuffer();
		str.append("select b.pk_corp as branchcode, b.unitname as branchname, a.pk_clsexe as clsexe, sum(a.studentnum)as studentnum, ")
		   .append("sum(a.total_money)as totalmoney, sum(a.group_money)as groupmoney, sum(a.branch_money)as branchmoney, ")
		   .append("sum(a.jx_money)as jxmoney, sum(a.sd_money)as sdmoney ")
		   .append("from bd_corp b left join smp_income a on (a.pk_branch=b.pk_corp) ")
		   .append("left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe ")
		   .append("and c.class_start_date >= ? ")
		   .append("and c.class_start_date <= ?) ")
		   .append("group by b.pk_corp, b.unitname, a.pk_clsexe order by b.pk_corp");
		return str.toString();
	}
	
	public IncomeReportVO[] getCorpIncomeData(IncomeQueryVO queryVO)
			throws BusinessException {

		//List<IncomeReportVO> rtList = new ArrayList<IncomeReportVO>();

		SMPBaseDAO dao = null;
		try {
			dao = new SMPBaseDAO();
		} catch (NamingException e) {
			e.printStackTrace();
			throw new BusinessException("��ʼSMPBaseDAO�����쳣��"+e.getMessage());
		}
		String SQL = getIncomeSQL();
		SQLParameter param = new SQLParameter();
		
		param.clearParams();
		param.addParam(queryVO.getFromDate().toString());
		param.addParam(queryVO.getEndDate().toString());
		
		List list0 = (List) dao.executeQuery(SQL, param, new MapListProcessor());
		
		List<IncomeReportVO> rtList = transIncomeResultSet(list0);		//����ת��
		
		if(!rtList.isEmpty()){
			return rtList.toArray(new IncomeReportVO[0]);
		}
		return null;
		

	}

	private List<IncomeReportVO> transIncomeResultSet(List<Map> list) {
		List<IncomeReportVO> rtList = new ArrayList<IncomeReportVO>();
		//UFDouble total = UFDouble.ZERO_DBL; 
		if(list!=null && list.size()>0){
			String lastBranchCode = null;
			boolean branchChanged = false;
			IncomeReportVO incomeVO = null;
			UFDouble total_income_perclsexe  = UFDouble.ZERO_DBL;
			UFDouble group_income_perclsexe  = UFDouble.ZERO_DBL;
			UFDouble branch_income_perclsexe  = UFDouble.ZERO_DBL;
			UFDouble jx_income_perclsexe  = UFDouble.ZERO_DBL;
			UFDouble sd_income_perclsexe  = UFDouble.ZERO_DBL;			
			for(Map map : list) {
				String currentBranchCode = (String)map.get("branchcode");
				if(!currentBranchCode.equals(lastBranchCode)) {
					if(incomeVO != null) {
						ClsexeIncomePerBranch summationPerBranch = new ClsexeIncomePerBranch();
						summationPerBranch.setPk_clsexe("summationperbranch");
						summationPerBranch.setTotalMoney(total_income_perclsexe.toString());
						
						summationPerBranch.setGroupMoney(group_income_perclsexe.toString());;
						summationPerBranch.setBranchMoney(branch_income_perclsexe.toString());
						summationPerBranch.setJxMoney(jx_income_perclsexe.toString());
						summationPerBranch.setSdMoney(sd_income_perclsexe.toString());
						incomeVO.setAttributeValue(summationPerBranch.getPk_clsexe(), summationPerBranch);
						rtList.add(incomeVO);							
					}
					
					total_income_perclsexe  = UFDouble.ZERO_DBL;
					group_income_perclsexe  = UFDouble.ZERO_DBL;
					branch_income_perclsexe  = UFDouble.ZERO_DBL;
					jx_income_perclsexe  = UFDouble.ZERO_DBL;
					sd_income_perclsexe  = UFDouble.ZERO_DBL;
					incomeVO = new IncomeReportVO();
					incomeVO.setAttributeValue("branchname", (String)map.get("branchname"));
					lastBranchCode = map.get("branchcode").toString();
				}
				ClsexeIncomePerBranch clsexePerBranch = new ClsexeIncomePerBranch();
				if(map.get("clsexe")!= null)
					clsexePerBranch.setPk_clsexe(map.get("clsexe").toString());
				if(map.get("studentnum")!= null){
					clsexePerBranch.setStudentNum(map.get("studentnum").toString());
				}
				if(map.get("totalmoney")!= null) {
					clsexePerBranch.setTotalMoney(map.get("totalmoney").toString());
					total_income_perclsexe = total_income_perclsexe.add(new UFDouble(map.get("totalmoney").toString()));				
				}
				if(map.get("groupmoney")!= null) {
					clsexePerBranch.setGroupMoney(map.get("groupmoney").toString());
					group_income_perclsexe = group_income_perclsexe.add(new UFDouble(map.get("groupmoney").toString()));							
				}
				if(map.get("branchmoney")!= null) {
					clsexePerBranch.setBranchMoney(map.get("branchmoney").toString());
					branch_income_perclsexe = branch_income_perclsexe.add(new UFDouble(map.get("branchmoney").toString()));					
				}
				if(map.get("jxmoney")!= null) {
					clsexePerBranch.setJxMoney(map.get("jxmoney").toString());
					jx_income_perclsexe = jx_income_perclsexe.add(new UFDouble(map.get("jxmoney").toString()));					
				}
				if(map.get("sdmoney")!= null) {
					clsexePerBranch.setSdMoney(map.get("sdmoney").toString());
					sd_income_perclsexe = sd_income_perclsexe.add(new UFDouble(map.get("sdmoney").toString()));					
				}
				
				incomeVO.setAttributeValue(clsexePerBranch.getPk_clsexe(), clsexePerBranch);
			}
			if(incomeVO != null) {
				rtList.add(incomeVO);
			}
		}
		return rtList;
	}
	
	private String getAgentIncomeSQL(){
		StringBuffer str = new StringBuffer();
		str.append("select a.pk_agent as agentname, b.unitcode as branchcode, b.unitname as branchname,a.pk_clsexe as clsexe, sum(a.studentnum)as studennumber, ")
		   .append("sum(a.total_money)as totalmoney from bd_corp b left join smp_income_agent a on (a.pk_branch=b.unitcode)")
		   .append("left join smp_clsexe c on (a.pk_clsexe=c.pk_clsexe and c.class_start_date >= ? ")
		   .append("and c.class_start_date <= ?) ")
		   .append("group by b.unitcode, b.unitname, a.pk_clsexe, a.pk_agent order by b.unitcode, a.pk_agent");
		return str.toString();
	}
	
	public AgentIncomeReportVO[] getAgentIncomeData(IncomeQueryVO queryVO) throws BusinessException
	{
		SMPBaseDAO dao = null;
		try {
			dao = new SMPBaseDAO();
		} catch (NamingException e) {
			e.printStackTrace();
			throw new BusinessException("��ʼSMPBaseDAO�����쳣��"+e.getMessage());
		}
		String SQL = getAgentIncomeSQL();
		SQLParameter param = new SQLParameter();
		
		param.clearParams();
		param.addParam(queryVO.getFromDate().toString());
		param.addParam(queryVO.getEndDate().toString());
		
		List list0 = (List) dao.executeQuery(SQL, param, new MapListProcessor());
		
		List<AgentIncomeReportVO> rtList = transAgentIncomeResultSet(list0);		//����ת��
		
		if(!rtList.isEmpty()){
			return rtList.toArray(new AgentIncomeReportVO[0]);
		}
		return null;
	}
	
	private List<AgentIncomeReportVO> transAgentIncomeResultSet(List<Map> list) {
		List<AgentIncomeReportVO> rtList = new ArrayList<AgentIncomeReportVO>(); 
		if(list!=null && list.size()>0){
			String lastAgent = null;
			AgentIncomeReportVO incomeVO = null;
			UFDouble total_income_perclsexe  = UFDouble.ZERO_DBL;			
			for(Map map : list) {
				String currentAgent = (String)map.get("agentname");
				if(!currentAgent.equals(lastAgent)) {
					if(incomeVO != null) {
						ClsexeIncomePerBranch summationPerBranch = new ClsexeIncomePerBranch();
						summationPerBranch.setPk_clsexe("summationperagent");
						summationPerBranch.setTotalMoney(total_income_perclsexe.toString());
						
						incomeVO.setAttributeValue(summationPerBranch.getPk_clsexe(), summationPerBranch);
						rtList.add(incomeVO);							
					}
					
					total_income_perclsexe  = UFDouble.ZERO_DBL;
					incomeVO = new AgentIncomeReportVO();
					incomeVO.setAttributeValue("branchname", (String)map.get("branchname"));
					incomeVO.setAttributeValue("agentname", (String)map.get("agentname"));
					lastAgent = map.get("agentname").toString();
				}
				ClsexeIncomePerBranch clsexePerBranch = new ClsexeIncomePerBranch();
				if(map.get("clsexe")!= null)
					clsexePerBranch.setPk_clsexe(map.get("clsexe").toString());
				if(map.get("studentnum")!= null){
					clsexePerBranch.setStudentNum(map.get("studentnum").toString());
				}
				if(map.get("totalmoney")!= null) {
					clsexePerBranch.setTotalMoney(map.get("totalmoney").toString());
					total_income_perclsexe = total_income_perclsexe.add(new UFDouble(map.get("totalmoney").toString()));				
				}
				
				incomeVO.setAttributeValue(clsexePerBranch.getPk_clsexe(), clsexePerBranch);
			}
			if(incomeVO != null) {
				rtList.add(incomeVO);
			}
		}
		return rtList;
	}
	
	public ClsexeVO[] getClsexeVO(IncomeQueryVO queryVO) throws BusinessException {
		
		//String month = queryVO.getMonth();
		//UFDate date = new UFDate(month+"-"+"01");
		//Date theDate = new Date(month+"-"+"01");
		//Date firstDay = SMPUtil.getFirstDayOfCurrentMonth(theDate);
		//Date lastDay = SMPUtil.getLastDayOfCurrentMonth(theDate);
		
		StringBuilder sb = new StringBuilder();
		sb.append("class_start_date >= '");
		sb.append(queryVO.getFromDate().toString());
		sb.append("' and class_start_date<='");
		sb.append(queryVO.getEndDate().toString());
		sb.append("'");
		
		List list = (List) new BaseDAO().retrieveByClause(ClsexeVO.class, sb.toString());
		if(list!=null&&list.size()>0){
			return (ClsexeVO[]) list.toArray(new ClsexeVO[0]);
		}
		return null;
	}
	public List<ExpenseDetailReportVO> getExpenseDetail(QueryDateVO queryVO) throws BusinessException {
		Map<String,String> map=new HashMap<String,String>();
		map.put("GLFY", "��������");
		map.put("XSFY", "���۷���");
		map.put("CWFY", "�������");
		List <ExpenseDetailReportVO>resultList=getExpenseDetailList(queryVO);
		List<ExpenseDetailReportVO> returnList=new ArrayList<ExpenseDetailReportVO> ();
		if(resultList!=null){
			
			ExpenseDetailReportVO glSumVO=new ExpenseDetailReportVO();
			 
			List<ExpenseDetailReportVO> glList=new ArrayList();
			ExpenseDetailReportVO xsSumVO=new ExpenseDetailReportVO();
			List<ExpenseDetailReportVO> xsList=new ArrayList();
			ExpenseDetailReportVO cwSumVO=new ExpenseDetailReportVO();
			List<ExpenseDetailReportVO> cwList=new ArrayList();
			ExpenseDetailReportVO ndSumVO=new ExpenseDetailReportVO();
			xsSumVO.setExpenseType("���۷����ܼ�");
			xsSumVO.setExpenseCode("----------");
			xsSumVO.setExpenseName("----------");
			glSumVO.setExpenseType("���������ܼ�");
			glSumVO.setExpenseCode("----------");
			glSumVO.setExpenseName("----------");
			cwSumVO.setExpenseType("��������ܼ�");
			cwSumVO.setExpenseCode("----------");
			cwSumVO.setExpenseName("----------");
			ndSumVO.setExpenseType("��ȷ����ܼ�");
			ndSumVO.setExpenseCode("----------");
			ndSumVO.setExpenseName("----------");
			for(ExpenseDetailReportVO vo:resultList){
				ndSumVO.setYearSum(ndSumVO.getYearSum().add(vo.getYearSum()));
				ndSumVO.setJanSum(ndSumVO.getJanSum().add(vo.getJanSum()));
				ndSumVO.setFebSum(ndSumVO.getFebSum().add(vo.getFebSum()));
				ndSumVO.setMatSum(ndSumVO.getMatSum().add(vo.getMatSum()));
				ndSumVO.setAprSum(ndSumVO.getAprSum().add(vo.getAprSum()));
				ndSumVO.setMaySum(ndSumVO.getMaySum().add(vo.getMaySum()));
				ndSumVO.setJunSum(ndSumVO.getJunSum().add(vo.getJunSum()));
				ndSumVO.setJulSum(ndSumVO.getJulSum().add(vo.getJulSum()));
				ndSumVO.setAugSum(ndSumVO.getAugSum().add(vo.getAugSum()));
				ndSumVO.setSepSum(ndSumVO.getSepSum().add(vo.getSepSum()));
				ndSumVO.setOctSum(ndSumVO.getOctSum().add(vo.getOctSum()));
				ndSumVO.setNovSum(ndSumVO.getNovSum().add(vo.getNovSum()));
				ndSumVO.setDecSum(ndSumVO.getDecSum().add(vo.getDecSum()));
				if("GLFY".equalsIgnoreCase(vo.getExpenseType())){
					vo.setExpenseType("��������");
					glList.add(vo);
					glSumVO.setYearSum(glSumVO.getYearSum().add(vo.getYearSum()));
					glSumVO.setJanSum(glSumVO.getJanSum().add(vo.getJanSum()));
					glSumVO.setFebSum(glSumVO.getFebSum().add(vo.getFebSum()));
					glSumVO.setMatSum(glSumVO.getMatSum().add(vo.getMatSum()));
					glSumVO.setAprSum(glSumVO.getAprSum().add(vo.getAprSum()));
					glSumVO.setMaySum(glSumVO.getMaySum().add(vo.getMaySum()));
					glSumVO.setJunSum(glSumVO.getJunSum().add(vo.getJunSum()));
					glSumVO.setJulSum(glSumVO.getJulSum().add(vo.getJulSum()));
					glSumVO.setAugSum(glSumVO.getAugSum().add(vo.getAugSum()));
					glSumVO.setSepSum(glSumVO.getSepSum().add(vo.getSepSum()));
					glSumVO.setOctSum(glSumVO.getOctSum().add(vo.getOctSum()));
					glSumVO.setNovSum(glSumVO.getNovSum().add(vo.getNovSum()));
					glSumVO.setDecSum(glSumVO.getDecSum().add(vo.getDecSum()));
				}else if("XSFY".equalsIgnoreCase(vo.getExpenseType())){
					vo.setExpenseType("���۷���");
					xsList.add(vo);
					xsSumVO.setYearSum(xsSumVO.getYearSum().add(vo.getYearSum()));
					xsSumVO.setJanSum(xsSumVO.getJanSum().add(vo.getJanSum()));
					xsSumVO.setFebSum(xsSumVO.getFebSum().add(vo.getFebSum()));
					xsSumVO.setMatSum(xsSumVO.getMatSum().add(vo.getMatSum()));
					xsSumVO.setAprSum(xsSumVO.getAprSum().add(vo.getAprSum()));
					xsSumVO.setMaySum(xsSumVO.getMaySum().add(vo.getMaySum()));
					xsSumVO.setJunSum(xsSumVO.getJunSum().add(vo.getJunSum()));
					xsSumVO.setJulSum(xsSumVO.getJulSum().add(vo.getJulSum()));
					xsSumVO.setAugSum(xsSumVO.getAugSum().add(vo.getAugSum()));
					xsSumVO.setSepSum(xsSumVO.getSepSum().add(vo.getSepSum()));
					xsSumVO.setOctSum(xsSumVO.getOctSum().add(vo.getOctSum()));
					xsSumVO.setNovSum(xsSumVO.getNovSum().add(vo.getNovSum()));
					xsSumVO.setDecSum(xsSumVO.getDecSum().add(vo.getDecSum()));
				}else if("CWFY".equalsIgnoreCase(vo.getExpenseType())){
					vo.setExpenseType("�������");
					cwList.add(vo);
					cwSumVO.setYearSum(cwSumVO.getYearSum().add(vo.getYearSum()));
					cwSumVO.setJanSum(cwSumVO.getJanSum().add(vo.getJanSum()));
					cwSumVO.setFebSum(cwSumVO.getFebSum().add(vo.getFebSum()));
					cwSumVO.setMatSum(cwSumVO.getMatSum().add(vo.getMatSum()));
					cwSumVO.setAprSum(cwSumVO.getAprSum().add(vo.getAprSum()));
					cwSumVO.setMaySum(cwSumVO.getMaySum().add(vo.getMaySum()));
					cwSumVO.setJunSum(cwSumVO.getJunSum().add(vo.getJunSum()));
					cwSumVO.setJulSum(cwSumVO.getJulSum().add(vo.getJulSum()));
					cwSumVO.setAugSum(cwSumVO.getAugSum().add(vo.getAugSum()));
					cwSumVO.setSepSum(cwSumVO.getSepSum().add(vo.getSepSum()));
					cwSumVO.setOctSum(cwSumVO.getOctSum().add(vo.getOctSum()));
					cwSumVO.setNovSum(cwSumVO.getNovSum().add(vo.getNovSum()));
					cwSumVO.setDecSum(cwSumVO.getDecSum().add(vo.getDecSum()));
				}
			}
			for(ExpenseDetailReportVO vo:xsList){
				returnList.add(vo);
			}
			returnList.add(xsSumVO);
			for(ExpenseDetailReportVO vo:glList){
				returnList.add(vo);
			}
			returnList.add(glSumVO);
			for(ExpenseDetailReportVO vo:cwList){
				returnList.add(vo);
			}
			returnList.add(cwSumVO);
			returnList.add(ndSumVO);
		}
		return returnList;
	}
	private List<ExpenseDetailReportVO> getExpenseDetailList(QueryDateVO queryVO) throws BusinessException {
		 PersistenceManager sessionManager=null;
		 String queryDate=queryVO.getQueryDate();
		 SQLParameter sqlParameter=new SQLParameter();
		 sqlParameter.addParam(queryDate);
		 List<ExpenseDetailReportVO> result=null;
		 ExpenseDetailReportVO[] arrayResult=null;
		 if(queryDate==null) return null;
		try {
		   sessionManager= PersistenceManager. getInstance ();
		 JdbcSession session = sessionManager.getJdbcSession ();
		 
//		���ݿ���ʲ���
		 String querySql= "select expensetype,\n" +
         "       expensecode,\n" +
         "       expensename,\n" +
         "       sum(total) as yearSum,\n" +
         "       sum(m01) as janSum,\n" +
         "       sum(m02) as febSum,\n" +
         "       sum(m03) as matSum,\n" +
         "       sum(m04) as aprSum,\n" +
         "       sum(m05) as maySum,\n" +
         "       sum(m06) as junSum,\n" +
         "       sum(m07) as julSum,\n" +
         "       sum(m08) as augSum,\n" +
         "       sum(m09) as sepSum,\n" +
         "       sum(m10) as octSum,\n" +
         "       sum(m11) as novSum,\n" +
         "       sum(m12) as decSum\n" +
         "  from (select t.*,\n" +
         "               m01 + m02 + m03 + m04 + m05 + m06 + m07 + m08 + m09 + m10 + m11 + m12 as total\n" +
         "          from (select t.expensecode,\n" +
         "                       t.expensename,\n" +
         "                       t.expensetype,\n" +
         "                       decode(substr(t.t_year, 6, 2), '01', t.amount, 0) as m01,\n" +
         "                       decode(substr(t.t_year, 6, 2), '02', t.amount, 0) as m02,\n" +
         "                       decode(substr(t.t_year, 6, 2), '03', t.amount, 0) as m03,\n" +
         "                       decode(substr(t.t_year, 6, 2), '04', t.amount, 0) as m04,\n" +
         "                       decode(substr(t.t_year, 6, 2), '05', t.amount, 0) as m05,\n" +
         "                       decode(substr(t.t_year, 6, 2), '06', t.amount, 0) as m06,\n" +
         "                       decode(substr(t.t_year, 6, 2), '07', t.amount, 0) as m07,\n" +
         "                       decode(substr(t.t_year, 6, 2), '08', t.amount, 0) as m08,\n" +
         "                       decode(substr(t.t_year, 6, 2), '09', t.amount, 0) as m09,\n" +
         "                       decode(substr(t.t_year, 6, 2), '10', t.amount, 0) as m10,\n" +
         "                       decode(substr(t.t_year, 6, 2), '11', t.amount, 0) as m11,\n" +
         "                       decode(substr(t.t_year, 6, 2), '12', t.amount, 0) as m12\n" +
         "                  from smp_expensedetail t\n" +
         "                 where substr(t.t_year, 0, 4) = ?) t) e\n" +
         " group by expensetype, expensecode, expensename";
		 
		  result=(List<ExpenseDetailReportVO>) session.executeQuery(querySql, sqlParameter,new  ExpenseReportResultSetProcessor());
		} catch (DbException e) {
			e.printStackTrace();
		}
		finally {  
			if(sessionManager!=null)
			sessionManager. release ();//��Ҫ�رջỰ
		} 
		int size=0;
		if(result!=null){
			 size=result.size();
			 
		}

		return result;
	}
	public List<WPerformanceReportVO> getWPerformance(QueryDateVO queryVO ) throws BusinessException{
		List<WPerformanceReportVO> result=genWPerformanceDate(queryVO);
		 
		return result;
	}
	private List<WPerformanceReportVO> genWPerformanceDate(QueryDateVO queryVO) throws BusinessException{
		String sql="select itemcode,achievetype,sum(wamount) as wamount ,sum(fweek) as fweek,sum(sweek) as sweek,sum(tweek) as tweek,sum(ftweek) as ftweek,sum(fiweek) as fiweek from (\n"+
				 "SELECT decode(e.achievetype, 0, '����ҵ��', 1, '����������ҵ��') as itemcode,\n"+
				        "e.achievetype, e.remit_amount  as wamount ,\n"+
				        "decode(to_char(to_date(e.performance_date,'YYYY-MM-DD'),'W'),1,e.remit_amount) as fweek,\n"+
				"        decode(to_char(to_date(e.performance_date,'YYYY-MM-DD'),'W'),2,e.remit_amount) as sweek,\n"+
				"        decode(to_char(to_date(e.performance_date,'YYYY-MM-DD'),'W'),3,e.remit_amount) as tweek,\n"+
				"        decode(to_char(to_date(e.performance_date,'YYYY-MM-DD'),'W'),4,e.remit_amount) as ftweek,\n"+
				"        decode(to_char(to_date(e.performance_date,'YYYY-MM-DD'),'W'),5,e.remit_amount) as fiweek\n"+
				" FROM SMP_PERFORMANCE E WHERE SUBSTR(E.PERFORMANCE_DATE, 0, 7) = ?\n"+
				" ) group by itemcode,achievetype";
		 PersistenceManager sessionManager=null;
		 String queryDate=queryVO.getQueryDate();
		 SQLParameter sqlParameter=new SQLParameter();
		 sqlParameter.addParam(queryDate);
		 List<WPerformanceReportVO> result=null;
		 
		 if(queryDate==null) return null;
		try {
		   sessionManager= PersistenceManager. getInstance ();
		 JdbcSession session = sessionManager.getJdbcSession ();
		 result=( List<WPerformanceReportVO>)session.executeQuery(sql,sqlParameter, new WPerformanceReportResultSetProcessor());
		 //������ҵ��
		 if(result!=null){
			 WPerformanceReportVO tvo=new WPerformanceReportVO();
			 tvo.setItemcode("ʵ��������ҵ��");
			 
			 for(WPerformanceReportVO vo:result){
				tvo.setWamount(tvo.getWamount().add(vo.getWamount()));
				tvo.setFweek(tvo.getFweek().add(vo.getFweek()));
				tvo.setFtweek(tvo.getFtweek().add(vo.getFtweek()));
				tvo.setFiweek(tvo.getFiweek().add(vo.getFiweek()));
				tvo.setSweek(tvo.getSweek().add(vo.getSweek()));
				tvo.setTweek(tvo.getTweek().add(vo.getTweek()));
			 }
			 result.add(0, tvo);
		 }
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
}
