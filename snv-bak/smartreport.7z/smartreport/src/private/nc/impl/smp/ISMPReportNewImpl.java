package nc.impl.smp;

import java.util.ArrayList;
import java.util.List;

import nc.bs.smp.InnerMangDMO;
import nc.itf.smp.ISMPReportNew;
import nc.vo.pub.BusinessException;
import nc.vo.smp.report.innermang.InnerMangQueryVO;
import nc.vo.smp.report.innermang.InnerMangReportVO;

public class ISMPReportNewImpl implements ISMPReportNew {

	/**
	 * �����ڲ���������
	 */
	public InnerMangReportVO[] getInnerMangData(InnerMangQueryVO queryvo) throws BusinessException {
		
		List<InnerMangReportVO> rtList = new ArrayList<InnerMangReportVO>();
		InnerMangDMO dmo = new InnerMangDMO();
		InnerMangReportVO r3 = dmo.getR3_YuSuanXiaoShouYeJi();		//excel�����еĵ����С�Ԥ������ҵ����
		InnerMangReportVO r4 = dmo.getR4_YuSuanXiaoShouYeJi_XiaYue();
		InnerMangReportVO r5 = dmo.getR5_ShiJiXiaoShouYeJi();
		InnerMangReportVO r6 = dmo.getR6_ShiJiXiaoShouYeJi_ZiYou();
		rtList.add(r3);
		rtList.add(r4);
		rtList.add(r5);
		rtList.add(r6);
		if(!rtList.isEmpty())
			return rtList.toArray(new InnerMangReportVO[0]);
		
		return null;
	}

}
