package nc.pub.smp.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import nc.lfw.querytemplate.sysfunc.SysFunctionUtil.FirstDayOfCurrentMonth;


public class SMPUtil {

	public static int getWeeksOfMonth(Date date){
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.set(Calendar.DATE, 1);
		int weekOfMonth = cal.getActualMaximum(Calendar.WEEK_OF_MONTH);		//һ���������
		return weekOfMonth;
	}
	
	/**
	 * @param date
	 * @param week
	 * @return
	 */
	public static Date getFirsDayOfWeek(Date date,int week){
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.set(Calendar.DATE, 1);
		
		cal.setFirstDayOfWeek(Calendar.SATURDAY);
		int currentMonth = cal.get(Calendar.MONTH);
		while(true) {
			if(cal.get(Calendar.WEEK_OF_MONTH) == week) {
				return cal.getTime();
			}
			cal.add(Calendar.DAY_OF_WEEK, 1);
			int monthAfterShift = cal.get(Calendar.MONTH);
			if (monthAfterShift != currentMonth){
				break;
			}
		}
		return null;
	}
	
	public static Date getLastDayOfWeek(Date date,int week){
		Date firstDayOfThisWeek = getFirsDayOfWeek(date, week);
		if (firstDayOfThisWeek == null) {
			return null;
		}
		
		Calendar cal = new GregorianCalendar();
		cal.setTime(firstDayOfThisWeek);

		int lastDayOfMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		if(week == 1){
			int currentDayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
			int daysLeftInCurrentWeek = 6 - currentDayOfWeek;
			if(lastDayOfMonth - cal.get(Calendar.DAY_OF_MONTH) >= daysLeftInCurrentWeek){
				cal.add(Calendar.DAY_OF_WEEK, daysLeftInCurrentWeek);
			} else {
				cal.add(Calendar.DAY_OF_WEEK, lastDayOfMonth - cal.get(Calendar.DAY_OF_MONTH)); 
			}
		} else {
			if(( lastDayOfMonth - cal.get(Calendar.DAY_OF_MONTH)) >= 6 ){
				cal.add(Calendar.DAY_OF_WEEK, 6);
			} else {
				cal.add(Calendar.DAY_OF_WEEK, lastDayOfMonth - cal.get(Calendar.DAY_OF_MONTH)); 
			}
		}
		return cal.getTime();
	}
		
	/** 
	 * ȡ��ָ�����������ܵĵ�һ�� 
	 * 
	 * @param date 
	 * @return 
	 */ 
	 public static Date getFirstDayOfWeek(Date date) { 
		 Calendar c = new GregorianCalendar(); 
		 c.setFirstDayOfWeek(Calendar.SATURDAY);		//������Ϊ��ʼ��
		 c.setTime(date); 
		 c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek()); // Monday 
		 return c.getTime (); 
	 }
	 
	 
	 /** 
	 * ȡ��ָ�����������ܵ����һ�� 
	 * 
	 * @param date 
	 * @return 
	 */ 
	 public static Date getLastDayOfWeek(Date date) { 
		 Calendar c = new GregorianCalendar(); 
		 c.setFirstDayOfWeek(Calendar.SATURDAY);		//������Ϊ��ʼ��
		 c.setTime(date); 
		 c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek() + 6); // Sunday
		 return c.getTime(); 
	 } 
	
}
