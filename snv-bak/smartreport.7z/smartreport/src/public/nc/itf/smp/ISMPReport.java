package nc.itf.smp;
import java.util.List;

import nc.vo.pub.BusinessException;
import nc.vo.smp.clsexe.ClsexeVO;
import nc.vo.smp.cost.CostVO;
import nc.vo.smp.course.CourseVO;
import nc.vo.smp.report.cost.CostQueryVO;
import nc.vo.smp.report.cost.CostReportVO;
import nc.vo.smp.report.detail.DetailQueryVO;
import nc.vo.smp.report.detail.DetailReportVO;
import nc.vo.smp.report.income.AgentIncomeReportVO;
import nc.vo.smp.report.expensedetail.ExpenseDetailReportVO;
import nc.vo.smp.report.expensedetail.QueryDateVO;
import nc.vo.smp.report.income.IncomeQueryVO;
import nc.vo.smp.report.income.IncomeReportVO;
import nc.vo.smp.report.wperformance.WPerformanceReportVO;


/**
 * �����ӿ�
 * @author LINQI
 *
 */
public interface ISMPReport {

	// For �������  
	public DetailReportVO[] getDetailData(DetailQueryVO queryVO) throws BusinessException;	
	public CourseVO[] getCourseVO(String str) throws BusinessException;
	
	// For ���뱨��
	public IncomeReportVO[] getCorpIncomeData(IncomeQueryVO queryVO) throws BusinessException;
	public AgentIncomeReportVO[] getAgentIncomeData(IncomeQueryVO queryVO) throws BusinessException;
	public AgentIncomeReportVO[] getChannelIncomeData(IncomeQueryVO queryVO) throws BusinessException;
	
	// Get all the class execution during this moth
	public ClsexeVO[] getClsexeVO(IncomeQueryVO queryVO) throws BusinessException;
	
	
	//������ϸ����
	public List<ExpenseDetailReportVO> getExpenseDetail(QueryDateVO queryVO ) throws BusinessException;
	//�ܼ�Ч����
 
	public List<WPerformanceReportVO> getWPerformance(QueryDateVO queryVO ) throws BusinessException;
	
	//����ɱ�����	 
	public CostReportVO[] getCostData(CostQueryVO queryVO ) throws BusinessException;
	
}
