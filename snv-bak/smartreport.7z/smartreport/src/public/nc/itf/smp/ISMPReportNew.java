package nc.itf.smp;

import nc.vo.pub.BusinessException;
import nc.vo.smp.report.innermang.InnerMangQueryVO;
import nc.vo.smp.report.innermang.InnerMangReportVO;

public interface ISMPReportNew {

	/**
	 * �����ڲ���������
	 * @return
	 * @throws BusinessException
	 */
	public InnerMangReportVO[] getInnerMangData(InnerMangQueryVO queryvo) throws BusinessException;
}
