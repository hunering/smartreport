package nc.vo.smp.report.innermang;

import nc.vo.pub.SuperVO;
import nc.vo.pub.lang.UFDouble;

/**
 * �����ڲ���������VO
 * @author LINQI
 *
 */
public class InnerMangReportVO extends SuperVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	private String itemname;		//��Ŀ����
	private UFDouble yeartotal;		//�����ۼ�
	private UFDouble month1;		//1�½��
	private UFDouble month2;		//2�½��
	private UFDouble month3;		//3�½��
	private UFDouble month4;		//4�½��
	private UFDouble month5;		//5�½��
	private UFDouble month6;		//6�½��
	private UFDouble month7;		//7�½��
	private UFDouble month8;		//8�½��
	private UFDouble month9;		//9�½��
	private UFDouble month10;		//10�½��
	private UFDouble month11;		//11�½��
	private UFDouble month12;		//12�½��
	
	private String excelno;			//excel����к�
	
	private String vfree1;	//
	private String vfree2;	//
	private String vfree3;	//
	private String vfree4;	//
	private String vfree5;	//
	
	public InnerMangReportVO(){

	}
	
	

	public String getExcelno() {
		return excelno;
	}



	public void setExcelno(String excelno) {
		this.excelno = excelno;
	}



	public String getItemname() {
		return itemname;
	}



	public void setItemname(String itemname) {
		this.itemname = itemname;
	}



	public UFDouble getYeartotal() {
		return yeartotal;
	}



	public void setYeartotal(UFDouble yeartotal) {
		this.yeartotal = yeartotal;
	}



	public UFDouble getMonth1() {
		return month1;
	}



	public void setMonth1(UFDouble month1) {
		this.month1 = month1;
	}



	public UFDouble getMonth2() {
		return month2;
	}



	public void setMonth2(UFDouble month2) {
		this.month2 = month2;
	}



	public UFDouble getMonth3() {
		return month3;
	}



	public void setMonth3(UFDouble month3) {
		this.month3 = month3;
	}



	public UFDouble getMonth4() {
		return month4;
	}



	public void setMonth4(UFDouble month4) {
		this.month4 = month4;
	}



	public UFDouble getMonth5() {
		return month5;
	}



	public void setMonth5(UFDouble month5) {
		this.month5 = month5;
	}



	public UFDouble getMonth6() {
		return month6;
	}



	public void setMonth6(UFDouble month6) {
		this.month6 = month6;
	}



	public UFDouble getMonth7() {
		return month7;
	}



	public void setMonth7(UFDouble month7) {
		this.month7 = month7;
	}



	public UFDouble getMonth8() {
		return month8;
	}



	public void setMonth8(UFDouble month8) {
		this.month8 = month8;
	}



	public UFDouble getMonth9() {
		return month9;
	}



	public void setMonth9(UFDouble month9) {
		this.month9 = month9;
	}



	public UFDouble getMonth10() {
		return month10;
	}



	public void setMonth10(UFDouble month10) {
		this.month10 = month10;
	}



	public UFDouble getMonth11() {
		return month11;
	}



	public void setMonth11(UFDouble month11) {
		this.month11 = month11;
	}



	public UFDouble getMonth12() {
		return month12;
	}



	public void setMonth12(UFDouble month12) {
		this.month12 = month12;
	}



	public String getVfree1() {
		return vfree1;
	}



	public void setVfree1(String vfree1) {
		this.vfree1 = vfree1;
	}



	public String getVfree2() {
		return vfree2;
	}



	public void setVfree2(String vfree2) {
		this.vfree2 = vfree2;
	}



	public String getVfree3() {
		return vfree3;
	}



	public void setVfree3(String vfree3) {
		this.vfree3 = vfree3;
	}



	public String getVfree4() {
		return vfree4;
	}



	public void setVfree4(String vfree4) {
		this.vfree4 = vfree4;
	}



	public String getVfree5() {
		return vfree5;
	}



	public void setVfree5(String vfree5) {
		this.vfree5 = vfree5;
	}



	@Override
	public String getParentPKFieldName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPKFieldName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
