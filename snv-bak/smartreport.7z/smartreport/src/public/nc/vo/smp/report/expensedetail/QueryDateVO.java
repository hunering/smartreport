package nc.vo.smp.report.expensedetail;

import java.io.Serializable;

public class QueryDateVO implements Serializable{
	private String queryDate;
	private String unitcode;	//��λ����
	private String pk_corp;
	public String getPk_corp() {
		return pk_corp;
	}
	public void setPk_corp(String pk_corp) {
		this.pk_corp = pk_corp;
	}
	public String getQueryDate() {
		return queryDate;
	}
	public void setQueryDate(String queryDate) {
		this.queryDate = queryDate;
	}
	public String getUnitcode() {
		return unitcode;
	}
	public void setUnitcode(String unitcode) {
		this.unitcode = unitcode;
	}		 
}
