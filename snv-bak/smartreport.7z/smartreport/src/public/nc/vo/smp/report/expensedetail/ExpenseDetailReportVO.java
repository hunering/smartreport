package nc.vo.smp.report.expensedetail;

import java.util.HashMap;
import java.util.Vector;

import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.ValidationException;
import nc.vo.pub.lang.UFDouble;

public class ExpenseDetailReportVO extends CircularlyAccessibleValueObject implements Cloneable{
	private String expenseType;
	private String expenseCode;
	private String expenseName;
	private UFDouble yearSum=new UFDouble(0);
	private UFDouble janSum=new UFDouble(0);
	private UFDouble febSum=new UFDouble(0);
	private UFDouble matSum=new UFDouble(0);
	private UFDouble aprSum=new UFDouble(0);
	private UFDouble maySum=new UFDouble(0);
	private UFDouble junSum=new UFDouble(0);
	private UFDouble julSum=new UFDouble(0);
	private UFDouble augSum=new UFDouble(0);
	private UFDouble sepSum=new UFDouble(0);
	private UFDouble octSum=new UFDouble(0);
	private UFDouble novSum=new UFDouble(0);
	private UFDouble decSum=new UFDouble(0);
	
	 private HashMap values;
	 private Vector fields;
	 public ExpenseDetailReportVO(){
			values = new HashMap();
	        fields = new Vector();
	 }
	public UFDouble getAprSum() {
		return aprSum;
	}

	public void setAprSum(UFDouble aprSum) {
		this.aprSum = aprSum;
		this.setAttributeValue("aprSum", aprSum);
	}

	public UFDouble getAugSum() {
		return augSum;
	}

	public void setAugSum(UFDouble augSum) {
		this.augSum = augSum;
		this.setAttributeValue("augSum", augSum);
	}

	public UFDouble getDecSum() {
		return decSum;
	}

	public void setDecSum(UFDouble decSum) {
		this.decSum = decSum;
		this.setAttributeValue("decSum", decSum);
	}

	public String getExpenseCode() {
		return expenseCode;
	}

	public void setExpenseCode(String expenseCode) {
		this.expenseCode = expenseCode;
		this.setAttributeValue("expenseCode", expenseCode);
	}

	public String getExpenseName() {
		return expenseName;
	}

	public void setExpenseName(String expenseName) {
		this.expenseName = expenseName;
		this.setAttributeValue("expenseName", expenseName);
	}

	public UFDouble getFebSum() {
		return febSum;
	}

	public void setFebSum(UFDouble febSum) {
		this.febSum = febSum;
		this.setAttributeValue("febSum", febSum);
	}

	public UFDouble getJanSum() {
		return janSum;
	}

	public void setJanSum(UFDouble janSum) {
		this.janSum = janSum;
		this.setAttributeValue("janSum", janSum);
	}

	public UFDouble getJulSum() {
		return julSum;
	}

	public void setJulSum(UFDouble julSum) {
		this.julSum = julSum;
		this.setAttributeValue("julSum", julSum);
	}

	public UFDouble getJunSum() {
		return junSum;
	}

	public void setJunSum(UFDouble junSum) {
		this.junSum = junSum;
		this.setAttributeValue("junSum", junSum);
	}

	public UFDouble getMatSum() {
		return matSum;
	}

	public void setMatSum(UFDouble matSum) {
		this.matSum = matSum;
		this.setAttributeValue("matSum", matSum);
	}

	public UFDouble getMaySum() {
		return maySum;
	}

	public void setMaySum(UFDouble maySum) {
		this.maySum = maySum;
		this.setAttributeValue("maySum", maySum);
	}

	public UFDouble getNovSum() {
		return novSum;
	}

	public void setNovSum(UFDouble novSum) {
		this.novSum = novSum;
		this.setAttributeValue("novSum", novSum);
	}

	public UFDouble getOctSum() {
		return octSum;
	}

	public void setOctSum(UFDouble octSum) {
		this.octSum = octSum;
		this.setAttributeValue("octSum", octSum);
	}

	public UFDouble getSepSum() {
		return sepSum;
	}

	public void setSepSum(UFDouble sepSum) {
		this.sepSum = sepSum;
		this.setAttributeValue("sepSum", sepSum);
	}

	public UFDouble getYearSum() {
		return yearSum;
	}

	public void setYearSum(UFDouble yearSum) {
		this.yearSum = yearSum;
		this.setAttributeValue("yearSum", yearSum);
	}

	@Override
	public String[] getAttributeNames() {
		// TODO Auto-generated method stub
		return (String[])(String[])fields.toArray(new String[0]);
	}

	@Override
	public Object getAttributeValue(String attributeName) {
		 
		// TODO Auto-generated method stub
		if(attributeName.equals("yearSum")){
			return this.getYearSum();
		}else if(attributeName.equals("expenseCode")){
			return this.getExpenseCode();
		}else if(attributeName.equals("expenseType")){
			return this.getExpenseType();
		}else if(attributeName.equals("expenseName")){
			return this.getExpenseName();
		} 
		else if(attributeName.equals("janSum")){
			return this.getJanSum();
		}
		else if(attributeName.equals("febSum")){
			return this.getFebSum();
		}
		else if(attributeName.equals("matSum")){
			return this.getMatSum();
		}
		else if(attributeName.equals("aprSum")){
			return this.getAprSum();
		}
		else if(attributeName.equals("maySum")){
			return this.getMaySum();
		}
		else if(attributeName.equals("junSum")){
			return this.getJunSum();
		}
		else if(attributeName.equals("julSum")){
			return this.getJulSum();
		}
		else if(attributeName.equals("augSum")){
			return this.getAugSum();
		}
		else if(attributeName.equals("sepSum")){
			return this.getSepSum();
		}
		else if(attributeName.equals("octSum")){
			return this.getOctSum();
		}
		else if(attributeName.equals("novSum")){
			return this.getNovSum();
		}
		else if(attributeName.equals("decSum")){
			return this.getDecSum();
		}
		else
			return values.get(attributeName);
	}

	@Override
	public void setAttributeValue(String name, Object value) {
		// TODO Auto-generated method stub
		 if(name != null){
			 if(value != null){
				 values.put(name, value);
				 if(!fields.contains(name))
					 fields.addElement(name);
			 } else{
				 values.remove(name);
			 }
		 }
	}

	@Override
	public String getEntityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void validate() throws ValidationException {
		// TODO Auto-generated method stub
		
	}
	
	public Object clone(){
		ExpenseDetailReportVO gvo;
        try{
            gvo = (ExpenseDetailReportVO)super.clone();
        }catch(Exception e){
            gvo = new ExpenseDetailReportVO();
        }
        gvo.fields = (Vector)fields.clone();
        gvo.values = (HashMap)values.clone();
        return gvo;
    }
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
		this.setAttributeValue("expenseType", expenseType);
	}

}
