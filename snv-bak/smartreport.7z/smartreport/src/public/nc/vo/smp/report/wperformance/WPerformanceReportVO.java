package nc.vo.smp.report.wperformance;

import java.util.HashMap;
import java.util.Vector;

import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.ValidationException;
import nc.vo.pub.lang.UFDouble;

public class WPerformanceReportVO extends CircularlyAccessibleValueObject implements Cloneable{
 
	private String itemcode;
	private UFDouble wamount=new UFDouble(0,2);
	private UFDouble fweek=new UFDouble(0,2);
	private UFDouble sweek=new UFDouble(0,2);
	private UFDouble tweek=new UFDouble(0,2);
	private UFDouble ftweek=new UFDouble(0,2);
	private UFDouble fiweek=new UFDouble(0,2);
	 
	 private HashMap values;
	 private Vector fields;
	 public WPerformanceReportVO(){
			values = new HashMap();
	        fields = new Vector();
	 }
	 
	public UFDouble getFiweek() {
		fiweek.setScale(2, UFDouble.ROUND_HALF_UP);
		return fiweek;
	}

	public void setFiweek(UFDouble fiweek) {
		fiweek.setScale(2, UFDouble.ROUND_HALF_UP);
		this.fiweek = fiweek;
		this.setAttributeValue("fiweek", fiweek);
	}

	public UFDouble getFtweek() {
		ftweek.setScale(2, UFDouble.ROUND_HALF_UP);
		return ftweek;
	}

	public void setFtweek(UFDouble ftweek) {
		ftweek.setScale(2, UFDouble.ROUND_HALF_UP);
		this.ftweek = ftweek;
		this.setAttributeValue("ftweek", ftweek);
	}

	public UFDouble getFweek() {
		fweek.setScale(2, UFDouble.ROUND_HALF_UP);
		return fweek;
	}

	public void setFweek(UFDouble fweek) {
		fweek.setScale(2, UFDouble.ROUND_HALF_UP);
		this.fweek = fweek;
		this.setAttributeValue("fweek", fweek);
	}

	public String getItemcode() {
		return itemcode;
	}

	public void setItemcode(String itemcode) {
		this.itemcode = itemcode;
		this.setAttributeValue("itemcode", itemcode);
	}

	public UFDouble getSweek() {
		sweek.setScale(2, UFDouble.ROUND_HALF_UP);
		return sweek;
	}

	public void setSweek(UFDouble sweek) {
		sweek.setScale(2, UFDouble.ROUND_HALF_UP);
		this.sweek = sweek;
		this.setAttributeValue("sweek", sweek);
	}

	public UFDouble getTweek() {
		tweek.setScale(2, UFDouble.ROUND_HALF_UP);
		return tweek;
	}

	public void setTweek(UFDouble tweek) {
		tweek.setScale(2, UFDouble.ROUND_HALF_UP);
		this.tweek = tweek;
		this.setAttributeValue("tweek", tweek);
	}

	public UFDouble getWamount() {
		wamount.setScale(2, UFDouble.ROUND_HALF_UP);
		return wamount;
	}

	public void setWamount(UFDouble wamount) {
		wamount.setScale(2, UFDouble.ROUND_HALF_UP);
		this.wamount = wamount;
		this.setAttributeValue("wamount", wamount);
	}

	 

	@Override
	public String[] getAttributeNames() {
		// TODO Auto-generated method stub
		return (String[])(String[])fields.toArray(new String[0]);
	}

	@Override
	public Object getAttributeValue(String attributeName) {
		 
		// TODO Auto-generated method stub
		if(attributeName.equals("itemcode")){
			return this.getItemcode();
		}else if(attributeName.equals("wamount")){
			return this.getWamount();
		} else if(attributeName.equals("fweek")){
			return this.getFweek();
		} 
		else if(attributeName.equals("sweek")){
			return this.getSweek();
		}
		else if(attributeName.equals("tweek")){
			return this.getTweek();
		}
		else if(attributeName.equals("ftweek")){
			return this.getFtweek();
		}
		else if(attributeName.equals("fiweek")){
			return this.getFiweek();
		}
		 
		else
			return values.get(attributeName);
	}

	@Override
	public void setAttributeValue(String name, Object value) {
		// TODO Auto-generated method stub
		 if(name != null){
			 if(value != null){
				 values.put(name, value);
				 if(!fields.contains(name))
					 fields.addElement(name);
			 } else{
				 values.remove(name);
			 }
		 }
	}

	@Override
	public String getEntityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void validate() throws ValidationException {
		// TODO Auto-generated method stub
		
	}
	
	public Object clone(){
		WPerformanceReportVO gvo;
        try{
            gvo = (WPerformanceReportVO)super.clone();
        }catch(Exception e){
            gvo = new WPerformanceReportVO();
        }
        gvo.fields = (Vector)fields.clone();
        gvo.values = (HashMap)values.clone();
        return gvo;
    }
 

}
