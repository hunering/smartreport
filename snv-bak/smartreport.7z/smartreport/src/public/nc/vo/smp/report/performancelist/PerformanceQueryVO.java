package nc.vo.smp.report.performancelist;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Vector;

import nc.vo.pub.lang.UFDate;
import nc.vo.smp.report.detail.DetailReportVO;

/**
 * ҵ����ϸ������ѯ����
 * @author LINQI
 *
 */
public class PerformanceQueryVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private UFDate fromDate;	//��ʼ����
	private UFDate endDate;		//
	private String unitcode;	//��λ����
	private String pk_corp;		
	private String month;		//��ѯ�·�yyyy-MM
	
	
	public PerformanceQueryVO(){
		
	}


	public UFDate getFromDate() {
		return fromDate;
	}


	public void setFromDate(UFDate fromDate) {
		this.fromDate = fromDate;
	}


	public UFDate getEndDate() {
		return endDate;
	}


	public void setEndDate(UFDate endDate) {
		this.endDate = endDate;
	}


	public String getUnitcode() {
		return unitcode;
	}


	public void setUnitcode(String unitcode) {
		this.unitcode = unitcode;
	}


	public String getPk_corp() {
		return pk_corp;
	}


	public void setPk_corp(String pk_corp) {
		this.pk_corp = pk_corp;
	}


	public String getMonth() {
		return month;
	}


	public void setMonth(String month) {
		this.month = month;
	}
	
/*	public Object clone(){
		IncomeQueryVO gvo;
        try{
            gvo = (IncomeQueryVO)super.clone();
        }catch(Exception e){
            gvo = new IncomeQueryVO();
        }
        gvo.fromDate = (UFDate) fromDate.clone();
        gvo.endDate = (UFDate) endDate.clone();
        return gvo;
    }*/
	
}
