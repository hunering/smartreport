package nc.vo.smp.report.performancelist;

import java.util.HashMap;
import java.util.Vector;

import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.ValidationException;
import nc.vo.pub.lang.UFDouble;

public class PerformanceDetailVO extends CircularlyAccessibleValueObject implements
		Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Vector fields;
	private HashMap values;

	private String area; // ����
	private String branchName; // �ֹ�˾

	public PerformanceDetailVO() {
		fields = new Vector();
		values = new HashMap();
	}

	@Override
	public String[] getAttributeNames() {
		// TODO Auto-generated method stub
		return (String[]) (String[]) fields.toArray(new String[0]);
	}

	@Override
	public Object getAttributeValue(String attributeName) {
		// TODO Auto-generated method stub
		if (attributeName.equals("area")) {
			return this.getArea();
		} else
			return values.get(attributeName);
	}

	@Override
	public void setAttributeValue(String name, Object value) {
		// TODO Auto-generated method stub
		if(name != null){
			 if(value != null){
				 values.put(name, value);
				 if(!fields.contains(name))
					 fields.addElement(name);
			 } else{
				 values.remove(name);
			 }
		 }
	}

	@Override
	public String getEntityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void validate() throws ValidationException {
		// TODO Auto-generated method stub

	}

	public Object clone() {
		PerformanceDetailVO gvo;
		try {
			gvo = (PerformanceDetailVO) super.clone();
		} catch (Exception e) {
			gvo = new PerformanceDetailVO();
		}
        gvo.fields = (Vector)fields.clone();
        gvo.values = (HashMap)values.clone();
        return gvo;
	}

	protected void setArea(String area) {
		this.area = area;
	}

	protected String getArea() {
		return area;
	}

	protected void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	protected String getBranchName() {
		return branchName;
	}

}
