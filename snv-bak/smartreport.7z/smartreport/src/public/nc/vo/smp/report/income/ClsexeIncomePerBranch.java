package nc.vo.smp.report.income;

import java.io.Serializable;

import nc.vo.pub.lang.UFDouble;

public class ClsexeIncomePerBranch implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String pk_clsexe;
	private String studentNum;
	private String totalMoney;
	private String groupMoney;
	private String branchMoney;
	private String jxMoney;
	private String sdMoney;
	public void setPk_clsexe(String pk_clsexe) {
		this.pk_clsexe = pk_clsexe;
	}
	public String getPk_clsexe() {
		return pk_clsexe;
	}
	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	}
	public String getStudentNum() {
		return studentNum;
	}
	public void setTotalMoney(String totalMoney) {
		this.totalMoney = totalMoney;
	}
	public String getTotalMoney() {
		return totalMoney;
	}
	public void setGroupMoney(String groupMoney) {
		this.groupMoney = groupMoney;
	}
	public String getGroupMoney() {
		return groupMoney;
	}
	public void setBranchMoney(String branchMoney) {
		this.branchMoney = branchMoney;
	}
	public String getBranchMoney() {
		return branchMoney;
	}
	public void setJxMoney(String jxMoney) {
		this.jxMoney = jxMoney;
	}
	public String getJxMoney() {
		return jxMoney;
	}
	public void setSdMoney(String sdMoney) {
		this.sdMoney = sdMoney;
	}
	public String getSdMoney() {
		return sdMoney;
	}
	
//	public int studentNum;
//	public UFDouble totalMoney;
//	public UFDouble groupMoney;
//	public UFDouble branchMoney;
//	public UFDouble jxMoney;
//	public UFDouble sdMoney;
}
