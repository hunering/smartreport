package nc.vo.smp.report.income;

import java.io.Serializable;

import nc.vo.pub.lang.UFDouble;

public class ClsexeIncomePerBranch implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String pk_clsexe;
	private Integer studentNum = 0;
	private UFDouble totalMoney = UFDouble.ZERO_DBL;
	private UFDouble groupMoney = UFDouble.ZERO_DBL;
	private UFDouble branchMoney = UFDouble.ZERO_DBL;
	private UFDouble jxMoney = UFDouble.ZERO_DBL;
	private UFDouble sdMoney = UFDouble.ZERO_DBL;
	private UFDouble wuxiangMoney = UFDouble.ZERO_DBL;
	public void setPk_clsexe(String pk_clsexe) {
		this.pk_clsexe = pk_clsexe;
	}
	public String getPk_clsexe() {
		return pk_clsexe;
	}
	public void setStudentNum(Integer studentNum) {
		this.studentNum = studentNum;
	}
	public Integer getStudentNum() {
		return studentNum;
	}
	public void setTotalMoney(UFDouble totalMoney) {
		this.totalMoney = totalMoney;
	}
	public UFDouble getTotalMoney() {
		return totalMoney;
	}
	public void setGroupMoney(UFDouble groupMoney) {
		this.groupMoney = groupMoney;
	}
	public UFDouble getGroupMoney() {
		return groupMoney;
	}
	public void setBranchMoney(UFDouble branchMoney) {
		this.branchMoney = branchMoney;
	}
	public UFDouble getBranchMoney() {
		return branchMoney;
	}
	public void setJxMoney(UFDouble jxMoney) {
		this.jxMoney = jxMoney;
	}
	public UFDouble getJxMoney() {
		return jxMoney;
	}
	public void setSdMoney(UFDouble sdMoney) {
		this.sdMoney = sdMoney;
	}
	public UFDouble getSdMoney() {
		return sdMoney;
	}
	
	public void setWuxiangMoney(UFDouble wuxiangMoney) {
		this.wuxiangMoney = wuxiangMoney;
	}
	public UFDouble getWuxiangMoney() {
		return wuxiangMoney;
	}	
//	public int studentNum;
//	public UFDouble totalMoney;
//	public UFDouble groupMoney;
//	public UFDouble branchMoney;
//	public UFDouble jxMoney;
//	public UFDouble sdMoney;
}
