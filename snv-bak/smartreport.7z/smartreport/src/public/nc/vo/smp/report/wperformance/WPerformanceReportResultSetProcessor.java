package nc.vo.smp.report.wperformance;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nc.jdbc.framework.processor.ResultSetProcessor;
import nc.vo.pub.lang.UFDouble;

public class WPerformanceReportResultSetProcessor implements ResultSetProcessor {

	public Object handleResultSet(ResultSet rs) throws SQLException {
		List<WPerformanceReportVO> result=new ArrayList<WPerformanceReportVO>();
		while(rs.next()){
			WPerformanceReportVO vo=new WPerformanceReportVO();
			vo.setItemcode(rs.getString("itemcode"));
			vo.setFweek(new UFDouble(rs.getString("fweek")));
			 
			vo.setWamount (new UFDouble(rs.getDouble("wamount")));
			vo.setSweek(new UFDouble(rs.getDouble("sweek")));
			vo.setTweek(new UFDouble(rs.getDouble("tweek")));
			vo.setFtweek(new UFDouble(rs.getDouble("ftweek")));
			vo.setFiweek(new UFDouble(rs.getDouble("fiweek")));
			 
			result.add(vo);
		 
		}
		return result;
	}

}
