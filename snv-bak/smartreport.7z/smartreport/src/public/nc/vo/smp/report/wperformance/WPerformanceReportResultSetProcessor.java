package nc.vo.smp.report.wperformance;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nc.jdbc.framework.processor.ResultSetProcessor;
import nc.vo.pub.lang.UFDouble;

public class WPerformanceReportResultSetProcessor implements ResultSetProcessor {

	public Object handleResultSet(ResultSet rs) throws SQLException {
		List<WPerformanceReportVO> result=new ArrayList<WPerformanceReportVO>();
		while(rs.next()){
			WPerformanceReportVO vo=new WPerformanceReportVO();
			vo.setItemcode(rs.getString("itemcode"));
			vo.setFweek(new UFDouble(rs.getString("fweek"),2));
			 
			vo.setWamount (new UFDouble(rs.getDouble("wamount"),2));
			vo.setSweek(new UFDouble(rs.getDouble("sweek"),2));
			vo.setTweek(new UFDouble(rs.getDouble("tweek"),2));
			vo.setFtweek(new UFDouble(rs.getDouble("ftweek"),2));
			vo.setFiweek(new UFDouble(rs.getDouble("fiweek"),2));
			 
			result.add(vo);
		 
		}
		return result;
	}

}
