package nc.vo.smp.report.income;

import java.util.HashMap;
import java.util.Vector;

import nc.vo.pub.CircularlyAccessibleValueObject;
import nc.vo.pub.ValidationException;
import nc.vo.pub.lang.UFDouble;

/**
 * ��ϸ����VO
 * 
 * @author LINQI
 * 
 */
public class AgentIncomeReportVO extends CircularlyAccessibleValueObject implements
		Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HashMap<String, ClsexeIncomePerBranch> clsexeIncomes; //pk_clsexe -> ClsexePerBranch
	private Vector fields;

	private String branchName; 
	private String agentName; // Agent

	public AgentIncomeReportVO() {
		clsexeIncomes = new HashMap<String, ClsexeIncomePerBranch>();
		fields = new Vector();
	}

	@Override
	public String[] getAttributeNames() {
		// TODO Auto-generated method stub
		return (String[]) (String[]) fields.toArray(new String[0]);
	}

	@Override
	public Object getAttributeValue(String attributeName) {
		// TODO Auto-generated method stub
		if (attributeName.equals("agentname")) {
			return this.getAgentName();
		} else if (attributeName.equals("branchname")) {
			return this.getBranchName();
		} else
			return clsexeIncomes.get(attributeName);
	}

	@Override
	public void setAttributeValue(String name, Object value) {
		// TODO Auto-generated method stub
		if (name != null) {
			if (value != null) {
				if(name.equals("branchname")) {
					setBranchName((String)value);
				} else if(name.equals("agentname")) {
					setAgentName((String)value);
				} else {
					clsexeIncomes.put(name, (ClsexeIncomePerBranch)value);
				}
				if (!fields.contains(name))
					fields.addElement(name);
			} else {
				clsexeIncomes.remove(name);
			}
		}
	}

	@Override
	public String getEntityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void validate() throws ValidationException {
		// TODO Auto-generated method stub

	}

	public Object clone() {
		AgentIncomeReportVO gvo;
		try {
			gvo = (AgentIncomeReportVO) super.clone();
		} catch (Exception e) {
			gvo = new AgentIncomeReportVO();
		}
		gvo.fields = (Vector) fields.clone();
		gvo.clsexeIncomes = (HashMap) clsexeIncomes.clone();
		return gvo;
	}

	protected void setAgentName(String branchName) {
		this.agentName = branchName;
	}

	protected String getAgentName() {
		return agentName;
	}
	
	protected void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	protected String getBranchName() {
		return branchName;
	}
}
