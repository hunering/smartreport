package nc.vo.smp.report.expensedetail;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nc.jdbc.framework.processor.ResultSetProcessor;
import nc.vo.pub.lang.UFDouble;

public class ExpenseReportResultSetProcessor implements ResultSetProcessor {

	public Object handleResultSet(ResultSet rs) throws SQLException {
		List<ExpenseDetailReportVO> result=new ArrayList<ExpenseDetailReportVO>();
		while(rs.next()){
			ExpenseDetailReportVO vo=new ExpenseDetailReportVO();
			vo.setExpenseCode(rs.getString("expenseCode"));
			vo.setExpenseName(rs.getString("expenseName"));
			vo.setExpenseType(rs.getString("expenseType"));
			vo.setYearSum(new UFDouble(rs.getDouble("yearSum")));
			vo.setJanSum(new UFDouble(rs.getDouble("janSum")));
			vo.setFebSum(new UFDouble(rs.getDouble("febSum")));
			vo.setMatSum(new UFDouble(rs.getDouble("matSum")));
			vo.setAprSum(new UFDouble(rs.getDouble("aprSum")));
			vo.setMaySum(new UFDouble(rs.getDouble("maySum")));
			vo.setJunSum(new UFDouble(rs.getDouble("junSum")));
			vo.setJulSum(new UFDouble(rs.getDouble("julSum")));
			vo.setAugSum(new UFDouble(rs.getDouble("augSum")));
			vo.setSepSum(new UFDouble(rs.getDouble("sepSum")));
			vo.setOctSum(new UFDouble(rs.getDouble("octSum")));
			vo.setNovSum(new UFDouble(rs.getDouble("novSum")));
			vo.setDecSum(new UFDouble(rs.getDouble("decSum")));
			result.add(vo);
		 
		}
		return result;
	}

}
